﻿using UnityEngine;
using System.Collections;
using System;
using System.IO;
using System.Text.RegularExpressions;
using UnityEngine.UI;
using System.Collections.Generic;




public class WaspWalk : MonoBehaviour {

	public Text WhatToRotate;

	Keyframe[] KeysofCurve;
	String[] substrings;
	String[] skinstrings;
	String[] animstrings;
	AnimationInfo[] toTransform;
	int jointCount;
	joint[] joints;
	String names;
	//int frames;
	AnimationCurve[] anims;
	static float pi = 57.29578F;
	private AnimationCurve anim;
	private Keyframe[] ks;
	int channels;

	//MeshFilter[] jointMeshes;

	public GameObject[] myObjects;

	class AnimationInfo{
		
		public AnimationCurve animationCurve;
		public int extmode;


	
		public void setExtMode(int mode)
		{
			extmode = mode;

		}
		public int getExtMode()
		{
			return extmode;
		}
	}



	class joint{

		public joint parent = null;
		//public Vector3[] points;
		public Vector3 jOffset;
		public Vector3 jboxmin;
		public Vector3 jboxmax;
		public Vector2 jrotxlimit;
		public Vector2 jrotylimit;
		public Vector2 jrotzlimit;
		public Vector3 jpose;

		public joint()
		{
			jOffset = new Vector3(0,0,0);
			jboxmin = new Vector3(-0.1f,-0.1f,-0.1f);
			jboxmin = new Vector3(0.1f,0.1f,0.1f);
			jpose = new Vector3(0,0,0);
			jrotxlimit = new Vector2(-1000f,1000f);
			jrotylimit = new Vector2(-1000f,1000f);
			jrotzlimit = new Vector2(-1000f,1000f);
		}

		public void setJOffset(Vector3 Offset)
		{
			jOffset = Offset;
		}
		public void setJBoxmin(Vector3 boxmin)
		{
			jboxmin = boxmin;
		}
		public void setJBoxmax(Vector3 boxmax)
		{
			jboxmax = boxmax;
		}
		public void setRotxlimit(Vector3 rotxlimit)
		{
			jrotxlimit =rotxlimit;
		}
		public void setRotylimit(Vector3 rotylimit)
		{
			jrotylimit = rotylimit;
		}
		public void setRotzlimit(Vector3 rotzlimit)
		{
			jrotzlimit = rotzlimit;
		}
		public void setPose(Vector3 pose)
		{
			jpose = pose;
		}
	}

	//
	//





	//
	//
	//
	//
	int timeToFrames(float time)
	{
		return (int)time * 60;
	}

	//
	//
	//
	// TO CREATE THE EASEINOUT ANIMATION CURVE INVOKE THE ANIMATION CURVE METHOD AnimationCurve.EaseInOut

	void createAnimation(){


		float time;
		int inc =0;


		for (int i = 2; i < animstrings.Length; ++i)
		{
			Debug.Log ("test i = " + i);
			if (animstrings [i] == "range") {
				float beginTime = Convert.ToSingle(animstrings[i+1]);
				float endTime = Convert.ToSingle(animstrings[i+2]);
				time = endTime - beginTime;
				//frames = timeToFrames (time);
				i += 3;
			}


			if (animstrings [i] == "numchannels") {  //the first 3 channels are for the position of the root, and then the last 3*jointcount are for rotation cycles
				//each channel is an animation curve
				Debug.Log("am i getting here?");
				channels = Convert.ToInt32 (animstrings [i + 1]);
				anims = new AnimationCurve[channels];

				i += 5;
			}
			

			//gather the extrapolation modes
			if (animstrings [i] == "constant") {
				Debug.Log ("channels is "+channels +" inc is "+inc);
				toTransform [inc] = new AnimationInfo();
				//Debug.Log ("LENGTH IS "+toTransform.Length);
				//Debug.Log (toTransform[inc].extmode);
				toTransform [inc].setExtMode(1); 
				i += 2;
			}
			if (animstrings [i] == "cycle") {
				toTransform [inc] = new AnimationInfo();
				toTransform [inc].setExtMode(2); 
				i += 2;
			}
			if (animstrings [i] == "cycle_offset") {
				toTransform [inc] = new AnimationInfo();
				toTransform [inc].setExtMode(3); 
				i += 2;
			}
			if (animstrings [i] == "bounce") {
				toTransform [inc] = new AnimationInfo();
				toTransform [inc].setExtMode(4); 
				i += 2;
			}

			if (animstrings [i] == "keys") {
				int keys = Convert.ToInt32 (animstrings [i + 1]);
				i += 3;
				for (int j = 0; j < keys; ++j) {
					KeysofCurve = new Keyframe[keys];
					KeysofCurve[j] = new Keyframe(Convert.ToSingle(animstrings[i]),Convert.ToSingle(animstrings[i+1]),0f,0f);
					i += 4;
				}
				if (animstrings [i - 1] == "linear") {
					AnimationCurve a = new AnimationCurve (KeysofCurve);
					SetCurveLinear (a);
					anims [inc]= a; 

				}
				if (animstrings [i - 1] == "smooth")
				{
					AnimationCurve a = new AnimationCurve (KeysofCurve);
					for (int k = 0; k < a.length; ++k)
						a.SmoothTangents (k, 0);
					anims [inc] = a;
				}
				if (animstrings [i - 1] == "flat") 
				{
					anims [inc] = new AnimationCurve (KeysofCurve);
				}
				
				toTransform [inc].animationCurve = anims [inc];
				++inc;
				Debug.Log ("INCREMENTED to " + inc);
			}
		}
		}
	//
	//
	//
	//
	//
	//

	public static void SetCurveLinear(AnimationCurve curve) {
		for (int i = 0; i < curve.keys.Length; ++i) {
			float intangent = 0;
			float outtangent = 0;
			bool intangent_set = false;
			bool outtangent_set = false;
			Vector2 point1;
			Vector2 point2;
			Vector2 deltapoint;
			Keyframe key = curve[i];

			if (i == 0) {
				intangent = 0; intangent_set = true;
			}

			if (i == curve.keys.Length - 1) {
				outtangent = 0; outtangent_set = true;
			}

			if (!intangent_set) {
				point1.x = curve.keys[i - 1].time;
				point1.y = curve.keys[i - 1].value;
				point2.x = curve.keys[i].time;
				point2.y = curve.keys[i].value;

				deltapoint = point2 - point1;

				intangent = deltapoint.y / deltapoint.x;
			}
			if (!outtangent_set) {
				point1.x = curve.keys[i].time;
				point1.y = curve.keys[i].value;
				point2.x = curve.keys[i + 1].time;
				point2.y = curve.keys[i + 1].value;

				deltapoint = point2 - point1;

				outtangent = deltapoint.y / deltapoint.x;
			}

			key.inTangent = intangent;
			key.outTangent = outtangent;
			curve.MoveKey(i, key);
		}
	}
	//
	//
	//

	void createSkin(Transform[] bones)
	{
		BoneWeight[] skinweights;
		Matrix4x4[] bindings;
		Mesh mesh = new Mesh ();
		gameObject.AddComponent<SkinnedMeshRenderer> ();
		SkinnedMeshRenderer rend = GetComponent<SkinnedMeshRenderer> ();

		int inc;
		for (int i = 0; i < skinstrings.Length; i++) {
			if (skinstrings [i] == "positions") {
				inc = Convert.ToInt32 (skinstrings [i + 1]);
				Vector3[] positions = new Vector3[inc];
				i += 3;
				for (int k = 0; k < inc; k++) {
					positions [k] = new Vector3 (Convert.ToSingle (skinstrings [i]), Convert.ToSingle (skinstrings [i + 1]), Convert.ToSingle (skinstrings [i + 2]));
					Debug.Log ("Set mesh.vertices[" + k + "] to " + Convert.ToSingle (skinstrings [i]));
					i += 3;

				}
				mesh.vertices = positions;
			} else if (skinstrings [i] == "normals") {
				inc = Convert.ToInt32 (skinstrings [i + 1]);
				Debug.Log ("am i here");
				Vector3[] normals = new Vector3[inc];
				i += 3;
				for (int k = 0; k < inc; k++) {
					normals [k] = new Vector3 (Convert.ToSingle (skinstrings [i]), Convert.ToSingle (skinstrings [i + 1]), Convert.ToSingle (skinstrings [i + 2]));
					Debug.Log ("Set mesh.normals[" + k + "] to " + Convert.ToSingle (skinstrings [i]));
					i += 3;
				}
				mesh.normals = normals;
			} else if (skinstrings [i] == "skinweights") {
				inc = Convert.ToInt32 (skinstrings [i + 1]);
				Debug.Log ("am i here");
				skinweights = new BoneWeight[inc];
				i += 3;
				for (int k = 0; k < inc; k++) {
					int numattachments = Convert.ToInt32 (skinstrings [i]);
					++i;

					if (numattachments == 1) {
						skinweights [k].boneIndex0 = Convert.ToInt32 (skinstrings [i]);
						skinweights [k].weight0 = Convert.ToSingle (skinstrings [i + 1]);
						Debug.Log ("Set skinweights[" + k + "].boneIndex0 to " + Convert.ToSingle (skinstrings [i]) + " and Set skinweights[" + k + "].weight0 to " + Convert.ToSingle (skinstrings [i + 1]));
						i += 2;
					} else if (numattachments == 2) {
						skinweights [k].boneIndex0 = Convert.ToInt32 (skinstrings [i]);
						skinweights [k].weight0 = Convert.ToSingle (skinstrings [i + 1]);
						skinweights [k].boneIndex1 = Convert.ToInt32 (skinstrings [i + 2]);
						skinweights [k].weight1 = Convert.ToSingle (skinstrings [i + 3]);
						//Debug.Log ("Set skinweights[" + k + "].boneIndex0 to " + Convert.ToSingle (skinstrings [i]) + " and Set skinweights[" + k + "].weight0 to " + Convert.ToSingle (skinstrings [i + 1]));
						i += 4;
					} else if (numattachments == 3) {
						skinweights [k].boneIndex0 = Convert.ToInt32 (skinstrings [i]);
						skinweights [k].weight0 = Convert.ToSingle (skinstrings [i + 1]);
						skinweights [k].boneIndex1 = Convert.ToInt32 (skinstrings [i + 2]);
						skinweights [k].weight1 = Convert.ToSingle (skinstrings [i + 3]);
						skinweights [k].boneIndex2 = Convert.ToInt32 (skinstrings [i + 4]);
						skinweights [k].weight2 = Convert.ToSingle (skinstrings [i + 5]);
						//Debug.Log ("Set skinweights[" + k + "].boneIndex0 to " + Convert.ToSingle (skinstrings [i]) + " and Set skinweights[" + k + "].weight0 to " + Convert.ToSingle (skinstrings [i + 1]));
						i += 6;
					} else if (numattachments == 4) {
						skinweights [k].boneIndex0 = Convert.ToInt32 (skinstrings [i]);
						skinweights [k].weight0 = Convert.ToSingle (skinstrings [i + 1]);
						skinweights [k].boneIndex1 = Convert.ToInt32 (skinstrings [i + 2]);
						skinweights [k].weight1 = Convert.ToSingle (skinstrings [i + 3]);
						skinweights [k].boneIndex2 = Convert.ToInt32 (skinstrings [i + 4]);
						skinweights [k].weight2 = Convert.ToSingle (skinstrings [i + 5]);
						skinweights [k].boneIndex3 = Convert.ToInt32 (skinstrings [i + 6]);
						skinweights [k].weight3 = Convert.ToSingle (skinstrings [i + 7]);
						//Debug.Log ("Set skinweights[" + k + "].boneIndex0 to " + Convert.ToSingle (skinstrings [i]) + " and Set skinweights[" + k + "].weight0 to " + Convert.ToSingle (skinstrings [i + 1]));
						i += 8;
					}



				}
				//
				mesh.boneWeights = skinweights;
				//
			} 

			else if (skinstrings [i] == "triangles") {
				inc = Convert.ToInt32 (skinstrings [i + 1]);
				int[] triangles = new int[inc *= 3];
				i += 3;
				for (int k = 0; k < inc; k++) {
					triangles [k] = Convert.ToInt32 (skinstrings [i]);
					Debug.Log ("mesh.triangles[" + k + "] was set to " + (skinstrings [i]));
					i += 1;

				}
				mesh.triangles = triangles;

			} else if (skinstrings [i] == "bindings") {
				inc = Convert.ToInt32 (skinstrings [i+1]);
				bindings = new Matrix4x4[inc];
				i += 5;
				for (int j = 0; j < inc; j++) {
					for (int k = 0; k < 3; k++) {
						bindings [j].SetRow (k, new Vector4 (Convert.ToSingle (skinstrings [i]), Convert.ToSingle (skinstrings [i + 1]), Convert.ToSingle (skinstrings [i + 2]), 0f));
						Debug.Log ("set bindings[" + j + "] first element of row to " + Convert.ToSingle (skinstrings [i]));
						i += 3;
					}

					bindings [j].SetRow (3, new Vector4 (Convert.ToSingle (skinstrings [i]), Convert.ToSingle (skinstrings [i + 1]), Convert.ToSingle (skinstrings [i + 2]), 1f));
					bindings [j] = bindings [j].inverse;
					//bindings [j] = bindings [j].inverse;
					i += 6;
				}
				//
				mesh.bindposes = bindings;
				//
			}



		}

		Debug.Log (mesh.vertices [239]);
		Debug.Log (mesh.normals [239]);
		Debug.Log (mesh.boneWeights [239].boneIndex0 + " " + mesh.boneWeights [20].weight0+ " " + mesh.boneWeights [20].boneIndex1+ " " + mesh.boneWeights [20].weight1);
		Debug.Log (mesh.triangles [455]);
		Debug.Log (mesh.bindposes [0]);
		Debug.Log (mesh.bindposes [1]);

		mesh.RecalculateBounds();
		mesh.Optimize();
		rend.bones = bones;
		rend.sharedMesh = mesh;
		rend.material = new Material(Shader.Find("Diffuse"));


	}


	Transform createJoint(Vector3 offset, Vector3 poffset, Vector3 bmin, Vector3 bmax, Vector3 pose, Vector3 ppose, GameObject joints)
	{

		MeshFilter filter = joints.AddComponent< MeshFilter >();
		MeshRenderer meshrenderer = joints.AddComponent<MeshRenderer>();
		Mesh mesh = filter.mesh;
		meshrenderer.enabled = true;



		Vector3 p0 = new Vector3(bmin.x,bmin.y,bmax.z);
		Vector3 p1 = new Vector3(bmax.x,bmin.y,bmax.z);
		Vector3 p2 = new Vector3(bmax.x,bmin.y,bmin.z);
		Vector3 p3 = new Vector3(bmin.x,bmin.y,bmin.z);	

		Vector3 p4 = new Vector3(bmin.x,bmax.y,bmax.z);
		Vector3 p5 = new Vector3(bmax.x,bmax.y,bmax.z);
		Vector3 p6 = new Vector3(bmax.x,bmax.y,bmin.z);
		Vector3 p7 = new Vector3(bmin.x,bmax.y,bmin.z);

		Vector3[] vertices = new Vector3[]
		{
			//top
			p3,p2,p1,p0,
			//p0,p1,p2,p3,
			// RIGHT
			p3,p0,p4,p7,
			// Front
			//p4, p5, p1, p0,
			p0,p1,p5,p4,
			// Back
			//p6, p7, p3, p2,
			p2,p3,p7,p6,
			// LEFT
			p1,p2,p6,p5,

			// Bottom
			p4,p5,p6,p7
		};

		int[] triangles = new int[]
		{
			// TOP
			3, 1, 0,
			3, 2, 1,			

			// RIGHT
			3 + 4 * 1, 1 + 4 * 1, 0 + 4 * 1,
			3 + 4 * 1, 2 + 4 * 1, 1 + 4 * 1,

			// Front
			3 + 4 * 2, 1 + 4 * 2, 0 + 4 * 2,
			3 + 4 * 2, 2 + 4 * 2, 1 + 4 * 2,

			// Back
			3 + 4 * 3, 1 + 4 * 3, 0 + 4 * 3,
			3 + 4 * 3, 2 + 4 * 3, 1 + 4 * 3,

			// LEFT
			3 + 4 * 4, 1 + 4 * 4, 0 + 4 * 4,
			3 + 4 * 4, 2 + 4 * 4, 1 + 4 * 4,

			// BOTTOM
			3 + 4 * 5, 1 + 4 * 5, 0 + 4 * 5,
			3 + 4 * 5, 2 + 4 * 5, 1 + 4 * 5,

		};


		//mesh.vertices = vertices;

		//mesh.triangles = triangles;


		Vector3 flippedRotation = new Vector3 (ppose.x*pi +pose.x *pi, ppose.y*pi +pose.y*pi,ppose.z +pose.z);
		Quaternion qx = Quaternion.AngleAxis(flippedRotation.x, Vector3.right);
		Quaternion qy = Quaternion.AngleAxis(flippedRotation.y, Vector3.up);
		Quaternion qz = Quaternion.AngleAxis(flippedRotation.z, Vector3.forward);
		Quaternion qq = qz * qy * qx ; 

		joints.transform.localRotation = qq;
		joints.transform.localPosition= new Vector3 (offset.x + poffset.x, offset.y + poffset.y, offset.z + poffset.z);
		//joints.transform.rotation = Quaternion.Euler(ppose.x*57f + pose.x*57f, ppose.y*57f + pose.y*57f, ppose.z*57f + pose.z*57f);

		//mesh.RecalculateBounds();
		//mesh.Optimize();

		Vector3[] vertices8 = new Vector3[8] {
			p0,p1,p2,p3,p4,p5,p6,p7
		};

		return joints.transform;
	}

	void Awake() {
		Application.targetFrameRate = 60;
	}
	void Start () {



		try
		{   // Open the text file using a stream reader.
			using (StreamReader sr = new StreamReader("wasp_walk.skel"))
			{
				// Read the stream to a string, and write the string to the console.
				Debug.Log("found!");
				String line = sr.ReadToEnd();
				jointCount = Regex.Matches(line, "balljoint").Count;
				substrings =line.Split(new string[] {"\n","\r\n"," ","\t"},StringSplitOptions.RemoveEmptyEntries);
				myObjects = new GameObject[jointCount];



			}
		}
		catch (Exception e)
		{
			Debug.Log ("could not find");
			Console.WriteLine(e.Message);
		}

		Transform[] bones =new Transform[jointCount];

		try
		{   // Open the text file using a stream reader.
			using (StreamReader sr = new StreamReader("wasp_walk.skin"))
			{
				// Read the stream to a string, and write the string to the console.
				Debug.Log("found!");
				String line = sr.ReadToEnd();

				skinstrings =line.Split(new string[] {"\n","\r\n"," ","\t"},StringSplitOptions.RemoveEmptyEntries);



			}
		}
		catch (Exception e)
		{
			Debug.Log ("could not find");
			Console.WriteLine(e.Message);
		}

		try
		{   // Open the text file using a stream reader.
			using (StreamReader sr = new StreamReader("wasp_walk.anim"))
			{
				// Read the stream to a string, and write the string to the console.
				Debug.Log("found!");
				String line = sr.ReadToEnd();

				animstrings =line.Split(new string[] {"\n","\r\n"," ","\t"},StringSplitOptions.RemoveEmptyEntries);



			}
		}
		catch (Exception e)
		{
			Debug.Log ("could not find");
			Console.WriteLine(e.Message);
		}


		joints = new joint[jointCount];
		toTransform = new AnimationInfo[jointCount * 3 +3];
		Debug.Log ("LENGTH IS "+toTransform.Length);


		int jointIndex = 0;

		joints [jointIndex] = new joint ();
		joints [jointIndex].parent = new joint();


		//loops start here
		for(int i=0;i<substrings.Length;i++)
		{

			Debug.Log ("Index:" + i + "\t" + substrings[i]);
			if (substrings [i].Contains ("{")) 
			{
				Debug.Log (jointIndex);
				int k = i;

				while(true)
				{
					int nameindex = k-1;
					if (substrings [k + 1].Contains ("offset")) { //index out of range
						//joints [jointIndex] = new joint ();

						joints[jointIndex].setJOffset(new Vector3 (Convert.ToSingle (substrings [k + 2]), Convert.ToSingle (substrings [k + 3]), Convert.ToSingle (substrings [k + 4])));
						Debug.Log ("Is it parsing?1");
						k += 4;
					}
					if (substrings [k + 1].Contains ("boxmin")) {
						joints [jointIndex].setJBoxmin (new Vector3 (Convert.ToSingle (substrings [k + 2]), Convert.ToSingle (substrings [k + 3]), Convert.ToSingle (substrings [k + 4])));
						k += 4;
					} 
					if (substrings [k + 1].Contains ("boxmax")) {
						joints [jointIndex].setJBoxmax (new Vector3 (Convert.ToSingle (substrings [k + 2]), Convert.ToSingle (substrings [k + 3]), Convert.ToSingle (substrings [k + 4])));
						k += 4;
					} 
					if (substrings [k + 1].Contains ("rotxlimit")) {	
						joints [jointIndex].setRotxlimit (new Vector2 (Convert.ToSingle (substrings [k + 2]), Convert.ToSingle (substrings [k + 3])));
						k += 3;
					} 
					if (substrings [k + 1].Contains ("rotylimit")) {	
						joints [jointIndex].setRotylimit (new Vector2 (Convert.ToSingle (substrings [k + 2]), Convert.ToSingle (substrings [k + 3])));
						k += 3;
					} 
					if (substrings [k + 1].Contains ("rotzlimit")) {	
						joints [jointIndex].setRotzlimit (new Vector2 (Convert.ToSingle (substrings [k + 2]), Convert.ToSingle (substrings [k + 3])));
						k += 3;
					} 
					if (substrings [k + 1].Contains ("pose")) {	
						joints [jointIndex].setPose (new Vector3 (Convert.ToSingle (substrings [k + 2]), Convert.ToSingle (substrings [k + 3]), Convert.ToSingle (substrings [k + 4])));
						k += 4;
					}
					//++k;
					Debug.Log (joints [jointIndex].jOffset.x +" "+joints [jointIndex].jOffset.y +" "+joints [jointIndex].jOffset.z +" "+joints [jointIndex].jboxmin.x +" " 
						+joints [jointIndex].jboxmin.y +" "+joints [jointIndex].jboxmin.z +" ");

					//JOINT CREATION

					myObjects[jointIndex] = new GameObject(substrings[nameindex]);
					names += substrings [nameindex];


					bones[jointIndex] = createJoint (joints [jointIndex].jOffset, joints[jointIndex].parent.jOffset,  joints [jointIndex].jboxmin ,
						joints [jointIndex].jboxmax,joints[jointIndex].jpose, joints[jointIndex].parent.jpose, myObjects[jointIndex]);

					i = k;

					++jointIndex;
					if(jointIndex<jointCount)
						joints [jointIndex] = new joint ();
					break;



				}
				if(jointIndex<jointCount)
				{

					if (substrings [k + 1].Contains ("balljoint"))
					{
						joints [jointIndex].parent = joints [jointIndex - 1];
					}
					else
						joints [jointIndex].parent = new joint();

				}

			}
		}

		createSkin (bones);
		createAnimation();


	}


	void Update(){
		

		for (int i = 0; i < 3; ++i) {


			if (toTransform [i].extmode == 1) { //CONSTANT
				
				if (i % 3 == 0) {
					gameObject.transform.position = new Vector3 (toTransform [i].animationCurve.Evaluate (Time.time), 0, 0);
					for (int j = 0; j < myObjects.Length; ++j)
						myObjects [j].transform.position = new Vector3 (toTransform [i].animationCurve.Evaluate (Time.time), 0, 0);
				}
				if (i % 3 == 1){
					gameObject.transform.position = new Vector3 (0, toTransform [i].animationCurve.Evaluate (Time.time), 0);
					for (int j = 0; j < myObjects.Length; ++j)
						myObjects [j].transform.position = new Vector3 (0, toTransform [i].animationCurve.Evaluate (Time.time), 0);
				}
				if (i % 3 == 2){
					gameObject.transform.position = new Vector3 (0, 0,toTransform [i].animationCurve.Evaluate (Time.time));
					for (int j = 0; j < myObjects.Length; ++j)
						myObjects [j].transform.position = new Vector3 (0, 0,toTransform [i].animationCurve.Evaluate (Time.time));
				}
			}


			if (toTransform [i].extmode == 2) { //CYCLE
				toTransform [i].animationCurve.postWrapMode = WrapMode.Loop;
				if (i % 3 == 0) {
					
					gameObject.transform.position = new Vector3 (toTransform [i].animationCurve.Evaluate (Time.time), 0, 0);
					for (int j = 0; j < myObjects.Length; ++j)
						myObjects [j].transform.position = new Vector3 (toTransform [i].animationCurve.Evaluate (Time.time), 0, 0);
				}
				if (i % 3 == 1) {
					
					gameObject.transform.position = new Vector3 (0, toTransform [i].animationCurve.Evaluate (Time.time), 0);
					for (int j = 0; j < myObjects.Length; ++j)
						myObjects [j].transform.position = new Vector3 (0, toTransform [i].animationCurve.Evaluate (Time.time), 0);
				}
				if (i % 3 == 2) {
					
					gameObject.transform.position = new Vector3 (0, 0, toTransform [i].animationCurve.Evaluate (Time.time));
					for (int j = 0; j < myObjects.Length; ++j)
						myObjects [j].transform.position = new Vector3 (0, 0, toTransform [i].animationCurve.Evaluate (Time.time));
				}
			}
			if (toTransform [i].extmode == 3) { //CYCLE OFFSET
				toTransform [i].animationCurve.postWrapMode = WrapMode.Loop;
				if (i % 3 == 0) {
					
					gameObject.transform.position = new Vector3 (toTransform [i].animationCurve.Evaluate (Time.time), 0, 0);
					for (int j = 0; j < myObjects.Length; ++j)
						myObjects [j].transform.position = new Vector3 (toTransform [i].animationCurve.Evaluate (Time.time), 0, 0);
					
					} 
				if (i % 3 == 1) {
					
					gameObject.transform.position = new Vector3 (0, toTransform [i].animationCurve.Evaluate (Time.time), 0);
					for (int j = 0; j < myObjects.Length; ++j)
						myObjects [j].transform.position = new Vector3 (0, toTransform [i].animationCurve.Evaluate (Time.time), 0);
				}
				if (i % 3 == 2) {
					
					gameObject.transform.position = new Vector3 (0, 0, toTransform [i].animationCurve.Evaluate (Time.time));
					for (int j = 0; j < myObjects.Length; ++j)
						myObjects [j].transform.position = new Vector3 (0, 0, toTransform [i].animationCurve.Evaluate (Time.time));
				}
			}
			if (toTransform [i].extmode == 4) { //Bounce
				toTransform [i].animationCurve.postWrapMode = WrapMode.Loop;
				if (i % 3 == 0) {
					gameObject.transform.position = new Vector3 (toTransform [i].animationCurve.Evaluate (Time.time), 0, 0);
					for (int j = 0; j < myObjects.Length; ++j)
						myObjects [j].transform.position = new Vector3 (toTransform [i].animationCurve.Evaluate (Time.time), 0, 0);
				}
				if (i % 3 == 1){
					gameObject.transform.position = new Vector3 (0, toTransform [i].animationCurve.Evaluate (Time.time), 0);
					for (int j = 0; j < myObjects.Length; ++j)
						myObjects [j].transform.position = new Vector3 (0, toTransform [i].animationCurve.Evaluate (Time.time), 0);
				}
				if (i % 3 == 2){
					gameObject.transform.position = new Vector3 (0, 0,toTransform [i].animationCurve.Evaluate (Time.time));
					for (int j = 0; j < myObjects.Length; ++j)
						myObjects [j].transform.position = new Vector3 (0, 0,toTransform [i].animationCurve.Evaluate (Time.time));
				}
			}
		}

		for (int i = 3; i < (jointCount*3+3); ++i) {

		//toTransform array animationCurve and extmode
			if (toTransform [i].extmode == 1) { //Constant
				
				if (i % 3 == 0)
					myObjects [i / 3 - 1].transform.Rotate (toTransform [i].animationCurve.Evaluate (Time.time), 0, 0);
				if (i % 3 == 1)
					myObjects [i / 3 - 1].transform.Rotate (0, toTransform [i].animationCurve.Evaluate (Time.time), 0);
				if (i % 3 == 2)
					myObjects [i / 3 - 1].transform.Rotate (0, 0, toTransform [i].animationCurve.Evaluate (Time.time));
			}
				
			if (toTransform [i].extmode == 2) { //Cycle
				toTransform [i].animationCurve.postWrapMode = WrapMode.Loop;
				if (i % 3 == 0)
					myObjects [i / 3 - 1].transform.Rotate (toTransform [i].animationCurve.Evaluate (Time.time), 0, 0);
				if (i % 3 == 1)
					myObjects [i / 3 - 1].transform.Rotate (0, toTransform [i].animationCurve.Evaluate (Time.time), 0);
				if (i % 3 == 2)
					myObjects [i / 3 - 1].transform.Rotate (0, 0, toTransform [i].animationCurve.Evaluate (Time.time));
				toTransform [i].animationCurve.postWrapMode = WrapMode.PingPong;
			}

			if (toTransform [i].extmode == 3) { //Cycle-offset
				toTransform [i].animationCurve.postWrapMode = WrapMode.Loop;
				if (i % 3 == 0)
					myObjects [i / 3 - 1].transform.Rotate (toTransform [i].animationCurve.Evaluate (Time.time), 0, 0);
				if (i % 3 == 1)
					myObjects [i / 3 - 1].transform.Rotate (0, toTransform [i].animationCurve.Evaluate (Time.time), 0);
				if (i % 3 == 2)
					myObjects [i / 3 - 1].transform.Rotate (0, 0, toTransform [i].animationCurve.Evaluate (Time.time));
			}
			if (toTransform [i].extmode == 4) { //Bounce
				if (i % 3 == 0)
					myObjects [i / 3 - 1].transform.Rotate (toTransform [i].animationCurve.Evaluate (Time.time), 0, 0);
				if (i % 3 == 1)
					myObjects [i / 3 - 1].transform.Rotate (0, toTransform [i].animationCurve.Evaluate (Time.time), 0);
				if (i % 3 == 2)
					myObjects [i / 3 - 1].transform.Rotate (0, 0, toTransform [i].animationCurve.Evaluate (Time.time));
			}
		}
	}
}
		//Debug.Log (toTransform [0].extrapolationMode1);
		//gameObject.transform.position = new Vector3 (Time.time, toTransform[0].animationCurve.Evaluate (Time.time), 0);
		//gameObject.transform.Translate (Vector3.forward * Time.deltaTime);
		//myObjects[0].transform.Translate(Vector3.forward*Time.deltaTime);




