Grant Barratt
GCB140230
11/6/2016

To run this and view this assignment, either look at its scene file which is contained in assets or run the exe file.
In this assingment I was able to implement everything except proper animation of the limbs rotating and cycle-offset, which makes it look quite silly.