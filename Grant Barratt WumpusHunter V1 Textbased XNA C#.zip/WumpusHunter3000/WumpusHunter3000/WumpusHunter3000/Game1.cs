﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace WumpusHunter3000

{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        Room[] arena1;
        Map map1;

        Player you;
        Wumpus wump;

        static Boolean win = false;
        static Boolean nofix = false; // This prevents the arrows from realigning themselves to the path after veering off.
        static int backward = -1; // prevents arrows from going backward
        static int arrows;
        static int pstart;
        static int wstart;
        static Boolean step1 = true;
        static Boolean step2 = false;
        static Boolean step3 = false;

        string my_input;

        public void title()
        {
            System.Console.WriteLine("************************************************************************************");
            System.Console.WriteLine("************************************************************************************");
            System.Console.WriteLine("*******************      ♦♦♦♦♦       ♦♦♦♦♦       ♦♦♦♦♦       ♦♦♦♦♦         *********");
            System.Console.WriteLine("*******************     ♦     ♦     ♦     ♦     ♦     ♦     ♦     ♦        *********");
            System.Console.WriteLine("****                          ♦     ♦     ♦     ♦     ♦     ♦     ♦        *********");
            System.Console.WriteLine("****  WUMPUS HUNTER        ♦♦       ♦     ♦     ♦     ♦     ♦     ♦        *********");
            System.Console.WriteLine("****                          ♦     ♦     ♦     ♦     ♦     ♦     ♦        *********");
            System.Console.WriteLine("*******************     ♦     ♦     ♦     ♦     ♦     ♦     ♦     ♦        *********");
            System.Console.WriteLine("*******************      ♦♦♦♦♦       ♦♦♦♦♦       ♦♦♦♦♦       ♦♦♦♦♦         *********");
            System.Console.WriteLine("************************************************************************************");
            System.Console.WriteLine("************************************************************************************\n\n");
        }



        public class Room
        {
            int[] connect = new int[3];
            public int hazard; //0=nothing, 1=bats, 2=pit, 3= player start, 4= wumpus start

            public Room(int a, int b, int c)
            {
                connect[0] = a;
                connect[1] = b;
                connect[2] = c;
                hazard = 0;
            }

            public int[] getConnect()
            {
                return connect;
            }

        }

        public class Player
        {
            private int location;
            string input;

            public Player(int loc)
            {
                location = loc;
            }

            public void detect(Room a, Room[] b)
            {
                System.Console.WriteLine("\n");
                for (int i = 0; i < 3; i++)
                {
                    if (b[a.getConnect()[i]].hazard == 1)
                        System.Console.WriteLine("Bats Nearby!\n");
                    if (b[a.getConnect()[i]].hazard == 2)
                        System.Console.WriteLine("I feel a draft!\n");
                    if (b[a.getConnect()[i]].hazard >= 4) //fix this
                        System.Console.WriteLine("I smell a Wumpus!\n");
                }

            }





            public void bats()
            {
                System.Console.WriteLine("\nZap--Super Bat snatch! Elsewhereville for you!");
            }

            public void pit()
            {
                System.Console.WriteLine("\nYYYIIIIEEEE... fell in a pit");
            }

            public string wumpus(Wumpus a)
            {
                String death = "";
                if (a.getWoke() == false)
                {
                    System.Console.WriteLine("\nOoops! Bumped a Wumpus");
                    a.wakeUp();


                }
                else if (a.getWoke() == true)
                {
                    System.Console.WriteLine("\nOH NO THE WUughhgh...\n");
                    death = die();
                }
                return death;

            }

            public String die()
            {
                System.Console.WriteLine("OH NO YOU DIED!\n\n\n");
                System.Console.WriteLine("Would you like to play the same map or randomize to a new one?\nS - Same Map\nR - Randomize to a new Map");
                input = System.Console.ReadLine();
                while (input != "R" && input != "r" && input != "S" && input != "s")
                {
                    System.Console.WriteLine("nope bad input");
                    input = System.Console.ReadLine();
                }
                return input;

            }

            public int getLocation()
            {
                return location;
            }

            public int setLocation(int a)
            {
                location = a;
                return location;
            }

        }

        public class Wumpus
        {
            Random random = new Random();
            private int location;
            private Boolean wake;

            public Wumpus(int loc)
            {
                location = loc;
                wake = false;
            }

            public Boolean getWoke()
            {
                return wake;
            }

            public void wakeUp()
            {
                wake = true;
            }

            public void sleep()
            {
                wake = false;
            }

            public int move(int a, int b, int c, int d)
            {

                int r = random.Next(4);
                if (r == 0)
                    location = a;
                if (r == 1)
                    location = b;
                if (r == 2)
                    location = c;
                if (r == 3)
                    location = d;
                return location;
            }

            public int getLocation()
            {
                return location;
            }

            public int setLocation(int a)
            {
                location = a;
                return location;
            }
        }


        public class Map
        {

            public Room[] createArena()
            {
                Room[] Arena = new Room[20];
                Arena[0] = new Room(10, 1, 2);
                Arena[1] = new Room(0, 4, 15);
                Arena[2] = new Room(0, 6, 3);
                Arena[3] = new Room(5, 4, 2);
                Arena[4] = new Room(3, 1, 9);
                Arena[5] = new Room(7, 3, 8);
                Arena[6] = new Room(11, 2, 7);
                Arena[7] = new Room(6, 12, 5);
                Arena[8] = new Room(5, 13, 9);
                Arena[9] = new Room(8, 4, 14);
                Arena[10] = new Room(0, 11, 19);
                Arena[11] = new Room(10, 6, 16);
                Arena[12] = new Room(16, 7, 13);
                Arena[13] = new Room(12, 8, 17);
                Arena[14] = new Room(17, 15, 9);
                Arena[15] = new Room(14, 1, 19);
                Arena[16] = new Room(11, 12, 18);
                Arena[17] = new Room(18, 14, 13);
                Arena[18] = new Room(16, 17, 19);
                Arena[19] = new Room(10, 15, 18);
                //Provide the connections between rooms

                Random random = new Random();
                int temp1 = random.Next(20);
                Arena[temp1].hazard = 1;
                // Random room given bats.


                int temp2 = random.Next(20);
                while (temp1 == temp2)
                {
                    temp2 = random.Next(20);
                }
                Arena[temp2].hazard = 1;
                // Random room given bats. Bats can't be in the same place.


                int temp3 = random.Next(20);
                while (temp1 == temp3 || temp2 == temp3)
                {
                    temp3 = random.Next(20);
                }
                Arena[temp3].hazard = 2;
                // Random room assigned to pit1. Cant be same as bats


                int temp4 = random.Next(20);
                while (temp1 == temp4 || temp2 == temp4 || temp3 == temp4)
                {
                    temp4 = random.Next(20);
                }
                Arena[temp4].hazard = 2;
                // Random room assigned to pit2. Cant be same as bats or other pit.

                //---------------------
                int temp5 = random.Next(20);
                while (temp1 == temp5 || temp2 == temp5 || temp3 == temp5 || temp4 == temp5)
                {
                    temp5 = random.Next(20);
                }
                Arena[temp5].hazard = 3;
                pstart = temp5;
               // System.Console.WriteLine("TEST" + temp5);
                // Player start location


                int temp6 = random.Next(20);
                while (temp1 == temp6 || temp2 == temp6 || temp3 == temp6 || temp4 == temp6 || temp5 == temp6)
                {
                    temp6 = random.Next(20);
                }
                Arena[temp6].hazard = 4;
                wstart = temp6;
                // Wumpus start location


                return Arena;
            }

            public void describeMap(Room[] arena1, Player you, Wumpus wump)
            {
                for (int i = 0; i < 20; i++)
                {
                    /*
                    if (arena1[i].hazard == 1) //CHEATS!@#!@#
                        System.Console.WriteLine("Bats found at room " + i);
                    if (arena1[i].hazard == 2) //CHEATS!@#!@#
                        System.Console.WriteLine("Pit found at room " + i);
                    */
                    if (arena1[i].hazard == 3) //CHEATS!@#!@#
                    {
                        //   System.Console.WriteLine("Player start location at " + i);
                        pstart = i;
                    }

                    if (arena1[i].hazard == 4) //CHEATS!@#!@#
                    {
                        //    System.Console.WriteLine("Wumpus start location at " + i);
                        wstart = i;
                    }
                }

                you.setLocation(pstart);
                wump.setLocation(wstart);

            }

        }

        public void winner()
        {
            win = true;

            System.Console.WriteLine("\nHee hee hee - the Wumpus'll getcha next time!!\n\n");
            System.Console.WriteLine("Would you like to play the same map or randomize to a new one?\nS - Same Map\nR - Randomize to a new Map");


        }


        public void shoot(int ploc, int wloc, int[] path, Room[] a)
        {

            Random random = new Random();
            int temp = ploc;
            int x = path.Length;
            for (int i = 0; i < x; i++)
            {
                if ((path[i] == a[temp].getConnect()[0] || path[i] == a[temp].getConnect()[1] || path[i] == a[temp].getConnect()[2]) && nofix == false)
                {
                    backward = temp;
                    temp = path[i];
                    if (temp == wloc)
                    {
                        nofix = false;
                        System.Console.WriteLine("Aha! You got the Wumpus!");
                        winner();

                    }
                    else if (temp == ploc)
                    {
                        nofix = false;
                        System.Console.WriteLine("Ouch! Arrow got you!");
                        winner();
                    }
                }
                else
                {
                    nofix = true;
                    int temp2;
                    int rand;
                    temp2 = random.Next(3);
                    while (backward == a[temp].getConnect()[temp2])
                    {
                        temp2 = random.Next(3);
                    }

                    rand = temp2;

                    switch (rand)
                    {
                        case (0):
                            backward = temp;
                            temp = a[temp].getConnect()[0];
                            if (temp == wloc)
                            {
                                nofix = false;
                                System.Console.WriteLine("Aha! You got the Wumpus!");
                                winner();

                            }
                            if (temp == ploc)
                            {
                                nofix = false;
                                System.Console.WriteLine("Ouch! Arrow got you!");
                                winner();
                            }
                            break;
                        case (1):
                            backward = temp;
                            temp = a[temp].getConnect()[1];
                            if (temp == wloc)
                            {
                                nofix = false;
                                System.Console.WriteLine("Aha! You got the Wumpus!");
                                winner();

                            }
                            if (temp == ploc)
                            {
                                nofix = false;
                                System.Console.WriteLine("Ouch! Arrow got you!");
                                winner();
                            }
                            break;
                        case (2):
                            backward = temp;
                            temp = a[temp].getConnect()[2];
                            if (temp == wloc)
                            {
                                nofix = false;
                                System.Console.WriteLine("Aha! You got the Wumpus!");
                                winner();

                            }
                            if (temp == ploc)
                            {
                                nofix = false;
                                System.Console.WriteLine("Ouch! Arrow got you!");
                                winner();
                            }
                            break;

                    }
                   // System.Console.WriteLine("arrow has veered off your path");

                   // System.Console.WriteLine("The arrow is at room " + temp);
                }



            }
            if (!win)
                System.Console.WriteLine("Missed!");

            nofix = false;
            backward = -1;
        }


        public Game1()
        {
            title();
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            map1 = new Map();
            arena1 = map1.createArena();
            you = new Player(pstart);
            wump = new Wumpus(wstart);
            map1.describeMap(arena1, you, wump);
            arrows = 5;




            //System.Console.WriteLine(arena1[1].getConnect()[1]);

        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            // TODO: Add your initialization logic here

            base.Initialize();

        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);


            // TODO: use this.Content to load your game content here
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here

        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)//================================================================================================================================================================
        {
            Random random = new Random();
            //boolean step flags are console and turn
            if (step1)
            {
                if (wump.getWoke() == true)
                {
                    arena1[wump.getLocation()].hazard -= 4;
                    int moveA = wump.getLocation();
                    int moveB = arena1[wump.getLocation()].getConnect()[0];
                    int moveC = arena1[wump.getLocation()].getConnect()[1];
                    int moveD = arena1[wump.getLocation()].getConnect()[2];
                    wump.move(moveA, moveB, moveC, moveD);

                   // System.Console.WriteLine("WUMP IS AT " + wump.getLocation());
                    arena1[wump.getLocation()].hazard += 4;
                    if (arena1[you.getLocation()].hazard >= 4)
                    {
                        System.Console.WriteLine("\nTHE WUMPUS IS HERE GET AWAY BFORE THE TURN ENDS!\n");
                    }
                }
                you.detect(arena1[you.getLocation()], arena1);
                System.Console.WriteLine("You are at room " + you.getLocation());
                System.Console.WriteLine("This room connects to: " + arena1[you.getLocation()].getConnect()[0] + ", " + arena1[you.getLocation()].getConnect()[1] + ", and " + arena1[you.getLocation()].getConnect()[2]);
                System.Console.WriteLine("Shoot or Move (S - M)?");
            }
            step1 = false;
            step2 = true;
            if (step2)
            {

                my_input = System.Console.ReadLine();

                if (my_input == "M" || my_input == "m")
                {
                    System.Console.WriteLine("To where would you like to go?");
                    my_input = System.Console.ReadLine();
                    int i = 0;
                    bool check = int.TryParse(my_input, out i);
                    if (check)
                        i = Convert.ToInt32(my_input);
                    else;
                    
                    while (i != arena1[you.getLocation()].getConnect()[0] && i != arena1[you.getLocation()].getConnect()[1] && i != arena1[you.getLocation()].getConnect()[2])
                    {
                        System.Console.WriteLine("Stop trying to cheat");

                        my_input = System.Console.ReadLine();
                        i = 0;
                        bool result = int.TryParse(my_input, out i);
                        if (result)
                            i = Convert.ToInt32(my_input);
                        else
                            ;
                    }
                    //System.Console.WriteLine(i);
                    you.setLocation(i);
                    //System.Console.WriteLine(you.getLocation());

                }
                else if (my_input == "S" || my_input == "s")
                {
                    wump.wakeUp();
                    if (arrows > 0)
                    {
                        arrows -= 1;
                        System.Console.WriteLine("How many rooms? (0-5)");
                        my_input = System.Console.ReadLine();
                        int i = 10;
                        bool check = int.TryParse(my_input, out i);
                        if (check)
                            i = Convert.ToInt32(my_input);
                        else
                            i = 6;
                       

                        while (i != 0 && i != 1 && i != 2 && i != 3 && i != 4 && i != 5)
                        {
                            System.Console.WriteLine("Stop trying to cheat!");

                            my_input = System.Console.ReadLine();
                            i = 0;
                            bool result = int.TryParse(my_input, out i);
                            if (result)
                                i = Convert.ToInt32(my_input);
                            else
                                ;
                        }

                        if (i == 0)
                        {
                            System.Console.WriteLine("Ok... suit yourself. You still woke up the Wumpus and lost an arrow though");
                        }

                        else
                        {
                            bool check2;
                            int y;
                            System.Console.WriteLine("Please input the path of your arrow.");
                            int[] path = new int[i];
                            for (int p = 0; p < i; p++)
                            {
                              
                                my_input = System.Console.ReadLine();
                                check2 = int.TryParse(my_input, out y);
                                if (check2)
                                    y = Convert.ToInt32(my_input);
                                else;
                                while(check2 == false )
                                {
                                    System.Console.WriteLine("Stop trying to cheat!");
                                    my_input = System.Console.ReadLine();
                                    check2 = int.TryParse(my_input, out y);
                                    if (check2)
                                        y = Convert.ToInt32(my_input);
                                    else;
                                }
                                while (y == backward)
                                {
                                    System.Console.WriteLine("Arrows aren't that crooked - try another room");
                                    my_input = System.Console.ReadLine();
                                    y = int.Parse(my_input);
                                    y = Convert.ToInt32(my_input);
                                }

                                path[p] = y;
                                if (p > 0)
                                    backward = path[p - 1];
                            }
                            shoot(you.getLocation(), wump.getLocation(), path, arena1);// Now i need to define a path


                        }

                    }
                    else
                        System.Console.WriteLine("Out of arrows!");
                    if (win == true)
                    {
                        String input;
                        input = System.Console.ReadLine();
                        while (input != "R" && input != "r" && input != "S" && input != "s")
                        {
                            System.Console.WriteLine("nope bad input");
                            input = System.Console.ReadLine();
                        }
                        nofix = false;
                        arrows = 5;
                        if (input == "R" || input == "r")
                        {
                            wump.sleep();
                            arena1 = map1.createArena();
                            map1.describeMap(arena1, you, wump);
                        }
                        else
                        {
                            wump.sleep();
                            map1.describeMap(arena1, you, wump);
                            you.setLocation(pstart);
                            wump.setLocation(wstart);


                        }
                    }
                }
                step2 = false;
                step3 = true;
            }

            if (step3)
            {
                while (arena1[you.getLocation()].hazard == 1)
                {
                    you.bats();
                    you.setLocation(random.Next(20));
                }
                if (arena1[you.getLocation()].hazard == 2)
                {
                    you.pit();
                    String choice = you.die();
                    if (choice == "R" || choice == "r")
                    {
                        wump.sleep();
                        arena1 = map1.createArena();
                        map1.describeMap(arena1, you, wump);
                    }
                    else
                    {
                        wump.sleep();
                        map1.describeMap(arena1, you, wump);
                        you.setLocation(pstart);
                        wump.setLocation(wstart);


                    }
                    nofix = false;
                    arrows = 5;

                }
                if (arena1[you.getLocation()].hazard >= 4) // fix this
                {

                    if (wump.getWoke() == false)
                    {
                        you.wumpus(wump);
                        arena1[wump.getLocation()].hazard -= 4;
                        int moveA = wump.getLocation();
                        int moveB = arena1[wump.getLocation()].getConnect()[0];
                        int moveC = arena1[wump.getLocation()].getConnect()[1];
                        int moveD = arena1[wump.getLocation()].getConnect()[2];
                        wump.move(moveA, moveB, moveC, moveD);
                        arena1[wump.getLocation()].hazard += 4;
                        System.Console.WriteLine("WUMP IS AT " + wump.getLocation());
                        if (arena1[you.getLocation()].hazard >= 4)
                            you.wumpus(wump);
                    }
                    else if (wump.getWoke() == true)
                    {
                        String input = you.wumpus(wump);
                        if (input == "R" || input == "r")
                        {
                            wump.sleep();
                            arena1 = map1.createArena();
                            map1.describeMap(arena1, you, wump);
                        }
                        else
                        {
                            map1.describeMap(arena1, you, wump);
                            you.setLocation(pstart);
                            wump.setLocation(wstart);
                            wump.sleep();
                        }
                        nofix = false;
                        arrows = 5;
                    }
                }
                step3 = false;
                step1 = true;
            }



            base.Update(gameTime);
        }
        //==================================================================================================================================================================================================================
        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        /*protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            // TODO: Add your drawing code here

            base.Draw(gameTime);
        }*/
    }
}
