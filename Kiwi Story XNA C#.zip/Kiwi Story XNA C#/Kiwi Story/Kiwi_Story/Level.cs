﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Kiwi_Story
{
    class Level
    {
        #region Variables and properties
        public Tile[,] Tiles { get; private set; }
        public int Columns { get { return Tiles.GetLength(0); } }
        public int Rows { get { return Tiles.GetLength(1); } }
        private static Random Rnd = new Random();
        public IEnumerable<Tile> AllTiles
        {
            get
            {
                foreach (var tile in Tiles) { yield return tile; }
            }
        }
        #endregion

        public int[,] MapLayout { get; private set; }
       // public Level(SpriteBatch spritebatch, Texture2D tileTexture1, Texture2D tileTexture2, Texture2D tileTexture3, int columns, int rows)
        public Level(SpriteBatch spritebatch, Texture2D groundsheet, int columns, int rows)
        {
            Tiles = new Tile[columns, rows];
            MapLayout = new int[columns, rows];
            //Top
            for (int i = 0; i < columns; i++)
            {
                MapLayout[i, 0] = 2;
            }
            //Bottom
            for (int i = 0; i < columns; i++)
            {
                MapLayout[i, rows - 1] = 1;
            }
            //Side Walls
            for (int i = 0; i < rows; i++)
            {
                MapLayout[0, i] = 5;
                MapLayout[columns - 1, i] = 6;
            }

            //grass corners
            MapLayout[0, 0] = 17;
            MapLayout[columns-1, 0] = 16;
            MapLayout[columns-1, rows-1] = 15;
            MapLayout[0, rows-1] = 14;


            for (int i = 14; i < columns - 20; i++)
            {
                MapLayout[i, rows - 35] = 18;
            }

            for (int i = 19; i < columns - 15; i++)
            {
                MapLayout[i, rows - 31] = 18;
            }

            for (int i = 14; i < columns - 20; i++)
            {
                MapLayout[i, rows - 27] = 18;
            }

            for (int i = 19; i < columns - 15; i++)
            {
                MapLayout[i, rows - 23] = 18;
            }

            for (int i = 14; i < columns - 20; i++)
            {
                MapLayout[i, rows - 19] = 18;
            }

            for (int i = 19; i < columns - 45; i++)
            {
                MapLayout[i, rows - 15] = 18;
            }

            for (int i = 37; i < columns - 15; i++)
            {
                MapLayout[i, rows - 15] = 18;
            }
            //right edge of platforms
            MapLayout[columns - 20, rows - 35] = 21;

            MapLayout[columns - 15, rows - 31] = 21;
            MapLayout[columns - 20, rows - 27] = 21;
            MapLayout[columns - 15, rows - 23] = 21;
            MapLayout[columns - 20, rows - 19] = 21;
            MapLayout[columns - 15, rows - 15] = 21;
            MapLayout[columns - 46, rows - 15] = 21;

            //left edge of platforms
            MapLayout[14, rows - 35] = 22;
            MapLayout[19, rows - 31] = 22;
            MapLayout[14, rows - 27] = 22;
            MapLayout[19, rows - 23] = 22;
            MapLayout[14, rows - 19] = 22;
            MapLayout[19, rows - 15] = 22;
            MapLayout[37, rows - 15] = 22;

            for (int i = 1; i < columns/2 - 17; i++)
            {
                MapLayout[i, rows - 2] = 23;
            }
            for (int i = columns/2 + 17; i < columns-1; i++)
            {
                MapLayout[i, rows - 2] = 23;
            }

            //for (int i = columns/2 + 20; i < columns / 2 - 20; i++)
            //{
            //    MapLayout[i, rows - 1] = 1;
            //}

            for (int x = 0; x < columns; x++)
            {
                for (int y = 0; y < rows; y++)
                {
                   
                    int rand1 = Rnd.Next(3); //making the ground tiles random
                    int rand2 = Rnd.Next(3, 6);
                    int rand3 = Rnd.Next(8, 11);
                    int rand4 = Rnd.Next(11, 14);
                    int rand5 = Rnd.Next(18, 21);
                    int rand6 = Rnd.Next(23, 26);

                    Vector2 tilePosition = new Vector2(x * groundsheet.Width/26, y * groundsheet.Height);

                    //Every tile spot must be filled with atleast something so do this part first then give different tiles
                    Tiles[x, y] = new Tile(groundsheet, tilePosition, spritebatch, rand1, MapLayout[x, y] == 1 || MapLayout[x, y] == 2);

                    if (MapLayout[x, y] == 2) // Bottom Grass tiles
                        Tiles[x, y] = new Tile(groundsheet, tilePosition, spritebatch, rand2, MapLayout[x, y] == 2);

                    if (MapLayout[x, y] == 3) // Right side of platforms
                        Tiles[x, y] = new Tile(groundsheet, tilePosition, spritebatch, 6, MapLayout[x, y] == 3);

                    if (MapLayout[x, y] == 4) // Left side of platforms
                        Tiles[x, y] = new Tile(groundsheet, tilePosition, spritebatch, 14, MapLayout[x, y] == 4);

                    if (MapLayout[x, y] == 5) // Map Left Side
                        Tiles[x, y] = new Tile(groundsheet, tilePosition, spritebatch, rand4, MapLayout[x, y] == 5);

                    if (MapLayout[x, y] == 6) // Map Right Side
                        Tiles[x, y] = new Tile(groundsheet, tilePosition, spritebatch, rand3, MapLayout[x, y] == 6);
                    if (MapLayout[x, y] == 14) // Map Right Side
                        Tiles[x, y] = new Tile(groundsheet, tilePosition, spritebatch, 14, MapLayout[x, y] == 14);
                    if (MapLayout[x, y] == 15) // Map Right Side
                        Tiles[x, y] = new Tile(groundsheet, tilePosition, spritebatch, 15, MapLayout[x, y] == 15);
                    if (MapLayout[x, y] == 16) // Map Right Side
                        Tiles[x, y] = new Tile(groundsheet, tilePosition, spritebatch, 16, MapLayout[x, y] == 16);
                    if (MapLayout[x, y] == 17) // Map Right Side
                        Tiles[x, y] = new Tile(groundsheet, tilePosition, spritebatch, 17, MapLayout[x, y] == 17);
                    if (MapLayout[x, y] == 18) // Map Right Side
                        Tiles[x, y] = new Tile(groundsheet, tilePosition, spritebatch, rand5, MapLayout[x, y] == 18);
                    if (MapLayout[x, y] == 21) // Map Right Side
                        Tiles[x, y] = new Tile(groundsheet, tilePosition, spritebatch, 21, MapLayout[x, y] == 21);
                    if (MapLayout[x, y] == 22) // Map Right Side
                        Tiles[x, y] = new Tile(groundsheet, tilePosition, spritebatch, 22, MapLayout[x, y] == 22);
                    if (MapLayout[x, y] == 23)
                        Tiles[x, y] = new Tile(groundsheet, tilePosition, spritebatch, rand6, MapLayout[x, y] == 23);
                }
            }

        }


        public bool IsRectangleInBlockedArea(Rectangle boundingRectangleToCheck) //This is critical for determining if there is a wall in the way.
        {
            return AllTiles.Any(tile => tile.IsBlocked && tile.BoundingPortion.Intersects(boundingRectangleToCheck));
        }

        public void Draw()
        {
            foreach (var tile in Tiles)
            {
                tile.Draw();
            }
        }

        public int getTileBelow(Rectangle boundingRectangleToCheck)
        {
            foreach (Tile tile in Tiles)
            {
                if(tile.BoundingPortion.Intersects(boundingRectangleToCheck))
                {
                    return tile.getTileID();
                }
            }
            return -1;
        }

        public int getNextTile(Rectangle boundingRectangleToCheck)
        {
            foreach (Tile tile in Tiles)
            {
                if (tile.BoundingPortion.Intersects(boundingRectangleToCheck))
                {
                    return tile.getTileID();
                }
            }
            return -1;
        }
    }
}
