﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Kiwi_Story
{

    public class Sprite
    {

        #region Variables and properties

        public SpriteBatch SpriteBatch { get; protected set; }
        public Vector2 Position { get; set; }
        public Texture2D Texture { set; get; }
        public int PortionWidth;
        public int PortionHeight;
        public int WidthMod;


        public Rectangle BoundingRectangle //Things that do not have a sheet of sprites use this
        {
            get { return new Rectangle((int)(Position.X), (int)Position.Y, Texture.Width + WidthMod, Texture.Height); }
        }

        public Rectangle BoundingPortion // Things that have a sprite sheet use this. This is done to prevent collision with the whole texture when only a portion of it is actually displayed in game
        {// I also use this for the ground since I wanted to use a sheet for it
            get { return new Rectangle((int)(Position.X), (int)Position.Y, PortionWidth, PortionHeight); }
        }

        #endregion

        public Sprite(Texture2D texture, Vector2 position, SpriteBatch batch)
        {
            Texture = texture;
            Position = position;
            SpriteBatch = batch;
        }
        public Sprite(Texture2D texture, Vector2 position, SpriteBatch batch, int width, int height)
        {
            Texture = texture;
            Position = position;
            SpriteBatch = batch;
            PortionWidth = width;
            PortionHeight = height;
        }

        public bool IsRectangleInBlockedArea(Rectangle boundingRectangleToCheck) //This is critical for determining if there is a wall in the way.
        {
            return BoundingRectangle.Intersects(boundingRectangleToCheck);
        }

        public virtual void Draw()
        {
            SpriteBatch.Draw(Texture, Position, Color.White);
        }
    }
}
