﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Kiwi_Story
{
    class Sign: Gadget
    {

        public bool IsBlocked;


        public Sign(Texture2D texture, Vector2 position, SpriteBatch spriteBatch, Rectangle area, Level level1)
            : base(texture, position, spriteBatch, area, level1)
        {
            IsBlocked = true;
        }

        public bool IsRectangleInBlockedArea(Rectangle boundingRectangleToCheck) //This is critical for determining if there is a wall in the way.
        {
            return IsBlocked && base.IsRectangleInBlockedArea(boundingRectangleToCheck);
        }

        public void Update(GameTime gameTime)
        {
            base.Update(gameTime);
            if (clicked)
            {
                IsBlocked = false;
            }
            else
            {
                IsBlocked = true;
            }
        }
    }
}
