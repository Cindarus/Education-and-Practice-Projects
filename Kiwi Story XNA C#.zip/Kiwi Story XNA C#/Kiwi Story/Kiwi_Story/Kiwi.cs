﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Kiwi_Story
{
    class Kiwi : Sprite
    {

        Vector2 MovementSpeed = new Vector2(.25f, 0); //this is how fast the movement of the kiwi grows
        Vector2 FallingSpeed = new Vector2(0, .2f); //this is acceleration when falling
        float MaxSpeed = 2f; // this is max velocity 2f normal
        Rectangle sourceRect; // this is used to select a certain kiwi sprite from the sprite sheet png
        int direction = 1;// movement is multipled by direction (1 means right and -1 means left)
        Level level;
        Sign[] signs;
        Umbrella umbrella;
        Boolean hasUmbrella, dead, flag;
        Boolean firstTimeFinish = true;
        Boolean firstTimeDeath = true;
        float elapsed;
        float delay = 200f;
        int frames, deathFrames, danceframes, umbrellaTimer;
        Texture2D deathTexture;
        Vector2 Fallcheck, Turncheck;
        FinishLine finishLine;
        SoundEffect deathSound, yaySound;
    

        public Vector2 Movement { get; set; }
        public Kiwi(Texture2D texture, Texture2D deathTexture, Vector2 position, SpriteBatch spriteBatch, Level level1, FinishLine finishLine, Sign[] signs, Umbrella umbrella, SoundEffect deathSound, SoundEffect yaySound)
            : base(texture, position, spriteBatch,50,50) // Here it is making a Sprite Bounding Portion with the 50 50 instead of using the whole sheet's texture width and heigfht for collision
        {
            this.signs = signs;
            this.umbrella = umbrella;
            this.deathTexture = deathTexture;
            this.finishLine = finishLine;
            this.deathSound = deathSound;
            this.yaySound = yaySound;
            level = level1;
        }


        public void Update(GameTime gameTime)
        {
            flag = false;
            if (!dead)
            {
                if (!finishLine.IsRectangleInBlockedArea(BoundingPortion.GetCompensatedBoundingRectangle(Turncheck)))
                {
                    
                    if(level.getTileBelow(BoundingPortion.GetCompensatedBoundingRectangle(new Vector2(Position.X, Position.Y + 55))) > 22 && level.getTileBelow(BoundingPortion.GetCompensatedBoundingRectangle(new Vector2(Position.X, Position.Y + 55))) < 26)
                    {
                        dead = true;
                    }
                    //if (level.getNextTile(BoundingPortion.GetCompensatedBoundingRectangle(new Vector2(Position.X + 55, Position.Y))) > 22 && level.getTileBelow(BoundingPortion.GetCompensatedBoundingRectangle(new Vector2(Position.X + 55, Position.Y))) < 26)
                    //{
                    //    dead = true;
                    //}
                    //if (level.getNextTile(BoundingPortion.GetCompensatedBoundingRectangle(new Vector2(Position.X - 5, Position.Y))) > 22 && level.getTileBelow(BoundingPortion.GetCompensatedBoundingRectangle(new Vector2(Position.X - 5, Position.Y))) < 26)
                    //{
                    //    dead = true;
                    //}
                    if (elapsed >= delay) // frame counter which is then put into kiwi instance for determining which sprite to use.
                    {
                        if (frames >= 6)
                            frames = 0;
                        else
                            frames++;
                        elapsed = 0;

                    }
                    elapsed += (float)gameTime.ElapsedGameTime.TotalMilliseconds;

                    if (hasUmbrella)
                    {
                        FallingSpeed.Y = .1f;
                        if (Movement.X > 1.5f) //if the kiwi is moving faster than .1 then start walking to the right animation
                            sourceRect = new Rectangle((frames + 15) * 50, 0, 50, 50);
                        else if (Movement.X < -1.5f) // if less than .1 then start walking to tthe left animation
                            sourceRect = new Rectangle((frames + 22) * 50, 0, 50, 50);
                        else // else have it face the camera
                            sourceRect = new Rectangle(29 * 50, 0, 50, 50);

                        if(umbrellaTimer > 0)
                        {
                            umbrellaTimer--;
                        }
                        else
                        {
                            hasUmbrella = false;
                        }
                    }
                    else
                    {
                        if (Movement.X > 1.5f) //if the kiwi is moving faster than .1 then start walking to the right animation
                            sourceRect = new Rectangle(frames * 50, 0, 50, 50);
                        else if (Movement.X < -1.5f) // if less than .1 then start walking to the left animation
                            sourceRect = new Rectangle((frames + 7) * 50, 0, 50, 50);
                        else // else have it face the camera
                            sourceRect = new Rectangle(14 * 50, 0, 50, 50);
                    }
                    Fallcheck = new Vector2(Position.X, Position.Y + Movement.Y); //I make a position one step ahead for collision to determine the kiwi can continue falling

                    Turncheck = new Vector2(Position.X + Movement.X, Position.Y - 2); // I make a position one step ahead for collision to determine if the kiwi can continue walking

                    if (umbrella.IsRectangleInBlockedArea(BoundingPortion.GetCompensatedBoundingRectangle(Turncheck)))
                    {
                        dropItems();
                        hasUmbrella = true;
                        umbrellaTimer = 450;
                    }

                    //if you can move forward
                    foreach (Sign i in signs)
                    {
                        if (i.IsRectangleInBlockedArea(BoundingPortion.GetCompensatedBoundingRectangle(Turncheck)))
                        {
                            flag = true;
                            break;
                        }
                        
                    }
                    if (!level.IsRectangleInBlockedArea(BoundingPortion.GetCompensatedBoundingRectangle(Turncheck)) && !flag)
                    {
                        if (Movement.X < MaxSpeed && Movement.X > MaxSpeed * -1)//Move right or left
                        {
                            Movement += (MovementSpeed * direction);
                        }
                    }
                    //If you cant move forward
                    else
                    {
                        Movement = new Vector2(0, Movement.Y);
                        direction *= -1;
                    }

                    //if you aren't standing over a block then fall
                    if (!level.IsRectangleInBlockedArea(BoundingPortion.GetCompensatedBoundingRectangle(Fallcheck)))
                    {
                        Movement = new Vector2(0, Movement.Y);
                        if (hasUmbrella)
                        {
                            if (Movement.Y < MaxSpeed)
                                Movement += FallingSpeed;
                        }
                        else
                        {
                            Movement += FallingSpeed;
                        }

                    }
                    //Do not fall if on the ground
                    else
                    {
                        if (Movement.Y > 10f)
                            dead = true;
                        Movement = new Vector2(Movement.X, 0);
                    }


                    Position = Position + Movement;
                }
                else
                {
                    if (firstTimeFinish)
                    {
                        finishLine.WidthMod += 50;
                        yaySound.Play();
                        firstTimeFinish = false;
                    }
                    if (elapsed >= delay) // frame counter which is then put into kiwi instance for determining which sprite to use.
                    {
                        if (danceframes >= 18)
                            danceframes = 11;
                        else
                            danceframes++;
                        elapsed = 0;

                    }
                    elapsed += (float)gameTime.ElapsedGameTime.TotalMilliseconds;
                    sourceRect = new Rectangle(danceframes * 50, 50, 50, 50);
                }
            }
            else
            {
                if(firstTimeDeath)
                {
                    deathSound.Play();
                    firstTimeDeath = false;
                }
                if (elapsed >= delay) // frame counter which is then put into kiwi instance for determining which sprite to use.
                {
                    if (deathFrames >= 9)
                        deathFrames = 9;
                    else
                        deathFrames++;
                    elapsed = 0;

                }
                elapsed += (float)gameTime.ElapsedGameTime.TotalMilliseconds;

                base.Texture = deathTexture;
                sourceRect = new Rectangle(deathFrames * 50, 0, 50, 50);
            }
        }
        public void Draw()
        {
            SpriteBatch.Draw(Texture, Position, sourceRect, Color.White); //I overrided the sprite draw function to allow for animation with sourceRect
        }

        public Boolean checkHasItems()
        {
            return hasUmbrella;
        }

        public void dropItems()
        {
            hasUmbrella = false;
        }
    }

}
