﻿using Microsoft.Xna.Framework;


namespace Kiwi_Story //THIS IS WHERE I PUT USEFUL SIDE METHODS
{
    public static class Tools
    {
        public static Point ToPoint(this Vector2 position)
        {
            return new Point((int)position.X, (int)position.Y);
        }

        public static Vector2 ToVector2(this Point position)
        {
            return new Vector2(position.X, position.Y);
        }

        public static bool Contains(this Rectangle rectangle, Vector2 vectorToCheck)
        {
            return rectangle.Contains(vectorToCheck.ToPoint());
        }

        public static Rectangle GetCompensatedBoundingRectangle(this Rectangle boundingRectangle, Vector2 finalPosition) //this creates an invisible rectangle for determining if the next move would collide
        {
            int width = boundingRectangle.Width;
            int height = boundingRectangle.Height;
            if (finalPosition.X - ((int)finalPosition.X) != 0) { width++; }
            if (finalPosition.Y - ((int)finalPosition.Y) != 0) { height++; }
            return new Rectangle(finalPosition.ToPoint().X, finalPosition.ToPoint().Y, width, height);
        }
    }
}
