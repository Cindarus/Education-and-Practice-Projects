﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Kiwi_Story
{
    class Gadget : Sprite
    {
        Level level;
        public Rectangle area;
        public Boolean clicked;
        Texture2D texture;

        public Gadget(Texture2D texture, Vector2 position, SpriteBatch spriteBatch, Rectangle area, Level level1)
            : base(texture, position, spriteBatch)
        {
            this.texture = texture;
            this.area = area;
            level = level1;
        }

        MouseState prevState;
        public void Update(GameTime gameTime)
        {
            var mouseState = Mouse.GetState();
            var mousePosition = new Point(mouseState.X, mouseState.Y);

            if(clicked) //If clicked then center on mouse
            {
                base.Position = new Vector2(mousePosition.X-texture.Width/2, mousePosition.Y-texture.Height/2);
                area.X = (int)base.Position.X;
                area.Y = (int)base.Position.Y;
            }
            if (mouseState.LeftButton == ButtonState.Pressed && prevState.LeftButton != mouseState.LeftButton && area.Contains(mousePosition))//If they are clicking on the gadget
            {
                clicked = true;
            }
            else if(!(mouseState.LeftButton == ButtonState.Pressed))
            {
                clicked = false;
            }
            prevState = mouseState;
        }
    }
}
