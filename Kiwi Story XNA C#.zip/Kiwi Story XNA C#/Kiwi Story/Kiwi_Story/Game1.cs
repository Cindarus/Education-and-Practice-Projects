using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace Kiwi_Story
{

    public class Game1 : Microsoft.Xna.Framework.Game
    {
        #region Variables 

        GraphicsDeviceManager graphics;
        SpriteFont defaultFont;
        SpriteBatch spriteBatch;
        Rectangle mainFrame;
        Rectangle startButtonArea;
        Rectangle resetButtonArea;
        Texture2D tileTexture1;
        Texture2D tileTexture2;
        Texture2D tileTexture3;
        Texture2D groundsheet;
        Texture2D background;
        Texture2D umbrellaTexture;
        Texture2D[] tileTexture;
        Texture2D kiwiTexture;
        Texture2D kiwiDeathTexture;
        Texture2D startButtonTexture;
        Texture2D restartButtonTexture;
        Texture2D legendTexture;
        Texture2D endTexture;
        Texture2D kiwiSheet; // this is for the sprite sheet of the kiwi (0-6 walking right 7-13 walking left and 14 is facing camera)
        Level level;
        Sign[] signs = new Sign[5];
        Umbrella umbrella;
        Kiwi[] kiwis = new Kiwi[5];
        FinishLine finishLine;
        Boolean paused = true;
        public SoundEffect deathSound;
        public SoundEffect backgroundSound;
        public SoundEffect yaySound;
        float elapsed =0f; //Used to provide some time in between frames of the walking animation
        float delay = 200f; // This is the amount of time between each frame of the kiwi walking animation
        int frames = 0; // Used to tell XNA which frame to display of the walking animation
        #endregion


        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            graphics.PreferredBackBufferWidth = 1900;  // set this value to the desired width of your window
            graphics.PreferredBackBufferHeight = 1000;   // set this value to the desired height of your window
            //graphics.IsFullScreen = true;
            IsMouseVisible = true;
            graphics.ApplyChanges();
        }


        protected override void Initialize()
        {
            
            base.Initialize();
        }

        Texture2D turnAroundSignTexture;
        protected override void LoadContent()
        {
            spriteBatch = new SpriteBatch(GraphicsDevice);
            //defaultFont = Content.Load<SpriteFont>("DefaultFont");
            mainFrame = new Rectangle(0, 0, GraphicsDevice.Viewport.Width, GraphicsDevice.Viewport.Height);
            background = Content.Load<Texture2D>("background1");
            tileTexture1 = Content.Load<Texture2D>("ground1");
            tileTexture2 = Content.Load<Texture2D>("ground2");
            tileTexture3 = Content.Load<Texture2D>("ground3");
            kiwiTexture = Content.Load<Texture2D>("Kiwi");
            endTexture = Content.Load<Texture2D>("Finishline");
            turnAroundSignTexture = Content.Load<Texture2D>("turnaround");
            umbrellaTexture = Content.Load<Texture2D>("Umbrella");
            kiwiSheet = Content.Load<Texture2D>("SpriteSheet"); // KIWI walking spread sheet
            groundsheet = Content.Load<Texture2D>("biggroundsheet");
            kiwiDeathTexture = Content.Load<Texture2D>("Death");
            startButtonTexture = Content.Load<Texture2D>("PlayButton");
            restartButtonTexture = Content.Load<Texture2D>("RestartButton");
            legendTexture = Content.Load<Texture2D>("Legend");

            startButtonArea = new Rectangle(50, 50, startButtonTexture.Width, startButtonTexture.Height);
            resetButtonArea = new Rectangle(100 + startButtonTexture.Width, 50, restartButtonTexture.Width, restartButtonTexture.Height);

            deathSound = Content.Load<SoundEffect>("RSHIT");
            backgroundSound = Content.Load<SoundEffect>("A_Kiwi_StoryLOOP");
            yaySound = Content.Load<SoundEffect>("YAY");

            CreateMap();
        }

        private void CreateMap()
        {
            level = new Level(spriteBatch, groundsheet, 76, 40);
            for(int i = 0; i < signs.Length; i++)
            {
                signs[i] = new Sign(turnAroundSignTexture, new Vector2(50 + i*25, 200), spriteBatch, new Rectangle(50 + i*25, 200, turnAroundSignTexture.Width, turnAroundSignTexture.Height), level);
            }
            umbrella = new Umbrella(umbrellaTexture, new Vector2(50, 150), spriteBatch, new Rectangle(50, 150, umbrellaTexture.Width, umbrellaTexture.Height), level);
            finishLine = new FinishLine(endTexture, new Vector2(600, 925), spriteBatch, new Rectangle(50, 150, turnAroundSignTexture.Width, turnAroundSignTexture.Height), level);
        }

        protected override void UnloadContent()
        {

        }


        Boolean kiwi0created, kiwi1created, kiwi2created, kiwi3created, kiwi4created;
        protected override void Update(GameTime gameTime)
        {
            //Loop background music
            if(gameTime.TotalGameTime.TotalMilliseconds % backgroundSound.Duration.TotalMilliseconds < gameTime.ElapsedGameTime.TotalMilliseconds)
                backgroundSound.Play(0.1f,0f,0f);

            // Allows the game to exit
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                this.Exit();

            var mouseState = Mouse.GetState();
            var mousePosition = new Point(mouseState.X, mouseState.Y);
            
            //Check if they have clicked any of the signs
            if (mouseState.LeftButton == ButtonState.Pressed && startButtonArea.Contains(mousePosition))
            {
                paused = false;
            }
            if (mouseState.LeftButton == ButtonState.Pressed && resetButtonArea.Contains(mousePosition))
            {
                paused = true;
                for (int i = 0; i < kiwis.Length; i++)
                {
                    kiwis[i] = null;
                }
                kiwi0created = false;
                kiwi1created = false;
                kiwi2created = false;
                kiwi3created = false;
                kiwi4created = false;
                elapsed = 0;
            }

            if (!paused)
            {
                elapsed += (float)gameTime.ElapsedGameTime.TotalSeconds;
                foreach (Kiwi i in kiwis)
                {
                    if (i != null)
                        i.Update(gameTime); // added frames to the update of the kiwi for the walking animation
                }
                if (!kiwi0created)
                {
                    kiwis[0] = new Kiwi(kiwiSheet, kiwiDeathTexture, new Vector2(450, 50), spriteBatch, level, finishLine, signs, umbrella, deathSound, yaySound);
                    kiwi0created = true;
                }
                if (elapsed > 2 && !kiwi1created)
                {
                    kiwis[1] = new Kiwi(kiwiSheet, kiwiDeathTexture, new Vector2(450, 50), spriteBatch, level, finishLine, signs, umbrella, deathSound, yaySound);
                    kiwi1created = true;
                    System.Console.WriteLine("Second Kiwi Created");
                }
                if (elapsed > 4 && !kiwi2created)
                {
                    kiwis[2] = new Kiwi(kiwiSheet, kiwiDeathTexture, new Vector2(450, 50), spriteBatch, level, finishLine, signs, umbrella, deathSound, yaySound);
                    kiwi2created = true;
                }
                if (elapsed > 6 && !kiwi3created)
                {
                    kiwis[3] = new Kiwi(kiwiSheet, kiwiDeathTexture, new Vector2(450, 50), spriteBatch, level, finishLine, signs, umbrella, deathSound, yaySound);
                    kiwi3created = true;
                    System.Console.WriteLine("Second Kiwi Created");
                }
                if (elapsed > 8 && !kiwi4created)
                {
                    kiwis[4] = new Kiwi(kiwiSheet, kiwiDeathTexture, new Vector2(450, 50), spriteBatch, level, finishLine, signs, umbrella, deathSound, yaySound);
                    kiwi4created = true;
                }
            }
            else
            {
                foreach (Sign i in signs)
                {
                    i.Update(gameTime);
                }
                umbrella.Update(gameTime);
            }
            
            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.SkyBlue);
            spriteBatch.Begin();
            spriteBatch.Draw(background, mainFrame, Color.White);
            level.Draw();
            spriteBatch.Draw(startButtonTexture, startButtonArea, Color.White);
            spriteBatch.Draw(restartButtonTexture, resetButtonArea, Color.White);
            spriteBatch.Draw(legendTexture, new Rectangle(1900-legendTexture.Width-groundsheet.Height, groundsheet.Height,legendTexture.Width,legendTexture.Height), Color.White);

            foreach (Sign i in signs)
            {
                i.Draw();
            }
            umbrella.Draw();
            foreach (Kiwi i in kiwis)
            {
                if(i != null)
                    i.Draw();
            }
            finishLine.Draw();
            
            spriteBatch.End();
            
            base.Draw(gameTime);
        }
    }
}
