﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace Kiwi_Story
{
    class FinishLine : Gadget
    {
        public FinishLine(Texture2D texture, Vector2 position, SpriteBatch spriteBatch, Rectangle area, Level level1)
            : base(texture, position, spriteBatch, area, level1)
        {

        }
    }
}
