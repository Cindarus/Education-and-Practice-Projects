﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace Kiwi_Story
{
    public class Tile : Sprite
    {

        public bool IsBlocked;
        int tileID;

        public Tile(Texture2D texture, Vector2 position, SpriteBatch spritebatch, int tileID, bool blocked = false)
            : base(texture, position, spritebatch,25,25)
        {
            IsBlocked = blocked;
            this.tileID = tileID;
        }

        public int getTileID()
        {
            return tileID;
        }

        public override void Draw()
        {
            if (IsBlocked)
            {
                //base.Draw();
                SpriteBatch.Draw(Texture, Position, new Rectangle(25 * tileID, 0, 25, 25), Color.White);
            }
        }
    }
}
