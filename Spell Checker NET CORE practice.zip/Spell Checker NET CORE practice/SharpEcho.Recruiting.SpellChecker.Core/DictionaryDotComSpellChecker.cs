﻿
using System;
using System.Net;
using System.Security.Policy;
using SharpEcho.Recruiting.SpellChecker.Contracts;


namespace SharpEcho.Recruiting.SpellChecker.Core
{
    /// <summary>
    /// This is a dictionary based spell checker that uses dictionary.com to determine if
    /// a word is spelled correctly
    /// 
    /// The URL to do this looks like this: http://dictionary.reference.com/browse/<word>
    /// where <word> is the word to be checked
    /// 
    /// Example: http://dictionary.reference.com/browse/SharpEcho would lookup the word SharpEcho
    /// 
    /// We look for something in the response that gives us a clear indication whether the
    /// word is spelled correctly or not
    /// </summary>
    /// 
    public class DictionaryDotComSpellChecker : ISpellChecker
    {
        public bool Check(string word)
        {
            ServicePointManager.Expect100Continue = true;
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
            try
            {
                // Creates an HttpWebRequest for the specified URL.
                HttpWebRequest myHttpWebRequest = HttpWebRequest.CreateHttp("http://dictionary.reference.com/browse/" + word);
                myHttpWebRequest.Credentials = CredentialCache.DefaultCredentials;
                // Sends the HttpWebRequest and waits for a response.
                HttpWebResponse myHttpWebResponse = (HttpWebResponse)myHttpWebRequest.GetResponse();
                if (myHttpWebResponse.StatusCode == HttpStatusCode.OK)
                {
                    //Console.WriteLine("\r\n" + word + " is a word found on Dictionary.com");
                    myHttpWebResponse.Close();
                    return true;
                }// Releases the resources of the response.

            }
            catch (WebException e)
            {
                //Console.WriteLine(""+word+" could not be found from dictionary.com");
                return false;

            }

            //Console.WriteLine("Dictionary Website Check:-");

            //throw new System.NotImplementedException();
            return true;
        }
    }
}
