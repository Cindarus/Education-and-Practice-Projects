import java.util.Scanner;

public class Testing {

	
	public static void main(String[] args) {
        
        VendingMachine a = new VendingMachine();
        
        Scanner tanner= new Scanner(System.in);
        int input;
        boolean go0 = true;
        
        
       while(go0) {
    	    boolean go1 = true;
            boolean go2 = true;
	        a.status();
	        System.out.println("\nInput one of the following commands:\n1 - Insert Money\n2 - Select Item\n3 - Refund Button");
	        input = tanner.nextInt();
	        if(input == 1){
	        	while(go1) {
		        	System.out.println("1 - Dollar\n2 - Quarter\n3 - Dime\n4 - Nickel\n5 - Penny\n6 - Back");
		        	input = tanner.nextInt();
		        	if(input > 5)
		        		go1 = false;
		        	if(input == 1)
		        		a.add(moneyItems.DOLLAR);
		        	if(input == 2)
		        		a.add(moneyItems.QUARTER);
		        	if(input == 3)
		        		a.add(moneyItems.DIME);
		        	if(input == 4)
		        		a.add(moneyItems.NICKEL);
		        	if(input == 5)
		        		a.add(moneyItems.PENNY);
		        	}
		     }
	        
	        if(input == 2){
	        	while(go2) {
		        	System.out.println("1 - Water\n2 - Soda\n3 - EnergyDrink\n4 - Cookies\n5 - Chips\n6 - Candy\n7 - Back");
		        	input = tanner.nextInt();
		        	if(input == 1) {
		        		System.out.println(a.purchase(vendingItems.WATER));
		        		go2= false;
		        		input =0;
		        	}
		        	if(input == 2) {
		        		System.out.println(a.purchase(vendingItems.SODA));
		        		go2= false;
		        		input =0;
		        	}
		        	if(input == 3) {
		        		System.out.println(a.purchase(vendingItems.ENERGYDRINK));
		        		go2= false;
		        		input =0;
		        	}
		        	if(input == 4) {
		        		System.out.println(a.purchase(vendingItems.COOKIES));
		        		go2= false;
		        		input =0;
		        	}
		        	if(input == 5) {
		        		System.out.println(a.purchase(vendingItems.CHIPS));
		        		go2= false;
		        		input =0;
		        	}
		        	if(input == 6) {
		        		System.out.println(a.purchase(vendingItems.CANDY));
		        		go2= false;
		        		input =0;
		        	}
		        	if(input >6) {
		        		System.out.println(a.purchase(vendingItems.WATER));
		        		go2= false;
		        		input =0;
		        	}
	        	}
	        }
	        
	        if(input == 3) {
	        	System.out.println(a.moneyReturn(a.balance));
	        	System.out.println("Type anything to continue...");
	        	tanner.next();
	        	input =0;
	        }
		}
	}

}
