import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class VendingMachine {
	private Stock<moneyItems> money = new Stock<moneyItems>();
	private Stock<vendingItems> items = new Stock<vendingItems>();
	long balance;
	
	Scanner tanner2= new Scanner(System.in);
	String input = "";
	
	public VendingMachine() {
	
		for(vendingItems i : vendingItems.values())
			items.stockUp(i,5);
		for(moneyItems i : moneyItems.values())
			money.stockUp(i,10);
	}
	
	public void status() {
		System.out.println("Stock has : ");
		for (moneyItems i : moneyItems.values())
			System.out.print(money.getQuantity(i) + " " + i.getName() + "|");
		System.out.println();
		for (vendingItems i : vendingItems.values())
			System.out.print(items.getQuantity(i) + " " + i.getName() + "("+i.getPrice() +"c)"+"|");
		System.out.println("\nMoney Inputted = " + balance + " cents");
	}
	
	
	public void add(moneyItems input) {
        balance = balance + input.getValue();
        money.add(input);
    }
	
	
//moneyReturn will be used to provide a list of all the coins which are returned to the customer

	List<moneyItems> moneyReturn(long balance){
		
		int doUsed=0;
		int qUsed=0;
		int diUsed=0;
		int nUsed=0;
		int pUsed=0;
		boolean dollars=true;
		boolean quarters=true;
		boolean dimes=true;
		boolean nickels=true;
		boolean pennies=true;
		
		List<moneyItems> list = Collections.EMPTY_LIST;
		
		
		if(balance > 0) {
			list = new ArrayList<moneyItems>();
			long remainder = balance;
			while(remainder > 0) {
				
				//Give change in DOLLARS?
				if (remainder>= moneyItems.DOLLAR.getValue() && dollars) {
					if(money.getQuantity(moneyItems.DOLLAR)-doUsed>0) {
						doUsed++;
						list.add(moneyItems.DOLLAR);
						remainder = remainder - moneyItems.DOLLAR.getValue();
						//money.sub(moneyItems.DOLLAR);
						continue;
					}
					else
						dollars = false;		
				}
				
				//Give chgange in QUARTERS?
				if (remainder>= moneyItems.QUARTER.getValue() && quarters) {
					if(money.getQuantity(moneyItems.QUARTER)-qUsed>0) {
						qUsed++;
						list.add(moneyItems.QUARTER);
						remainder = remainder - moneyItems.QUARTER.getValue();
						//money.sub(moneyItems.QUARTER);
						continue;
					}
					else
						quarters = false;		
				}
				
				//Give change in DIMES?
				if (remainder>= moneyItems.DIME.getValue() && dimes) {
					if(money.getQuantity(moneyItems.DIME)-diUsed>0) {
						diUsed++;
						list.add(moneyItems.DIME);
						remainder = remainder - moneyItems.DIME.getValue();
						//money.sub(moneyItems.DIME);
						continue;
					}
					else
						dimes = false;		
				}
				
				if (remainder>= moneyItems.NICKEL.getValue() && nickels) {
					if(money.getQuantity(moneyItems.NICKEL)-nUsed>0) {
						nUsed++;
						list.add(moneyItems.NICKEL);
						remainder = remainder - moneyItems.NICKEL.getValue();
						//money.sub(moneyItems.NICKEL);
						continue;
					}
					else
						nickels = false;		
				}
				
				if (remainder>= moneyItems.PENNY.getValue() && pennies) {
					if(money.getQuantity(moneyItems.PENNY)-pUsed>0) {
						pUsed++;
						list.add(moneyItems.PENNY);
						remainder = remainder - moneyItems.PENNY.getValue();
						//money.sub(moneyItems.PENNY);
						continue;
					}
					else {
						pennies = false;
						System.out.println("Insufficient Change in machine, try selecting another product.");	
						break;
					}
				
				}
				
				
			}
			if(pennies)
				for(moneyItems i: list)
				{
					money.sub(i);
					this.balance -= i.getValue();
				}	
			
		}
		return list;
	}
	
	
	List<moneyItems> purchase(vendingItems a) {
		long orig = balance;
		//if you have enough money in vending machine for change and the inputted money is enough for purchase. subtract the appropriate vendingItems and moneyItems
		if (balance - a.getPrice()>=0 && items.getQuantity(a)>0 ) { //if price of item is less than total inputted
			//I need to subtract coins from machine for change
			//I need to subtract an item from the machine
			int sum=0;
			
			List<moneyItems> list = moneyReturn(balance - a.getPrice()); // return money of difference to customer if appropriate change was available,
			for(moneyItems i: list)
			{
				
				sum+=i.getValue(); // sum of change that was returned if it was enough.
			}
			
			if((orig - sum==a.getPrice())) {
				items.sub(a);
				balance-=a.getPrice();
				System.out.println("Type anything to receive change...");
				tanner2.next();
				System.out.println(a.getName()+" dropped. Enjoy!");
				System.out.println("Money returned to customer-:");
				return list;
			}
			return Collections.EMPTY_LIST;
		}
		System.out.println("Insufficient funds or no item available.");
		return Collections.EMPTY_LIST;
		
	}
	
	
}

//STOCK CLASS USED FOR ALL TYPES OF ITEMS (MONEY AND VENDING ITEMS)
//
//
class Stock<T> {
	
	private Map<T, Integer> stock = new HashMap<T, Integer>();
	
	public int getQuantity(T item) {
		Integer value = stock.get(item);
		if(value == null)
			return 0;
		else 
			return value;
	}
	
	//add an item
	public void add(T item) {
		stock.put(item,stock.get(item)+1);
	}
	
	//subtract an item
	public void sub(T item) {
		stock.put(item,stock.get(item)-1);
	}
	
	//adds a multitude of an item.
	public void stockUp(T item, int q) {
		stock.put(item, q);
	}
}

//vendingItems are things within the Vending Machine they have a name and value.
//Integer value associated is the price in cents
//
enum vendingItems{
	WATER("Water", 100), SODA("Soda", 75), ENERGYDRINK("Energy Drink", 200), COOKIES("Cookies", 75), CHIPS("Chips", 100), CANDY("Candy", 50);
	
	private String name;
	private int value;
	
	private vendingItems(String name, int value) {
		this.name = name;
		this.value = value;
	}
	
	
	int getPrice() {
		return value;
	}
	
	String getName() {
		return name;
	}	
}

//moneyItems are the types of currency that the vending machine accepts
//each item has a name and a value
//
enum moneyItems{
	DOLLAR("Dollar", 100), QUARTER("Quarter", 25), DIME("Dime", 10), NICKEL("Nickel", 5), PENNY("Penny", 1);
	
	private String name;
	private int value;
	
	private moneyItems(String name, int value) {
		this.name = name;
		this.value = value;
	}
	
	
	int getValue() {
		return value;
	}
	
	String getName() {
		return name;
	}	
}
