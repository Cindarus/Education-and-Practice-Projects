To compile type 

javac Project3.java

to run type:

java Project3 jobs.txt