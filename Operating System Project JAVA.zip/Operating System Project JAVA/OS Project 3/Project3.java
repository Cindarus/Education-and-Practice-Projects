//////////////
//GRANT BARRATT
//15 April 2017
//OZBIRN
//OS CONCEPTS 
//////////////


import java.io.*;
import java.util.*;

public class Project3 
{
	
	//SETTING GLOBAL VARIABLES
	public static int totalTime= 0; // used for spacing of output
	public static int quantum = 1;
	public static int maxTime = 0;

	public ArrayList<Job> inputJobs(String file)
	{
		ArrayList<Job> input = new ArrayList<Job>();
		try{
			int minArrival = 100;
			
			   Scanner scanner = new Scanner(new File(file));
			   while(scanner.hasNextLine())
			   {
				    String name = scanner.next();
				    int arrivalTime = scanner.nextInt();
				    int executeTime = scanner.nextInt();
				    maxTime += executeTime;
				    if (arrivalTime<minArrival)
				    	minArrival = arrivalTime;
				    Job jobs = new Job(name, arrivalTime, executeTime);
				    input.add(jobs);
			   }
			   scanner.close();
			   maxTime += minArrival;
		}
		catch(FileNotFoundException t)
		{
			System.out.println("File Not Found");
			System.exit(0);
		}
		
		return input;
	}
	
	// Job class which there is an arraylist of 
	private class Job
	{
		public String name;
		public int arrivalTime;
		public int executionTime;
		public int remaining;
		public boolean newArrival = true;
		public boolean newArrival2 = true;
		public boolean newArrival3 = true;
		public String jobSpace = "";
		public int difference = 0; 
		public int lastEntry = 0;
		public boolean viable =false;
		//public int timeWaiting = 0;
		
		
		public Job(String job, int aTime, int eTime)
		{
			name = job;
			arrivalTime=aTime;
			executionTime = eTime;
			remaining = eTime;
		}
		
		
		public String toString()
		{
			String a = "Name = " + name + " ETime " + executionTime + " ATime " + arrivalTime;
			return a;
		}
		
		public int runSlice(int t) //Run a specified quantum
		{
			int timeSpent=0;
			int time =t;
			while(time != 0 && remaining != 0)
			{
				
				time--;
				remaining--;
				timeSpent++;
				++totalTime;
				difference = totalTime-lastEntry;
				for (int i=0; i <difference-1; ++i)
				{
					jobSpace += " ";
				}
				jobSpace = jobSpace +name;
				lastEntry= totalTime;
				//System.out.print(name);
				
			}
			return timeSpent;
		}
		
		public int runCompletion() //RUN THE WHOLE THING
		{
			//for(int i = 0 ; i < totalTime; i++)
			//System.out.print(" ");
			return runSlice(remaining);
		}
		public String print()
		{
			return jobSpace;
		}
	}
	
	public static class RR // ROUND ROBIN
	{
		ArrayList<Job> jobs;
		int time =0;
		//int quantumSize=0;
		
		public RR(ArrayList<Job> a)
		{
			jobs = a;
		}
		
		
		
		void run() // NEW ARRIVAL HAS HIGH PRIORITY AND THEN CYCLING AMONG JOBS
		{
			Queue<Job>jobQueue = new LinkedList<Job>();
			
			for(int i = 0; i < maxTime; i+=quantum)
			{
				//System.out.println(maxTime);
				boolean work = false;
				for(int x  = 0; x  < jobs.size(); x++)
				{
					if(jobs.get(x).newArrival && time>=jobs.get(x).arrivalTime && jobs.get(x).remaining != 0 )
					{
						//System.out.println(x);
						work= true;
						//System.out.println();
						if(!jobQueue.contains(jobs.get(x)))
						jobQueue.add(jobs.get(x));
						jobs.get(x).newArrival = false;
					}
				}
				for(int x  = 0; x  < jobs.size(); x++)
				{
					if(time>jobs.get(x).arrivalTime && jobs.get(x).remaining != 0)
					{
						//System.out.println(x);
						work= true;
						//System.out.println();
						if(!jobQueue.contains(jobs.get(x)))
						jobQueue.add(jobs.get(x));
					}
					
				}
				//
				if(work == false)
				{
					time+=quantum;
					totalTime+=quantum;
				}
				if(jobQueue.size() != 0)
				{
				jobQueue.remove().runSlice(quantum);
				time+=quantum;
				//System.out.println();
				}
				//System.out.println();
				
			}
			for(int x  = 0; x  < jobs.size(); x++)
			{
				System.out.println(jobs.get(x).print());
			}
		}
	
	}
	
	
	public static class FCFS // FIRST COME FIRST SERVE, MAKES USE OF THE RUN COMPLETION
	{
		ArrayList<Job> jobs;
		int time =0;
		
		public FCFS(ArrayList<Job> a)
		{
			jobs = a;
		}
		
		void run()
		{
			
			for(int i = 0; i < jobs.size(); ++i)
			{
				
				boolean work = false;
				for(int x  = 0; x  < jobs.size(); x++)
				{
					//System.out.println(jobs.get(x).arrivalTime);
					if(time>=jobs.get(x).arrivalTime && jobs.get(x).remaining != 0)
					{
						
						//System.out.println(time + " should be more than " + jobs.get(x).arrivalTime);
						work= true;
						jobs.get(x).runCompletion();
						//System.out.println();
						time+=jobs.get(x).executionTime;
					}
				}
			if(work==false)
				{
				//i--;
				time++;
				totalTime++;
				}	
			}
			for(int x  = 0; x  < jobs.size(); x++)
			{
				System.out.println(jobs.get(x).print());
			}
		}
		
	}
	
	public static class SPN extends FCFS // SHORT PROCESS NEXT, checks if something is available then if it has the lowest execution time 

	{
		int minimumViable = 100;
		int nextIndex = 0;
		public SPN (ArrayList<Job> a)
		{
			super(a);
		}
		
		
		
		
		void viable(int x)
		{
			if(time>=jobs.get(x).arrivalTime && jobs.get(x).remaining != 0)
				jobs.get(x).viable = true;
			else
				jobs.get(x).viable = false;
		}
		
		void run()
		{
			
			for(int i = 0; i < 5; ++i)
			{	
				minimumViable =100;
				for(int x  = 0; x  < jobs.size(); x++)
				{
					viable(x);
					//System.out.println(jobs.get(x).viable);
				}
				
				for(int y  = 0; y  < jobs.size(); y++)
				{
					//System.out.println(jobs.get(y).viable);
					if (jobs.get(y).viable && jobs.get(y).executionTime < minimumViable)
						{
						minimumViable = jobs.get(y).executionTime;
						nextIndex = y;
						}
				}
				
				//work= true;
				jobs.get(nextIndex).runCompletion();
				jobs.get(nextIndex).viable = false;
				//System.out.println();
				time+=jobs.get(nextIndex).executionTime;
				
			
						
				
			/*if(work==false)
				{
				//i--;
				time++;
				totalTime++;
				}	*/
			}
			for(int x  = 0; x  < jobs.size(); x++)
			{
				System.out.println(jobs.get(x).print());
			}
		}
	}
	
	public static class SRT extends SPN // This is like SRT but looks at the remaining time rather than total execution time
	{
		public SRT (ArrayList<Job> a)
		{
			super(a);
		}
		
		void run()
		{

			for(int i = 0; i < maxTime; ++i)
			{	
				minimumViable =100;
				for(int x  = 0; x  < jobs.size(); x++)
				{
					viable(x);
					//System.out.println(jobs.get(x).viable);
				}
				
				for(int y  = 0; y  < jobs.size(); y++)
				{
					//System.out.println(jobs.get(y).viable);
					if (jobs.get(y).viable && jobs.get(y).remaining < minimumViable)
						{
						minimumViable = jobs.get(y).remaining;
						nextIndex = y;
						}
				}
				
				//work= true;
				//jobs.get(nextIndex).runCompletion();
				jobs.get(nextIndex).runSlice(1);
				jobs.get(nextIndex).viable = false;
				//System.out.println();
				time+=1;
				
			
						
				
			/*if(work==false)
				{
				//i--;
				time++;
				totalTime++;
				}	*/
			}
			for(int x  = 0; x  < jobs.size(); x++)
			{
				System.out.println(jobs.get(x).print());
			}
		}
	}

	
	public static class HRRN extends SPN // Highest response ratio next, like the others but instead of looking at a exec time or remaining time it looks for which job is viable and has the highest response ratio
	{
		
		
		public HRRN (ArrayList<Job> a)
		{
			super(a);
		}
		
		
		int response(int y)
		{
			int r = (((time - jobs.get(y).arrivalTime)+jobs.get(y).executionTime)/jobs.get(y).executionTime);
			return r;
		}
		
		void run()
		{

			for(int i = 0; i < maxTime; ++i)
			{	
				int largestViable = 0;
				for(int x  = 0; x  < jobs.size(); x++)
				{
					viable(x);
				//	System.out.println(jobs.get(x).viable);
				}
				
				for(int y  = 0; y  < jobs.size(); y++)
				{
					//System.out.println(jobs.get(y).viable);
					if (jobs.get(y).viable && (response(y) > largestViable))
						{
						largestViable = response(y);
						nextIndex = y;
						}
				}
				
				//work= true;
				//jobs.get(nextIndex).runCompletion();
				jobs.get(nextIndex).runSlice(1);
				jobs.get(nextIndex).viable = false;
				//System.out.println();
				time+=1;
				
			
						
				
			/*if(work==false)
				{
				//i--;
				time++;
				totalTime++;
				}	*/
			}
			for(int x  = 0; x  < jobs.size(); x++)
			{
				System.out.println(jobs.get(x).print());
			}
		}
	}
	
	public static class FEEDBACK extends SPN
	{
		public FEEDBACK (ArrayList<Job> a)
		{
			super(a);
		}
		
		void run()
		{
			Queue<Job>jobQueue1 = new LinkedList<Job>();
			Queue<Job>jobQueue2 = new LinkedList<Job>();
			Queue<Job>jobQueue3 = new LinkedList<Job>();
			Job latest = null;
			
			
			for(int i = 0; i < maxTime; i+=1)
			{
				for(int x  = 0; x  < jobs.size(); x++)
				{
					if(!jobs.get(x).equals(latest))
					{
					if(jobs.get(x).newArrival && time>=jobs.get(x).arrivalTime && jobs.get(x).remaining != 0 )
					{
						//System.out.println( x + "atest");
						jobQueue1.add(jobs.get(x));
						jobs.get(x).newArrival = false;
						break;
					}
					
					}
				}

				if(latest != null && latest.remaining !=0){
				if(latest.newArrival == false && latest.newArrival2 == true && latest.newArrival3 == true&& time>=latest.arrivalTime && latest.remaining != 0)
				{
					jobQueue1.add(latest);
					
				}
				else if(latest.newArrival2 && time>=latest.arrivalTime && latest.remaining != 0 && latest.newArrival == false)
				{
				//	System.out.println( x + "btest");
					jobQueue2.add(latest);
					latest.newArrival2 = false;
					
				}
				else if(latest.newArrival2 == false && latest.newArrival3 == true && time>=latest.arrivalTime && latest.remaining != 0)
				{
					jobQueue2.add(latest);
					
				}
				else if(latest.newArrival3 && time>=latest.arrivalTime && latest.remaining != 0 && latest.newArrival == false && latest.newArrival2 == false)
				{
				//	System.out.println( x + "ctest");
					jobQueue3.add(latest);
					latest.newArrival3 = false;
					
				}
				else if(time>=latest.arrivalTime && latest.remaining != 0)
				{
				//	System.out.println( x + "dtest");
					jobQueue3.add(latest);
					
				}
				
				}
					
					if(jobQueue1.size() != 0)
					{
					latest = jobQueue1.remove();
					latest.runSlice(1);
					time+=1;
					
					}

					else if(jobQueue2.size() != 0)
					{
						latest = jobQueue2.remove();
						latest.runSlice(1);
						time+=1;
					}
					
					else if(jobQueue3.size() != 0)
					{
						latest = jobQueue3.remove();
						latest.runSlice(1);
						time+=1;
					}
					


					
					
					
					
				
				
			
			}
			for(int x  = 0; x  < jobs.size(); x++)
			{
				System.out.println(jobs.get(x).print());
			}
		}
	}
	
	public static void main(String args[])
	{
		String response="";
	
		Project3 a = new Project3();
		ArrayList<Job> temp = a.inputJobs(args[0]);
		ArrayList<Job> temp1 = a.inputJobs(args[0]);
		ArrayList<Job> temp2 = a.inputJobs(args[0]);
		ArrayList<Job> temp3 = a.inputJobs(args[0]);
		ArrayList<Job> temp4 = a.inputJobs(args[0]);
		ArrayList<Job> temp5 = a.inputJobs(args[0]);
		ArrayList<Job> temp6 = a.inputJobs(args[0]);
		
		System.out.println("Which scheduling system would you like to use?");
		System.out.println("1) First Come First Serve \n2) Round Robin\n3) Short Process Next\n4) Short Remaining Time\n5) Highest Response Ratio Next \n6) Feedback\n7) ALL");
		Scanner tanner = new Scanner(System.in);
		response = tanner.next();
		switch(response){
		case "1":
			System.out.println("FCFS\n");
			FCFS test = new FCFS(temp);
			test.run();
			break;
			
		case "2":
			System.out.println("RR\n\n");
			System.out.println("Input quantum value:");
			quantum = tanner.nextInt();
			RR test1 = new RR(temp);
			test1.run();
			break;
			
		case "3":
			System.out.println("SPN\n");
			SPN test2 = new SPN(temp);
			test2.run();
			
			break;
			
		case "4":
			System.out.println("SRT\n");
			SPN test3 = new SRT(temp);
			test3.run();
			
			break;
			
		case "5":
			System.out.println("HRRN\n");
			HRRN test4 = new HRRN(temp);
			test4.run();
			
			break;
			
		case "6":
			System.out.println("FEEDBACK\n");
			FEEDBACK test5 = new FEEDBACK(temp);
			test5.run();
			
			break;
		case "7":
			System.out.println("ALL\n");
			System.out.println("FCFS\n");
			FCFS test6 = new FCFS(temp1);
			test6.run();
			totalTime = 0;
			System.out.println("RR\n\n");
			System.out.println("Input quantum value for RR:");
			quantum = tanner.nextInt();
			RR test7 = new RR(temp2);
			test7.run();
			totalTime = 0;
			System.out.println("SPN\n");
			SPN test8 = new SPN(temp3);
			test8.run();
			totalTime = 0;
			System.out.println("SRT\n");
			SPN test9 = new SRT(temp4);
			test9.run();
			totalTime = 0;
			System.out.println("HRRN\n");
			HRRN test10 = new HRRN(temp5);
			test10.run();
			totalTime = 0;
			System.out.println("FEEDBACK\n");
			FEEDBACK test11 = new FEEDBACK(temp6);
			test11.run();
			break;
		}
		
		/*Iterator<Job> butts = temp.iterator();
		
		while(butts.hasNext())
		{
			System.out.println(butts.next().toString());
		}
		*/
		
		
	}
	
}
	
