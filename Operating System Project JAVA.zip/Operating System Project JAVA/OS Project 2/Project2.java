//////////////////////////////
//GRANT BARRATT
//OZBIRN
//OS CONCEPTS
//MARCH 25 2017
//////////////////////////////


import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.Semaphore;
import java.io.FileNotFoundException;

public class Project2
{

	//Global Variables
	static String tasks[] = {"buy stamps","mail a letter","mail a package"}; //these will be associated with a random int 0-2 for necessary print statements
	static int currentCustomer;		//This is used to transfer customer id to the worker
	static int currentTask;			//This is used to transfer customer's task to the worker
	static boolean running = true;	//This is used to terminate the while loops in threads
	static int currentWorker;
	
	
	//Semaphores
	
	static Semaphore ask = new Semaphore (0,true);				//In the middle of the run function of worker, customer needs to ask for something
	static Semaphore doTask = new Semaphore (0,true);			//Once the customer is asked he needs to start doing action again
	static Semaphore max_capacity = new Semaphore (10,true); 	//max amount of customers in post office at a time
	static Semaphore mutexA = new Semaphore (1,true);			//ensures that mutual exclusion is observed between customers when transferring id and task to postal worker
	//static Semaphore worker = new Semaphore (3,true);			
	static Semaphore scale = new Semaphore (1,true);			//ensures only one worker is using scale at a time
	// boolean flag = 0;
	static Semaphore mutexB = new Semaphore (1,true);			
	static Semaphore[] finished = new Semaphore[50];			//conveys to customer that worker is done serving
	static
	{
		for (int i =0; i<50; i++)
		finished[i] = new Semaphore(0,true);
	}
	static Semaphore cust_ready = new Semaphore (0,true);		//used to convey to worker thread that customer is awaiting to be served
	/*static Semaphore[] test = new Semaphore [50];
	for(int i =0; i < 50; i++)
	{
	test[i] = new Semaphore(5);
	}*/
	
	static Random rand = new Random();							//Used for task selection


	public static void main(String[] args)
	{
		
		// initialize the 50 customer and 3 worker threads
		Thread pcustomers[] = new Thread[50];					//Make a thread for each customer as specified by requirements
		for(int i = 0; i<50;i++)
		{
			pcustomers[i] = new Thread(new Customer(i));		
		}
		
		Thread postalWorker[] =									//Make three threads for postal workers
			{ new Thread(new PostalWorker(0)),
			 new Thread(new PostalWorker(1)),
			 new Thread(new PostalWorker(2))};
		
		// Starting postalworkers then customers
		postalWorker[0].start();								//Start the postal workers first
		
		postalWorker[1].start();
		//System.out.println("Postal worker " + 1 + " created");
		postalWorker[2].start();
		//System.out.println("Postal worker " + 2 + " created");
		for (int i=0; i<50; i++)
			pcustomers[i].start();
		
		
		for(int i=0; i<50; i++)									//Start the customers
		{
			try
			{
				pcustomers[i].join();
				System.out.println("Joined customer " + i);
			}
			catch(InterruptedException e)
			{
				e.printStackTrace();
			}
		}
		running=false;											//Stop the threads from running and exit
		System.exit(0);
		
		//postalWorker[0].interrupt();
		//postalWorker[1].interrupt();
		//postalWorker[2].interrupt();
	}
	
	
	
	public static class Customer implements Runnable			
	{
		int id;
		
		public Customer(int id)
		{
			this.id=id;
		}
		
		//instead of wait and signal java uses acquire and release
		//************CUSTOMER RUN***********
		@Override
		public void run()									//Each customer thread runs 
		{
			
				
				System.out.println("Customer " + id + " created");
				//Enter Post Office
				try
				{
				max_capacity.acquire(); // wait(max_capacity);
				System.out.println("Customer " + id + " enters post office");
					
				//select a task
				
				mutexA.acquire();
				int task = rand.nextInt(3);
				currentTask = task;							//storing static variables of currentTask and currentCustomer for safe transfer
				currentCustomer = id;
				cust_ready.release();						//Worker, the customer is ready!
				ask.acquire(); 								//customer needs to ask 
				int workerid = currentWorker;
				
				System.out.println("Customer " + id + " asks postal worker " + workerid + " to " + tasks[task]);
				mutexB.release();
				doTask.release();							//return to worker action
				finished[id].acquire();						//Tell me when you are done worker
				
				switch(task)
				{
				case 0:
					System.out.println("Customer " +id + " finished buying stamps");
					break;
				case 1:
					System.out.println("Customer " +id + " finished mailing a letter");
					break;
				case 2:
					System.out.println("Customer " +id + " finished mailing a package");
					break;
				default:
					System.out.println("ERROR");
					break;
					
				}
				
				System.out.println("Customer " +id + " leaves post office");
				max_capacity.release();						//customer leaves so others may enter
				}
				catch(InterruptedException e)
				{
					e.printStackTrace();
				}
				
		}
		
	}
	
	public static class PostalWorker implements Runnable
	{
		int id;
		
		public PostalWorker(int id)
		{
			this.id=id;
		}
		
		//************WORKER RUN***********
		@Override
		public void run()									//I have my worker threads do the most work
		{
			System.out.println("Postal worker " + id + " created");
			while (running)
			{
				try
				{
					cust_ready.acquire();
					int cust_id = currentCustomer;				//ensuring the customer id and task are not replaced by storing to local variables
					int cust_task = currentTask;
					mutexA.release();
					mutexB.acquire();
					currentWorker = id;
					System.out.println("Postal worker " + id + " serving Customer " + cust_id);
					ask.release();								//Customer needs to ask
					doTask.acquire();							//Now return to worker actions
					//System.out.println("Customer " + cust_id + " asks postal worker " + id + " to " + tasks[cust_task]);
					
					switch(cust_task)
					{
					
					case 0:										//cust_task == 0 buy stamps
						try 
						{
							Thread.sleep(1000);
							System.out.println("Postal worker " + id +" finished serving customer " +cust_id);
							//System.out.println("Customer " +cust_id + " finished buying stamps");
						} 
						catch (InterruptedException e) 
						{
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						break;
						
					case 1:										//cust_task == 1 mail a letter
						try 
						{
							Thread.sleep(1500);
							System.out.println("Postal worker " + id +" finished serving customer " +cust_id);
							//System.out.println("Customer " +cust_id + " finished mailing a letter");
						} 
						catch (InterruptedException e) 
						{
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						break;
						
					case 2:										//cust_task == 2 mail a package
						try 
						{
							scale.acquire();
							System.out.println("Scales in use by postal worker " +id);
							Thread.sleep(2000);
							scale.release();
							System.out.println("Scales released by postal worker " +id);
							System.out.println("Postal worker " + id +" finished serving customer " +cust_id);
							//System.out.println("Customer " +cust_id + " finished mailing a package");
							
						} 
						catch (InterruptedException e) 
						{
						// TODO Auto-generated catch block
						e.printStackTrace();
						}
						break;
					
					default:
						System.out.println("ERROR");
						break;
					
						
				}
				finished[cust_id].release();
				
				}
				catch (InterruptedException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();}
			}
			return;
		}

	}
}