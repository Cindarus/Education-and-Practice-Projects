To run this program,

simply type 

javac Project2.java
java Project2

Or use a development environment such as eclipse