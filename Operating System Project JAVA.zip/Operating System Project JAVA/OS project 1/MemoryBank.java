//Grant Barratt
//OS Concepts
//Ozbirn
//Memory for CPU
//Should be split between user and system
//
/*
 *    It will consist of 2000 integer entries, 0-999 for the user program, 1000-1999 for system code.
   It will support two operations:
       read(address) -  returns the value at the address
       write(address, data) - writes the data to the address
   Memory will initialize itself by reading a program file.
   
DO THIS FIRST suggests Ozbirn
*/

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;


public class MemoryBank {

	static int memory[];
	static char wre;
	static int data;
	static int address;
	
	public static void main(String[] args) throws FileNotFoundException{
	{
		//System.out.println(args[0]);
	
		
		
		//String in = args[0];
		
		if(args.length == 0){
			// not enough arguments provided is there a way to make it think there are -1 args???
			System.exit(1);
		}
		String in = args[0];
		setup(in);}
	
		Scanner tanner = new Scanner(System.in);
		while(tanner.hasNextLine()){
			String input = tanner.nextLine();
			wre = input.charAt(0);
			int address, data;
			
			//exit
			if(wre == 'e')
				System.exit(0);
			
			//write
			else if(wre == 'w'){
				String[] parameters = input.substring(1).split(","); // cut first character out 'w'
				address = Integer.parseInt(parameters[0]);
				data = Integer.parseInt(parameters[1]);
				
				write(address,data);
			
			}
			
			//read
			else if(wre == 'r'){
				address= Integer.parseInt(input.substring(1));
				
				System.out.println(read(address));
				
			}
			
		}
		tanner.close();
	}
	
	//READ AND WRITE
	//just return index of memory
		private static int read(int address){
			
			return memory[address];
		}

		//set the index of memory to data
		private static void write(int address, int data){
			
			memory[address] = data;
		}

	//Take the program and read write or exit, call the other read and write functions accordingly
	static void setup(String input) throws FileNotFoundException{
		memory = new int[2000];
		
		int mindex = 0;
		File inputfile = new File(input);
		
		Scanner tanner2 = new Scanner(inputfile);
		while(tanner2.hasNextLine()){
			String line = tanner2.nextLine();
			line = line.trim();
			if(line.length() < 1) //"A line may be blank in which case the loader will skip it withuot advancing the load address"
				continue;
			// Anything following an integer is a comment, whether or not it begins with //.
			//A line may begin by a period followed by a number which causes the loader to change the load address.
			if(line.charAt(0) == 46){
				mindex = Integer.parseInt(line.substring(1).split("\\s+")[0]);
				continue;
			}
			// IF Number isnt found keep on going
			if(line.charAt(0) < 48 || line.charAt(0) > 58||line.charAt(0) == 46 )
				continue;
			
			//\\s is regular expression for white space
			String[] split = line.split("\\s+");
			memory[mindex++] = Integer.parseInt(split[0]);
			
		}
		tanner2.close();
	}
	
	
	
}