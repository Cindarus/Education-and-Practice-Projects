import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.Scanner;

public class CPU{
	//status flags
	public static boolean run;
	public static boolean kernel;
	
	public static void main(String[] args)throws IOException{
	
		//
		/*timer.schedule(new TimerTask() {
			  @Override
			  public void run() {
			  }
			}, 2*60*1000);
		 *///TIMER JUST NEEDS TO BE AFTER AMOUNT OF INSTRUCTIONS 
		//ProcessBuilder executor = new ProcessBuilder();
		// Get the program arguments
		
		//System.out.println(args[0]);
		//A timer will interrupt the processor after every X instructions, where X is a command-line parameter.
		
		//args0 = name of samples and args1 = timer
		String sampleInstructions = args[0];
		int timer = Integer.parseInt(args[1]);
		int a;
		
		
		try {
			Runtime executor = Runtime.getRuntime(); //create another process for the memory!
			System.out.println("loading java MemoryBank + " + sampleInstructions);
			Process memoryBlock = executor.exec("java MemoryBank "+sampleInstructions);
			String errorMessgaes;
			
		
			//input and output will both be Printwriters
			//in will be scanner
			
			PrintWriter mOut= new PrintWriter(memoryBlock.getOutputStream());
			//PrintWriter mIn = new PrintWriter(memoryBlock.getInputStream());
			Scanner tanner = new Scanner(memoryBlock.getInputStream());
			Processor cpu = new Processor(timer,tanner,mOut);
			//System.out.println("test1 " + run);
			cpu.run(); //processor class function
		} catch (IOException e) {
			e.printStackTrace();
			System.exit(1);
		}

	}
	
	//SIMULATE A simple COMPUTER processor and memory
	//   It will have these registers:  PC, SP, IR, AC, X, Y.
	//   It will run the user program at address 0.
	
	private static class Processor
	{
		private Scanner tanner;
		private int PC = 0, SP = 1000, IR = 0, AC =0, X=0, Y=0, time =0;
		private PrintWriter mOut;
		private int interrupt;
		
		
		public Processor(int timeflag, Scanner tanner, PrintWriter mOut)
		{
			//this.time = timeflag;
			this.interrupt = timeflag;
			this.tanner = tanner;
			this.mOut= mOut;
			kernel = false;
			
			
		}

	
		private int read(int address){
			if(!kernel && address >999){
				System.out.println("User may not access system stack. EXITING");
				System.exit(0);
			}
			mOut.println("r" + address);//tell memory to read the address 
			mOut.flush();
			//System.out.println("TANNER ARE YOU OK?");
			return Integer.parseInt(tanner.nextLine()); //return what memory had read
		}

		public void run(){
			run = true;
			//System.out.println("test2 " + run);
			while(run){
				//System.out.println("test3 " + run + IR);
				IR = read(PC++);
				//System.out.println("test " + run);
				run = execute();
				//System.out.println("test " + run);
				time++;
			
				if(time >= interrupt &&! kernel){
					
						time = 0;
						kernel();
						PC = 1000;
					
					
				}
			}
		}
		
	
		//The user stack resides at the end of user memory and grows down toward address 0.
		// The system stack resides at the end of system memory and grows down toward address 0
		private void kernel(){
			kernel = true;
			int tSP = SP; 
			//change the SP for now 
			SP = 2000;
			mOut.printf("w"+--SP+","+tSP+"\n");
			mOut.flush();
	
			mOut.printf("w"+--SP+","+PC+"\n");
			mOut.flush();
		
			/*mOut.printf("w"+--SP+","+IR+"\n");
			mOut.flush();
		
			mOut.printf("w"+--SP+","+AC+"\n");
			mOut.flush();
		
			mOut.printf("w"+--SP+","+X+"\n");
			mOut.flush();
		
			mOut.printf("w"+--SP+","+Y+"\n");
			mOut.flush();*/
		}
	
		//always flush!!!
		//Instructions are fetched into the IR from memory.  The operand can be fetched into a local variable.
		// Each instruction should be executed before the next instruction is fetched.
		//The program ends when the End instruction is executed.  The 2 processes should end at that time.
		private boolean execute(){
			
			switch(IR){
				case 1://Load the value into the AC
					IR = read(PC++);
					AC = IR;
					break;
					
				case 2://Load the value at the address into the AC
					IR = read(PC++);
					AC = read(IR);
					break;
					
				case 3: //Load the value from the address found in the given address into the AC
					IR = read(PC++);
					AC = read(read(IR));
					break;
					
				case 4: //Load the value at (address+X) into the AC
					IR = read(PC++);
					AC = read(IR + X);
					break;
					
				case 5: //Load the value at (address+Y) into the AC
					IR = read(PC++);
					AC = read(IR + Y);
					break;
				case 6: //Load from (Sp+X) into the AC (if SP is 990, and X is 1, load from 991).
					AC = read(SP+X);
					break;
					
				case 7: //Store the value in the AC into the address
					IR = read(PC++);
					mOut.printf("w"+--SP+","+AC+"\n");
					mOut.flush();
					break;
					
				case 8: //Gets a random int from 1 to 100 into the AC
					AC = (int) (Math.random()*100+1);
					break;
					
				case 9:
					//If port=1, writes AC as an int to the screen
					//If port=2, writes AC as a char to the screen

					IR = read(PC++);
					if(IR == 1){
						System.out.print(AC);
					}	
					else if(IR == 2){
						System.out.print((char)AC);
					}	
					break;
					
				case 10: //Add the value in X to the AC
					AC = AC + X;
					break;
					
				case 11: //Add the value in Y to the AC
					AC = AC + Y;
					break;
					
				case 12://Subtract the value in X from the AC
					AC = AC - X;
					break;
					
				case 13: //Subtract the value in Y from the AC
					AC = AC - Y;
					break;
					
				case 14://Copy the value in the AC to X
					X = AC;
					break;
					
				case 15: //Copy the value in X to the AC
					AC = X;
					break;
					
				case 16://Copy the value in the AC to Y
					Y = AC;
					break;
					
				case 17: //Copy the value in Y to the AC
					AC = Y;
					break;
					
				case 18: //Copy the value in AC to the SP
					SP = AC;
					break;
					
				case 19: //Copy the value in SP to the AC 
					AC = SP;
					break;
					
				case 20://Jump to the address
					IR = read(PC++);
					PC = IR;
					break;
					
				case 21: //Jump to the address only if the value in the AC is zero
					IR = read(PC++);
					if(AC == 0)
						PC = IR;
					break;
					
				case 22: //Jump to the address only if the value in the AC is not zero
					IR = read(PC++);
					if(AC != 0)
						PC = IR;
					break;
					
				case 23: //Push return address onto stack, jump to the address
					IR = read(PC++);
					mOut.printf("w"+--SP+","+PC+"\n");
					mOut.flush();
					PC = IR;
					break;
					
				case 24://Pop return address from the stack, jump to the address
					PC = read(SP++);
					break;
					
				case 25: //Increment the value in X
					X++; 
					break;
					
				case 26: //Decrement the value in X
					X--; 
					break;
					
				case 27://Push AC onto stack
					mOut.printf("w"+--SP+","+AC+"\n");
					mOut.flush();
					break;
					
				case 28://Pop from stack into AC
					AC = read(SP++);
					break;
					
				case 29: //Perform system call
					if(!kernel){
						kernel();
						PC = 1500;
					}
					break;
					
				case 30: // Return from system call
					/*Y = read(SP++);
					X = read(SP++);
					AC = read(SP++);
					IR = read(SP++);*/
					PC = read(SP++);
					SP = read(SP++);
					kernel = false;
					break;
					
				case 50: // End exec
					mOut.println("e");
					mOut.flush();
					return false;
					
				default: // bad
					System.err.println("ERROR: Invalid instruction.");
					mOut.println("e");
					mOut.flush();
					return false;
					
			}
			
			return true;
		}
		
	}
}