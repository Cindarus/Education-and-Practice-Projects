to run

javac CPU.java
javac MemoryBank.java

then

java CPU sample1.txt