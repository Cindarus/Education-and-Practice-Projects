//Grant Barratt
//HEXAGON
//GCB140230
//Sept 10 2016

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;


public class Hexagons extends JPanel {

	public static void main(String[] args){
		JFrame f = new JFrame("Hexagons");
		Hexagons p = new Hexagons();
		f.add(p);
		f.add("Center", new Hexagon());
		f.setSize(400,300);
		f.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		f.setVisible(true);
		f.setBackground(Color.RED);
	}

}


class Hexagon extends Canvas
{
	float r = -1, hexagonHeight, hexagonWidth;
	Point mouse;
	int originX;
	int originY;
	float pixelSize;
	float logicWidth = 10.0F;
	float logicHeight =10.0F;
	float actualWidth;
	float actualHeight;
	
	protected void start()
	{
		Dimension d =getSize();
		int maxX =d.width -1, maxY = d.height -1;
		pixelSize = Math.max(logicWidth/ maxX, logicHeight / maxY);
		
		originY = maxY/2;
		originX = maxX/2;
		
		actualHeight=maxY*pixelSize;
		actualWidth=maxX*pixelSize;
	}
	
	//I must set up functionality with a mouse
	Hexagon()
	{
		MouseAdapter listenformouse = new MouseAdapter(){
			
		public void mousePressed(MouseEvent q){
			getRadius(q);
		}
		private void getRadius(MouseEvent q){
			mouse = q.getPoint();
			
			float x = clickX(q.getX()), y = clickY(q.getY());
			r=distance(x,y, -actualWidth/2, actualHeight/2); // divided by 2
			
			hexagonHeight = (float) (Math.sqrt(3) *  r);
			hexagonWidth = r * 2;
			repaint();
			}	
		};
		addMouseListener(listenformouse);
		addMouseMotionListener(listenformouse);
	}
	

	
	
	
	float clickX(int X) //the X it uses when you click near top left
	{
		return (X - originX) * pixelSize;
	}
	
	float clickY(int Y) //the Y it uses when you click near top left
	{
		return (originY - Y) * pixelSize;
	}
	
	float distance (float x1, float y1, float x2, float y2) //function to do sqrt(x^2 + y^2) Distance formula
	{
		return (float) Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1));
	}
	
	int X(float x)
	{
		return Math.round(originX + x / pixelSize);
	}
	
	int Y(float y)
	{
		return Math.round(originY - y /pixelSize);
	}
	
	void draw(Graphics g, float x, float y, float r)
	{
		for (int i = 0; i<6; i++)
		{
			float x1 = (float) (x + r * Math.cos(i*Math.PI /3));
			float y1 = (float) (y + r * Math.sin(i*Math.PI /3));
			float x2 = (float) (x + r * Math.cos((i+1) * Math.PI/3));
			float y2 = (float) (y + r * Math.sin((i+1) * Math.PI/3));
			
			g.drawLine(X(x1), Y(y1), X(x2), Y(y2));
		}
	}
	
	public void paint(Graphics g){
		setBackground(Color.CYAN);
		start();
		if(mouse != null)
		{
			
			float offX;
			if(2*r > actualWidth)// when 0 hexes wide!
				offX = 0; 
				
			else if( 1.5*hexagonHeight > actualHeight || 3.5f*r > actualWidth) 
				offX = (actualWidth - 2*r) / 2;		
				
			else 
				offX = (float) (((actualWidth - 2*r) / (1.5*r) % 1) * 1.5*r / 2);
				
			
			float offY;
			if(hexagonHeight > actualHeight)
				offY = 0;
			else if(1.5*hexagonHeight > actualHeight) 
				offY = (actualHeight - hexagonHeight) / 2;
			else 
				offY = (float) (((actualHeight - hexagonHeight) / (.5*hexagonHeight) % 1) * .5*hexagonHeight / 2);

			//shift rows
			boolean offRow = false;
			for(float y=actualHeight/2 - hexagonHeight/2; y > -actualHeight/2 + hexagonHeight/2; y -= hexagonHeight/2)
			{
				for(float x=-actualWidth/2 + ((offRow)?2.5f:1f) * r; x < actualWidth/2 - r; x += 3*r)
				{
					draw(g, x + offX, y - offY, r);
				}
				offRow = !offRow;
			}
		}
		else
			g.drawString("CLICK SOMEWHERE!", 25, 120);
		
	}
	
}

