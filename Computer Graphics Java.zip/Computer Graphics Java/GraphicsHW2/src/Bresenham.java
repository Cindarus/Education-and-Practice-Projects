import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.awt.*;
import javax.swing.*;

//Grant Barratt
//Bresenham
//GCB140230
//Sept 23 2016


/*
 * 
 * INPUT.TXT SHOULD LOOK LIKE THIS
 *  N (int: number of lines up to 10)
 X1a Y1a X1b Y1b (int: endpoints of line 1)
 X2a Y2a X2b Y2b (int: endpoints of line 2)
 �
 XNa YNa XNb YNb (int: endpoints of line N)
 Xc Yc R (int: Center point co-ordinates and Radius of circle)
 * 
*/


public class Bresenham extends JPanel {

	public static void main(String[] args) throws FileNotFoundException{
		JFrame f = new JFrame("Bresenham Magnified");
		Bresenham p = new Bresenham();
		f.add(p);
		f.add("Center", new JBresenham());
		f.setSize(400,300);
		f.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		f.setVisible(true);
	}
}

class JBresenham extends Canvas
{ 
	int canvasX, canvasY; //CANVAS X AND Y NEEDED TO MAKE GRIDLINES
	int dGrid = 10; //INSTRUCTIONS SAY TO MAKE dGrid= 10
	
	
	int[][] lineinput;//inputs for lines
	
	int cX, cY, cR; //inputs for the circle at end of input.txt
	
	
	JBresenham() throws  FileNotFoundException
	{
		Scanner tanner = new Scanner(new File( "input.txt")); // I always call my scanners tanner, homage to a friend 
		int i = tanner.nextInt(); //since 'i' should be the first value in the input.txt, just read it!
		lineinput = new int[i][4];//i lines that each have 4 elements x1 y1 x2 y2
		for(int k = 0; k < i; k++)
		{
			lineinput[k] = new int[]{
			tanner.nextInt(),tanner.nextInt(),
			tanner.nextInt(),tanner.nextInt()
			};
		}
		//no loop for circle info
		cX = tanner.nextInt();
		cY = tanner.nextInt();
		cR = tanner.nextInt();
	}
	
	void start()
		{ 
		Dimension d;
		d = getSize();
		canvasX = d.width - 1;
		canvasY = d.height - 1; 
		}
	
	
	//I MUST INCLUDE A PUT PIXEL METHOD AS DESCRIBED BY QUESTION
	void putPixel(Graphics g, int x, int y)
	{ 
		int x1 = x * dGrid, y1 = y * dGrid, h = dGrid/2;
		g.drawOval(x1 - h, y1 - h, dGrid, dGrid);// OVAL since then i can specify xleft/right and y top/bottom
	}

	//I MUST INCLUDE A DRAWLINE METHOD WHICH USES BRESENHAM AND THE PUTPIXEL METHOD
	void drawLine(Graphics g, int xA, int yA, int xB, int yB)
	{
		int c;
		int M;
		int x = xA,
			y = yA,
			D = 0,
			dX = xB - xA,
			dY = yB - yA,
			xIncrement = 1,
			yIncrement = 1;
		
		if (dY < 0)
		{
			yIncrement = -1; dY = -dY;
		}
		
		if (dX < 0)
		{
			xIncrement = -1; dX = -dX;
		}
		
		
		
		if (dY <= dX)
		{ 
			c = 2 * dX; 
			M = 2 * dY;
			
			while (true)
			{ 
				putPixel(g, x, y);
				if (x == xB) 
					break;
				
				x += xIncrement;
				D += M;
				
				if (D > dX)
				{
					y += yIncrement; D -= c;
				}
			}
		}
		else
		{
			c = 2 * dY;
			M = 2 * dX;

			while (true)
			{
				putPixel(g, x, y);

				if (y == yB) break;
				y += yIncrement;
				D += M;

				if (D > dY)
				{
					x += xIncrement; D -= c;
				}
			}
		}
	}

	//AND FINALLY I MUST PUT A DRAWCIRCLE METHOD BY BRESENHAM
	void drawCircle(Graphics g, int xCenter, int yCenter, int radius)
	{
		int x = 0,
			y = radius,
			curve = 1, //should be around 1
			v = 2 * radius - 1,
			E = 0;
		
		while (x < y)

		{ 
			putPixel(g, xCenter + x, yCenter + y);
			putPixel(g, xCenter + y, yCenter - x);
			putPixel(g, xCenter - x, yCenter - y); 
			putPixel(g, xCenter - y, yCenter + x); 
			
			x++;
			E += curve;
			curve += 2;
			if (v < 2 * E)
			{
				y--; E -= v; v -= 2;
			}
			
			if (x > y) 
				break;

			putPixel(g, xCenter + y, yCenter + x); 
			putPixel(g, xCenter + x, yCenter - y); 
			putPixel(g, xCenter - y, yCenter - x); 
			putPixel(g, xCenter - x, yCenter + y); 
		}
	}

	//USING THE DRAWLINE, WHICH USES THE PUTPIXEL METHOD, I NEED TO MAKE A GRID ACCORDING TO MAX Y AND MAX X
	void showGrid(Graphics g)
	{
		for (int x=dGrid; x<=canvasX; x+=dGrid)
			for (int y=dGrid; y<=canvasY; y+=dGrid)
				g.drawLine(x, y, x, y);
	}

	public void paint(Graphics g)
	{ 
		setBackground(Color.PINK);
		start();
		showGrid(g);
		for(int[] line : lineinput)
		{
			drawLine(g, line[0], line[1], line[2], line[3]);
			
		}
		drawCircle(g, cX, cY, cR); 
		
	}
}