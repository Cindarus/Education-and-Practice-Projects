//Grant Barratt
//ClickSquare
//GCB140230
//Sept 23 2016

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ClickSquare extends JPanel {

	public static void main(String [] args){
		JFrame f = new JFrame("Click Two Points to create a square");
		ClickSquare p = new ClickSquare();
		f.add(p);
		f.add("Center", new PClickSquare());
		f.setSize(400, 300);
		f.setCursor(Cursor.getPredefinedCursor(Cursor.DEFAULT_CURSOR));
		f.setVisible(true);
		//f.setBackground(Color.RED);
	}
}


class PClickSquare extends Canvas
{
	//make variables and flaggs here, I need a flat to determine whether it is first or second click
	Point first,second;
	boolean oneclick;
	int xA, xB, yA, yB;
	
	/*protected void start(){
		oneclick = true;
	}THIS WAS EXCESSIVE*/
	
	PClickSquare(){
		oneclick = true;
		MouseAdapter listenformouse = new MouseAdapter(){
		public void mousePressed(MouseEvent q)
		{
			if(oneclick){
				first = q.getPoint();
				oneclick = false;
			}
			else{
				second = q.getPoint();
				oneclick =true;
				repaint();
			}
				
		}
		};
		addMouseListener(listenformouse);
		addMouseMotionListener(listenformouse);
	}
	public void paint(Graphics g)
	{	
		setBackground(Color.GREEN);
		
		if(first != null)
		{
		xA = first.x;
		yA = first.y;
		xB = second.x;
		yB = second.y;
		
		int xC = (xB-(yA-yB));
		int yC = (yB-(xB-xA));
		int xD = (xA-(yA-yB));
		int yD = (yA-(xB-xA));
		
	
			g.drawLine(xA,yA,xB,yB);//A -> B
			g.drawLine(xB,yB,xC,yC);//B -> C
			g.drawLine(xC,yC,xD,yD);//C -> D
			g.drawLine(xD,yD,xA,yA);//D -> A
			g.drawString("1", xA, yA);
			g.drawString("2", xB, yB);
			g.drawString("3", xC, yC);
			g.drawString("4", xD, yD);
		
		}
		else
		g.drawString("CLICK ANY TWO SPOTS TO MAKE SQUARES!", 25, 120);
	}
}