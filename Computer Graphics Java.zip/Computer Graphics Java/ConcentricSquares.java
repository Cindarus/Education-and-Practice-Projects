import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class ConcentricSquares extends JPanel {

	public static void main(String[] args) {
		
		JFrame f = new JFrame ("Concentric Squares");
		//f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		ConcentricSquares p = new ConcentricSquares();
		f.add(p);
		f.setSize(400, 300);
		f.setVisible(true);
		//f.setBackground(Color.BLACK);
	}
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		this.setBackground(Color.WHITE);
		
		Dimension d = getSize();
		int maxX = d.width-1, maxY = d.height-1, centerX = maxX/2, centerY = maxY /2;
		g.setColor(Color.BLACK);
	//	g.drawRect(10, 10, maxX-20, maxY-20);
	
		//loop until break and increment n
		for (int n=0;;n++)
		{
			int Offset1 = (int) Math.pow(2, n); // increase the offset from center for each loop
			
			if(centerY - Offset1 < 0 || centerY + Offset1 >maxY || centerX - Offset1 < 0 || centerX + Offset1 > maxX 
				){
				break;
			}
			else
			{
				g.drawLine(centerX+Offset1, centerY+Offset1, centerX-Offset1, centerY+Offset1);
				
				g.drawLine(centerX-Offset1, centerY+Offset1, centerX-Offset1, centerY-Offset1);
				
				g.drawLine(centerX-Offset1, centerY-Offset1, centerX+Offset1, centerY-Offset1);
				
				g.drawLine(centerX+Offset1, centerY-Offset1, centerX+Offset1, centerY+Offset1);
				
			}
			
			
			int Offset2 = (int) Math.pow(2, n+1); // increase the offset from center for each loop
			
			if(centerY - Offset2 < 0 || centerY + Offset2 >maxY || centerX - Offset2 < 0 || centerX + Offset2 > maxX ){
				break;
			}
			else
			{
				g.drawLine(centerX, centerY+Offset2, centerX-Offset2, centerY);
				
				g.drawLine(centerX-Offset2, centerY, centerX, centerY-Offset2);
				
				g.drawLine(centerX, centerY-Offset2, centerX+Offset2, centerY);
				
				g.drawLine(centerX+Offset2, centerY, centerX, centerY+Offset2);
				
			}
			
			
			
		}
	}
	
	
	
}

