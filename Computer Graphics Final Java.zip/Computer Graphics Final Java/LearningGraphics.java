import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import javax.imageio.*;
import javax.swing.*;

public class LearningGraphics {
    public static void main(String[] args) {
        new Menubar();
    }
    
}
class Menubar extends Frame implements ActionListener
{
    MenuItem menu,quit;
    LessonsMain obj = new LessonsMain();
    public Menubar()
    {
      super("Learning Graphics");
      addWindowListener(new WindowAdapter()
         {public void windowClosing(WindowEvent e){System.exit(0);}});
      MenuBar bar = new MenuBar();
      setMenuBar(bar);
      Menu file = new Menu("File");
      menu = new MenuItem("Menu");
      menu.addActionListener(this);
      quit = new MenuItem("Quit");
      quit.addActionListener(this);
      file.add(menu);
      file.add(quit);
      bar.add(file);
	GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
	GraphicsDevice defaultScreen = ge.getDefaultScreenDevice();
	Rectangle rect = defaultScreen.getDefaultConfiguration().getBounds();
	System.out.println(rect.getMaxX());
	int x = (int) rect.getMaxX()/2-375;
	int y = (int) rect.getMaxY()/2-375;
	setLocation(x, y);
      setSize(750, 750);
      setResizable(false);
      add("Center", obj);
      show();
    }
    public void actionPerformed(ActionEvent e)
    {
      MenuItem act= (MenuItem)e.getSource(); 
      if(act == quit) {
          System.exit(0);
      }
      if(act == menu) {
       obj.loadmenu();
      }
      } 
}


class LessonsMain extends Canvas
{ 
	boolean les1finished = false;
	boolean les2finished = false;
	boolean les3finished = false;
	boolean les4finished = false;

   Boolean Startscreen = true;
   Image background = null;
   Image complete = null;
   Image lesson1img = null;
   Image lesson1imggrey = null;
   Image lesson2img = null;
   Image lesson2imggrey = null;
   Image lesson3img = null;
   Image lesson3imggrey = null;
   Image lesson4img = null;
   Image lesson4imggrey = null;
   Boolean opened = false;
   JFrame LesFrame1 = new JFrame();
   Lessons1 les1 = new Lessons1(LesFrame1);
   JFrame LesFrame2 = new JFrame();
   Lessons2 les2 = new Lessons2(LesFrame2);
   JFrame LesFrame3 = new JFrame();
   Lessons3 les3 = new Lessons3(LesFrame3);
   JFrame LesFrame4 = new JFrame();
   Lessons4 les4 = new Lessons4(LesFrame4);
   
   LessonsMain()
   {  
       LesFrame1.setSize(500, 500);
       LesFrame1.setResizable(false);
       LesFrame1.addWindowListener(new WindowAdapter()
         {public void windowClosing(WindowEvent e){opened = false; System.out.println(les1.isFinished());
		 if(les1.isFinished()){
			les1finished = true;
			repaint();
		 }
		 }});
		  LesFrame2.setSize(500, 500);
       LesFrame2.setResizable(false);
       LesFrame2.addWindowListener(new WindowAdapter()
         {public void windowClosing(WindowEvent e){opened = false; System.out.println(les2.isFinished());
		 		 if(les2.isFinished()){
			les2finished = true;
			repaint();
		 }}});
		  LesFrame3.setSize(500, 500);
       LesFrame3.setResizable(false);
       LesFrame3.addWindowListener(new WindowAdapter()
         {public void windowClosing(WindowEvent e){opened = false; System.out.println(les3.isFinished());
		 		 if(les3.isFinished()){
			les3finished = true;
			repaint();
		 }}});
		  LesFrame4.setSize(500, 500);
       LesFrame4.setResizable(false);
       LesFrame4.addWindowListener(new WindowAdapter()
         {public void windowClosing(WindowEvent e){opened = false; System.out.println(les4.isFinished());
		 		 if(les4.isFinished()){
			les4finished = true;
			repaint();
		 }}});
        try {  
           // System.out.println("Working Directory = " +System.getProperty("user.dir"));
          background = ImageIO.read(new File("pictures/titlescreen.png"));
		  complete = ImageIO.read(new File("pictures/completed.png"));
          lesson1img = ImageIO.read(new File("pictures/lesson1title.png"));
          lesson1imggrey = GrayFilter.createDisabledImage(lesson1img);
		  
		  lesson2img = ImageIO.read(new File("pictures/lesson2title.png"));
          lesson2imggrey = GrayFilter.createDisabledImage(lesson2img);
		  
		  lesson3img = ImageIO.read(new File("pictures/lesson3title.png"));
          lesson3imggrey = GrayFilter.createDisabledImage(lesson3img);
		  
		  lesson4img = ImageIO.read(new File("pictures/lesson4title.png"));
          lesson4imggrey = GrayFilter.createDisabledImage(lesson4img);
       } catch (IOException ex) {
           System.out.println(ex.toString());
       }
        
       addMouseListener(new MouseAdapter()
      {  public void mousePressed(MouseEvent evt)
         {
             if(Startscreen)
             {
            Startscreen = false;
            repaint();
             }else{
                 if(!opened)
                 {
                     int x = evt.getX();
                     int y = evt.getY();
                     if(x<getWidth()/2){
                       if(y<getHeight()/2){
					   if(!les1finished)
					   {
                           System.out.println("Lesson 1 Clicked"); 
                           opened = true;
						   LesFrame1.add("Center",les1);
                           LesFrame1.setVisible(true);
						   }
                       }  
                       else{
					    if(les2finished && !les3finished)
					   {
                           System.out.println("Lesson 3 Clicked");
						    opened = true;
						   LesFrame3.add("Center",les3);
                           LesFrame3.setVisible(true);
						   }
                       }
                     }
                     else{
                       if(y<getHeight()/2){
					   if(les1finished && !les2finished)
					   {
                           System.out.println("Lesson 2 Clicked"); 
						   LesFrame2.add("Center",les2);
                           LesFrame2.setVisible(true);
						   }
                       }  
                       else{
					   if(les3finished && !les4finished){
                           System.out.println("Lesson 4 Clicked");						   
						   LesFrame4.add("Center",les4);
                           LesFrame4.setVisible(true);
						   }
                       }    
                     }
                     
                     
                 }
                 
                 
                 
                 
             }
         }
      });
       //show();
   }

    public void paint(Graphics g)
    {
        if(Startscreen){ 
               g.drawImage(background, 0, 0, getWidth(), getHeight(), this);
        }else{
			if(!les1finished)
			{
			g.drawImage(lesson1img, 0, 0, getWidth()/2, getHeight()/2, this);
            g.drawImage(lesson2imggrey, getWidth()/2, 0,getWidth()/2,getHeight()/2, this);
            g.drawImage(lesson3imggrey, 0, getHeight()/2,getWidth()/2,getHeight()/2, this);
            g.drawImage(lesson4imggrey, getWidth()/2, getHeight()/2,getWidth()/2,getHeight()/2, this);
			}else{
			g.drawImage(lesson1imggrey, 0, 0, getWidth()/2, getHeight()/2, this);
			g.drawImage(complete, 0, 0, getWidth()/2, getHeight()/2, this);
			if(!les2finished)
			{ g.drawImage(lesson2img, getWidth()/2, 0,getWidth()/2,getHeight()/2, this);
            g.drawImage(lesson3imggrey, 0, getHeight()/2,getWidth()/2,getHeight()/2, this);
            g.drawImage(lesson4imggrey, getWidth()/2, getHeight()/2,getWidth()/2,getHeight()/2, this);
			}else{
			g.drawImage(lesson2imggrey, getWidth()/2, 0,getWidth()/2,getHeight()/2, this);
			g.drawImage(complete, getWidth()/2, 0,getWidth()/2,getHeight()/2, this);
			if(!les3finished){
			g.drawImage(lesson3img, 0, getHeight()/2,getWidth()/2,getHeight()/2, this);
            g.drawImage(lesson4imggrey, getWidth()/2, getHeight()/2,getWidth()/2,getHeight()/2, this);
			}else{
			g.drawImage(lesson3imggrey, 0, getHeight()/2,getWidth()/2,getHeight()/2, this);
			g.drawImage(complete, 0, getHeight()/2,getWidth()/2,getHeight()/2, this);
			if(!les4finished){
			g.drawImage(lesson4img, getWidth()/2, getHeight()/2,getWidth()/2,getHeight()/2, this);
			}else{
			g.drawImage(lesson4imggrey, getWidth()/2, getHeight()/2,getWidth()/2,getHeight()/2, this);
			g.drawImage(complete, getWidth()/2, getHeight()/2,getWidth()/2,getHeight()/2, this);
			}
			}
			}
			}

            
            g.drawLine(0, getHeight()/2, getWidth(), getHeight()/2);
            g.drawLine(getWidth()/2, 0, getWidth()/2, getHeight());
        }
    }
    public void loadmenu(){
        LesFrame1.dispose();
		LesFrame2.dispose();
		LesFrame3.dispose();
		LesFrame4.dispose();
        opened = false;
        Startscreen = true;
        repaint();
    }
}