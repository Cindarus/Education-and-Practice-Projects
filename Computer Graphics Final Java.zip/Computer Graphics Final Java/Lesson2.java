import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import javax.imageio.*;
import javax.swing.*;

class Lessons2 extends Canvas
{ 
	Boolean finished = false;
	public Boolean isFinished(){
		return finished;
	}
	Lessons2(JFrame temp) {
	final JFrame t = temp;
	 addMouseListener(new MouseAdapter()
      {  public void mousePressed(MouseEvent evt)
         {
			finished = true;
			t.dispatchEvent(new WindowEvent(t, WindowEvent.WINDOW_CLOSING));
		 }
	  });
	}
	
	 public void paint(Graphics g)
    {
	g.drawLine(0,0,50,50);
	}
	
}