import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.geom.Point2D;
import java.util.Random;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import javax.imageio.*;
import javax.swing.*;




class Lessons1 extends Canvas implements KeyListener
{ 
	
	Image additive = null;
	Image subtractive = null;
	Image drawAdditive(){
		try {  
	           // System.out.println("Working Directory = " +System.getProperty("user.dir"));
	          additive = ImageIO.read(new File("pictures/additive.png"));
			  
	       } catch (IOException ex) {
	           System.out.println(ex.toString());
	       }
		return additive;
	}
	Image drawSubtractive(){
		try {  
	           // System.out.println("Working Directory = " +System.getProperty("user.dir"));
	          additive = ImageIO.read(new File("pictures/subtractive.png"));
			  
	       } catch (IOException ex) {
	           System.out.println(ex.toString());
	       }
		return additive;
	}
	
	
	Boolean finished = false;
	int midX, midY;
	int level, dir;
	float x, y;
	boolean phase1 = true, phase2 = false, phase3 = false, phase4 = false, phase5 = false, phase6 = false, phase7=false, choice1 = false, choice2 = false, choice4 = false;;
	
	
	public Boolean isFinished(){
		return finished;
	}
	
	Lessons1(JFrame temp) {
		final JFrame t = temp;
		dir = 0;
		level = -1;
		 addMouseListener(new MouseAdapter()
	      {  public void mousePressed(MouseEvent evt)
	         {
	    	  	if(phase1)
	    	  	{
	    	  		if(level < 0)
	    	  			level++;
	    	  		else
	    	  		{
	    	  			phase1 = false;
	    	  			level = 0;
		    	  		phase2 = true;
		    	  		
	    	  		}
	    	  	}
	    	  	else if(phase2){
	    	  		if(level < 0)
	    	  			level++;
	    	  		else
	    	  		{
	    	  			phase2 = false;
	    	  			level = 0;
		    	  		phase3 = true;
		    	  		
	    	  		}
	    	  	}
	    	  	else if(phase3){
	    	  		if(level <20)
	    	  			level++;
	    	  		else
	    	  		{
	    	  			level = 0;
	    	  			phase3 = false;
	    	  			phase4 = true;
	    	  		}
	    	  	}
	    	  	
	    	  	else if(phase4){
	    	  		if(level <20)
	    	  			level++;
	    	  		else
	    	  		{
	    	  			level = 0;
	    	  			phase4 = false;
	    	  			phase5 = true;
	    	  		}
	    	  	}
	    	  	
	    	  	else if(phase5){
	    	  		if(level <20)
	    	  			level++;
	    	  		else
	    	  		{
	    	  			level = 0;
	    	  			phase5 = false;
	    	  			phase6 = true;
	    	  		}
	    	  	}
	    	  	else if(phase6){
	    	  		if(level <0)
	    	  			level++;
	    	  		else
	    	  		{
	    	  			level = 0;
	    	  			phase6 = false;
	    	  			phase7 = true;
	    	  		}
	    	  	}
	    	  	else if(phase7){
	    	  		
	    	  	}
	    	  	repaint();
				//finished = true;
				if(finished)
					t.dispatchEvent(new WindowEvent(t, WindowEvent.WINDOW_CLOSING));
			 }
		  });
		 addKeyListener(this);
	}
	
	@Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    	
    	if(phase7)
    	{
    		if(e.getKeyCode() == 49)
    		{
    			choice1 = true;
    			repaint();
    		}
    		if(e.getKeyCode() == 50)
    		{
    			choice2 = true;
    			repaint();
    		}
    		if(e.getKeyCode() == 51)
    		{
    			
    			finished=true;
    			phase7=false;
    			repaint();
    		}
    		if(e.getKeyCode() == 52)
    		{
    			choice4 = true;
    			repaint();
    		}
    	}

        
    }

    @Override
    public void keyReleased(KeyEvent e) {
      
    }
    
	 public void paint(Graphics g)
    {
		 Dimension d = getSize();
	      int maxX = d.width - 1, maxY = d.height - 1;
	     if(phase1)
	     {
	          if(level >= 0){
		        
			      g.setColor(Color.red);
			      g.fillRect(50,25,134,35);
			      
			      g.setColor(Color.green);
			      g.fillRect(50,75,134,35);
			      
			      g.setColor(Color.blue);
			      g.fillRect(50,125,134,35);
			      
			      g.setColor(Color.red);
			      g.fillRect(50,175,32,35);
			      g.setColor(Color.green);
			      g.fillRect(152,175,32,35);
			      g.setColor(Color.yellow);
			      g.fillRect(82,175,70,35);
			      
			      g.setColor(Color.green);
			      g.fillRect(50,225,32,35);
			      g.setColor(Color.blue);
			      g.fillRect(152,225,32,35);
			      g.setColor(Color.cyan);
			      g.fillRect(82,225,70,35);
			      
			      g.setColor(Color.blue);
			      g.fillRect(50,275,32,35);
			      g.setColor(Color.red);
			      g.fillRect(152,275,32,35);
			      g.setColor(Color.magenta);
			      g.fillRect(82,275,70,35);
			      
			      
			      g.drawImage(drawAdditive(),getWidth()/2, 0, getWidth()/2, getHeight()/2, this);
			     
			      g.setColor(Color.magenta);
			      g.drawString("The diagrams above display additive color mixing. According to color theory,", 10, maxY - 82);
			      g.drawString("additive color mixing means that colors add to one another when they mix.", 10, maxY - 70);
			      g.drawString("This occurs in real life with lights. This means that when you put a red light ", 10, maxY - 58);
			      g.drawString("and a green light together, you end up with yellow. Red and blue combine to create ", 10, maxY - 46);
			      g.drawString("magenta, and green and blue combine to create cyan. Additive color mixing can be used  ", 10, maxY - 34);
			      g.drawString("to create oranges, yellows, purples, and white when all colors are added.", 10, maxY - 22);
			      g.drawString("The pixels of your monitor use additive color mixing!", 10, maxY - 10);
			      
	          }
	          else{
	        	  g.drawString("Welcome to the third lesson! In this lesson we learn about the color theory!", 10, 15);
			      g.drawString("Color theory is a body of practical guidance to color mixing and the visual effects.", 10, 27);
			      g.drawString("Color theory is used not only to produce colors and explore their elements, ", 10, 51);
			      g.drawString("but also to convey the perceptual effects of different colors we see.  ", 10, 63);
			      g.drawString("In this lesson we will learn about additive colors and subtracitve colors;", 10, 75);
			      g.drawString("Hue, Intensity, and saturation; and about warm and cool colors.", 10, 87);
			      g.drawString("Once you are done reading this, click to continue!", 10, 123);
	          }
	     }
	     else if(phase2)
	     {
	    	
	    	 g.setColor(Color.cyan);
		      g.fillRect(50,25,134,35);
		      
		      g.setColor(Color.magenta);
		      g.fillRect(50,75,134,35);
		      
		      g.setColor(Color.yellow);
		      g.fillRect(50,125,134,35);
		      
		      g.setColor(Color.cyan);
		      g.fillRect(50,175,32,35);
		      g.setColor(Color.blue);
		      g.fillRect(152,175,32,35);
		      g.setColor(Color.magenta);
		      g.fillRect(82,175,70,35);
		      
		      g.setColor(Color.magenta);
		      g.fillRect(50,225,32,35);
		      g.setColor(Color.red);
		      g.fillRect(152,225,32,35);
		      g.setColor(Color.yellow);
		      g.fillRect(82,225,70,35);
		      
		      g.setColor(Color.yellow);
		      g.fillRect(50,275,32,35);
		      g.setColor(Color.green);
		      g.fillRect(152,275,32,35);
		      g.setColor(Color.cyan);
		      g.fillRect(82,275,70,35);
		      
		     
		      
		      
		      g.drawImage(drawSubtractive(),getWidth()/2, 0, getWidth()/2, getHeight()/2, this);
		      
		      g.setColor(Color.magenta);
		      g.drawString("The diagrams above display subtractive color mixing. According to color theory,", 10, maxY - 82);
		      g.drawString("subtractive color mixing means that colors subtract from one another when they mix.", 10, maxY - 70);
		      g.drawString("This occurs in real life with paint and ink. This means that when you put a cyan paint ", 10, maxY - 58);
		      g.drawString("and a yellow ink together, you end up with green. This happens because cyan; which   ", 10, maxY - 46);
		      g.drawString("contains green and blue will absorb red, and yellow; which contains green and red will    ", 10, maxY - 34);
		      g.drawString("absorb blue. With red and blue absorbed, all that is left is green.", 10, maxY - 22);
		      g.drawString("In subtractive color mixing, when all the ink colors are mixed you get a brown color.", 10, maxY - 10);
		     
		      
		 	 
		 	 
	     }
	     else if(phase3)
	     {
	    	 
	    	 
	    	 g.drawString("Now for Hue!", 10, 10);
		 	 g.drawString("According to color theory, hue is simply the pure color.", 10, 22);
		 	 g.drawString("Click to display a hue, and then click again to show other hues", 10, 46);
		 	 g.drawString("Hues in range of 0 through 1. Hue: "+(float)level*0.05, 10, maxY -22);
		 	 
		 	 //Color.getHSBColor(level, g);
		 	 
		 	 increasingHue(maxX,maxY,level,g);
	 		 //dragonRecur(150, 200, 275, 325, level, g);

	     }
	     else if(phase4)
	     {
	    	 
	    	 
	    	 g.drawString("Now for Saturation!", 10, 10);
		 	 g.drawString("According to color theory, saturation is the level of pure color vs white.", 10, 22);
		 	 g.drawString("Click to display a red hue with low saturation, and then click to increase saturation.", 10, 46);
		 	 g.drawString("Saturation in range of 0 through 1. Saturation: "+(float)level*0.05, 10, maxY -22);
		 	 
		 	 increasingSaturation(maxX,maxY,level,g);
	 		

	     }
	     else if(phase5)
	     {
	    	 g.drawString("Now for Brightness!", 10, 10);
		 	 g.drawString("According to color theory, brightness is simply the variation in perception of a color.", 10, 22);
		 	 g.drawString("Click to display a red hue with low brightness, and then click to increase brightness.", 10, 46);
		 	 g.drawString("Brightness in range of 0 through 1. Brightness: "+(float)level*0.05, 10, maxY -22);
		 	 
		 	 increasingBrightness(maxX,maxY,level,g);
	 		

	     }
	     
	     else if(phase6)
	     {
	    	 g.drawString("Now for an explanation of warm colors vs cool colors!", 10, 10);
		 	 g.drawString("According to color theory, there are 2 subcategories of colors; warm and cool.", 10, 22);
		 	// g.drawString("maxX is" +maxX, 10, 58); 493
		 	//g.drawString("maxY is" +maxY, 10, 70); 470
		 	 g.drawString("Warm colors; such as reds, oranges, and yellows; are typically brighter and cheerful.", 10, 34);
		 	g.drawString("Cool colors; such as purples, blues, and greens; tend to be darker and gloomy.", 10, 46);
		 	
		 	int adj = 20;
		 	
		 	//WARM
		 	g.setColor(Color.getHSBColor(0.9f, 1, 1));
		 	g.fillOval(maxX/2-adj, 80, 40, 40);
		 	g.setColor(Color.getHSBColor(0f, 1, 1));
		 	g.fillOval(309-adj, 130, 40, 40);
		 	g.setColor(Color.getHSBColor(0.1f, 1, 1));
		 	g.fillOval(371-adj, 180, 40, 40);
		 	g.setColor(Color.getHSBColor(0.2f, 1, 1));
		 	g.fillOval(433-adj, 230, 40, 40);
		 	g.setColor(Color.getHSBColor(0.25f, 1, 1));
		 	g.fillOval(371-adj, 280, 40, 40);
		 	g.setColor(Color.getHSBColor(0.3f, 1, 1));
		 	g.fillOval(309-adj, 330, 40, 40);
		 	g.setColor(Color.getHSBColor(0.4f, 1, 1));
		 	g.fillOval(maxX/2-adj, 380, 40, 40);

		 	//COOL	
		 
		 	g.setColor(Color.getHSBColor(0.5f, 1, 1));
		 	g.fillOval(185-adj, 330, 40, 40);
		 	
		 	g.setColor(Color.getHSBColor(0.6f, 1, 1));
		 	g.fillOval(123-adj, 280, 40, 40);
		 	
		 	g.setColor(Color.getHSBColor(0.65f, 1, 1));
		 	g.fillOval(61-adj, 230, 40, 40);
		 	
		 	g.setColor(Color.getHSBColor(0.7f, 1, 1));
		 	g.fillOval(123-adj, 180, 40, 40);
		 	
		 	g.setColor(Color.getHSBColor(0.8f, 1, 1));
		 	g.fillOval(185-adj, 130, 40, 40);
		 	
		 	g.setColor(Color.black);
		 	g.drawLine(maxX/2, 80, maxX/2, 430);
		 	
		 	 //g.drawString(""), x, y);
		 	 
	     }
	    	 
	    	 
	     else if(phase7)
	     {
	    	 g.drawString("Which of the following are true concerning hue, saturation, and brightness", 70, 125);
	    	 g.drawString("A. Hue is how easy it is to perceive a color, ", 70, 149);
	    	 g.drawString("B. Brightness is how easy it is to perceive a color, ", 70, 161);
	    	 g.drawString("C. Saturation is the level of pure color vs black , ", 70, 173);
	    	 if(!choice1)
	    	 g.drawString("1. A and B ", 70, 197);
	    	 if(!choice2)
	    	 g.drawString("2. Just C", 70, 209);
	    	 
	    	 
	    	 if(!choice4)
	    	 g.drawString("4. B and C", 70, 233);
	    	 g.drawString("3. Just B", 70, 221);
	     }
	     else if(finished){

	    	 g.drawString("Congratulations, you passed! ", 125, 137);
	    	 g.drawString("Click to close this window! ", 125, 149);
	     }
	}
	
	 
	 public void increasingHue(int x, int y,int k,Graphics g2d){
		 for(int i=0; i < k; ++i)
		 {
		
		g2d.setColor(Color.getHSBColor((float) (i*0.05), 1, 1));
		g2d.fillRect( x/4, y/4, x/2, y/2);
		 }
	 }
	 
	 
	 public void increasingSaturation(int x, int y,int k,Graphics g2d){
		 
		g2d.setColor(Color.getHSBColor(0, (float) (k*0.05), 1));
		g2d.fillRect( x/4, y/4, x/2, y/2);
		
	 }
	 
	 public void increasingBrightness(int x, int y,int k,Graphics g2d){
		 
			g2d.setColor(Color.getHSBColor(0, 1, (float) (k*0.05)));
			g2d.fillRect( x/4, y/4, x/2, y/2);
			
		 }
	 
	 public int iX(float x){
		 return (int)(Math.round(x));
	 }
	 
	 public int iY(float y){
		 return (int)(Math.round(y));
	 }
	 
	
}

