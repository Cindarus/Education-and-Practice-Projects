import java.awt.Canvas;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Point;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowEvent;
import java.awt.geom.Point2D;
import java.util.Random;

import javax.swing.JFrame;


class Lessons4 extends Canvas implements KeyListener
{ 
	Boolean finished = false;
	int midX, midY;
	int level, dir;
	float x, y;
	boolean phase1 = true, phase2 = false, phase3 = false, phase4 = false, choice1 = false, choice2 = false, choice3 = false;;
	PTree tree;
	
	public Boolean isFinished(){
		return finished;
	}
	
	Lessons4(JFrame temp) {
		final JFrame t = temp;
		dir = 0;
		level = -1;
		 addMouseListener(new MouseAdapter()
	      {  public void mousePressed(MouseEvent evt)
	         {
	    	  	if(phase1)
	    	  	{
	    	  		if(level < 5)
	    	  			level++;
	    	  		else
	    	  		{
	    	  			phase1 = false;
	    	  			level = 0;
		    	  		phase2 = true;
		    	  		tree = new PTree();
	    	  		}
	    	  	}
	    	  	else if(phase2){
	    	  		if(tree.getA() == null)
	    	  			tree.setA(evt.getPoint());
	    	  		else if(tree.getB() == null)
	    	  			tree.setB(evt.getPoint());
	    	  		else
	    	  		{
	    	  			tree.reset();
	    	  		}
	    	  	}
	    	  	else if(phase3){
	    	  		if(level <20)
	    	  			level++;
	    	  		else
	    	  		{
	    	  			level = 0;
	    	  			phase3 = false;
	    	  			phase4 = true;
	    	  		}
	    	  	}
	    	  	else if(phase4){
	    	  		
	    	  	}
	    	  	repaint();
				//finished = true;
				if(finished)
					t.dispatchEvent(new WindowEvent(t, WindowEvent.WINDOW_CLOSING));
			 }
		  });
		 addKeyListener(this);
	}
	
	@Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {

    	if(phase2)
    	{
	        if (e.getKeyCode() == 78 && phase2)
	        {
	        	phase3 = true;
	        	phase2 = false;
	        	repaint();
	        }
    	}
    	else if(phase4)
    	{
    		if(e.getKeyCode() == 49)
    		{
    			choice1 = true;
    			repaint();
    		}
    		if(e.getKeyCode() == 50)
    		{
    			choice2 = true;
    			repaint();
    		}
    		if(e.getKeyCode() == 51)
    		{
    			choice3 = true;
    			repaint();
    		}
    		if(e.getKeyCode() == 52)
    		{
    			finished = true;
    			phase4 = false;
    			repaint();
    		}
    	}

        
    }

    @Override
    public void keyReleased(KeyEvent e) {
      
    }
    
	 public void paint(Graphics g)
    {
		 Dimension d = getSize();
	      int maxX = d.width - 1, maxY = d.height - 1;
	     if(phase1)
	     {
	          if(level >= 0){
		          int lengthX = maxX * 4 / 3, lengthY = maxY * 2/3;
			      int len = 260;
			      midX = maxX/2; midY = maxY/2;
			      x = 600;          // Start point
			      y = 300;
			      dir = -120;
			      x = lengthX/3; y = lengthY;
			      drawKoch(g, len, level);
			      dir+=120;
			      drawKoch(g, len, level);
			      dir+=120;
			      drawKoch(g, len, level);
			      g.drawString("     This is a Koch Snowflake, created by making a triangle in the middle", 10, maxY - 22);
			      g.drawString("     of each line segment. Click to see further generations.", 10, maxY - 10);
			      g.drawString("Generation = " + level, maxX/2 - 80, maxY - 60);
	          }
	          else{
	        	  g.drawString("Welcome to the first lesson! Here you will learn about the exciting world of fractals!", 10, 15);
			      g.drawString("Fractals are patterns that repeat endlessly.", 10, 27);
			      g.drawString("Fractals are used to create models that closely resemble natural phenomena, like trees", 10, 39);
			      g.drawString("The branches growing in a very fractal like way, so understanding fractals helps", 10, 51);
			      g.drawString("us to better understand the natural world. Lastly, it can help those in the computer", 10, 63);
			      g.drawString("science field to visualize the idea of recursion.", 10, 75);
			      g.drawString("Once you are done reading this, click to continue!", 10, 111);
	          }
	     }
	     else if(phase2)
	     {
	    	 g.setColor(Color.black);
		 		
		 		// If points are found, draw tree
		 		if(tree.getB() != null)
		 		{
		 			tree.draw(g, tree.getA(), tree.getB());
		 		}
		 		else
		 		{
		 			g.fillOval(170, 300, 10, 10);
				 	g.fillOval(225, 300, 10, 10);
		 		}
		 	 g.drawString("A Pythagoras Tree is made by drawing a right triangle off a side of a square", 10, 10);
		 	 g.drawString("Then, draw a square off the base of the right triangle, repeat infinitely", 10, 22);
		 	 g.drawString("Click any 2 points to draw a Pythagoras Tree.", 10, 34);
		 	 g.drawString("The third click will erase the tree.", 10, 46);
		  	 g.drawString("Click the 2 points below to try it out!", 10, 58);
		 	 g.drawString("Press N when you are ready to move on.", 10, 70);
		 	 
	     }
	     else if(phase3)
	     {
	    	 g.drawString("This is a Dragon Curve", 10, 10);
		 	 g.drawString("A dragon curve is made similarly to a Koch curve", 10, 22);
		 	 g.drawString("Except here the entire segment is changed to a right triangle with no hypotenuse", 10, 34);
		  	 g.drawString("Click to see further generations", 10, 46);
		     g.drawString("Generation = " + level, maxX/2 - 80, maxY - 60);
	 		 dragonRecur(150, 200, 275, 325, level, g);

	     }
	     else if(phase4)
	     {
	    	 g.drawString("What is a reason to use fractals?", 70, 125);
	    	 if(!choice1)
	    	 g.drawString("1. For 3d modeling", 70, 137);
	    	 if(!choice2)
	    		 g.drawString("2. To understand how the natural world works, like branches on a tree", 70, 149);
	    	 if(!choice3)
	    		 g.drawString("3. To better one's understanding of recursion", 70, 161);
	    	 g.drawString("4. All of the above", 70, 173);
	     }
	     else if(finished){

	    	 g.drawString("Congratulations, you passed! ", 125, 137);
	    	 g.drawString("Click to close this window! ", 125, 149);
	     }
	}
	
	 public void drawKoch(Graphics g, int len, int n)
	   {  
		   int deltaX, deltaY, x2, y2, x3, y3, x4, y4;
		   double dirRad = dir * Math.PI/180;
		   if (n == 0)
	      {  double xInc, yInc;
	         xInc = len * Math.cos(dirRad);   // x increment
	         yInc = len * Math.sin(dirRad);   // y increment
	         float xT = x + (float)xInc,
	               yT = y + (float)yInc;
	         g.drawLine(iX(x), iY(y), iX(xT), iY(yT));
	         x = xT;
	         y = yT;
	}
	      else
	      {   
	    	 drawKoch(g, len/=3, --n);
	         dir -= 60;
	         drawKoch(g, len, n);
	         dir+=120;
	         drawKoch(g, len, n);
	         dir-= 60;
	         drawKoch(g, len, n);
	      }
	   }
	 
	 public void dragonRecur(int x1, int y1, int x2, int y2, int k,
				Graphics g2d) {
			if (k > 0) {
				int xn = (x1 + x2) / 2 + (y2 - y1) / 2;
				int yn = (y1 + y2) / 2 - (x2 - x1) / 2;
				dragonRecur(x2, y2, xn, yn, k - 1, g2d);
				dragonRecur(x1, y1, xn, yn, k - 1, g2d);
			} else {
				g2d.drawLine(x1, y1, x2, y2);
			}
		}
	 
	 public int iX(float x){
		 return (int)(Math.round(x));
	 }
	 
	 public int iY(float y){
		 return (int)(Math.round(y));
	 }
	 
	 class PTree
	 {
	 	int centerX, centerY;
	 	float pixelSize, width = 10.0F, height = 10.0F,
	 			actualWidth, actualHeight;
	 	float r = -1;
	 	
	 	Random random;
	 	long seed = System.currentTimeMillis();
	 	
	 	
	 	Point2F a, b;

	 	
	 	// Calculate new values for mapping
	 	public PTree()
	 	{
	 		Dimension d = getSize();
	 		int maxX = d.width - 1, maxY = d.height - 1;
	 		pixelSize = Math.max(width / maxX, height / maxY);
	 		centerY = maxY / 2;
	 		centerX = maxX / 2;
	 		
	 		//Accounts for difference in pixel sizes
	 		actualWidth = maxX * pixelSize;
	 		actualHeight = maxY * pixelSize;
	 		
	 		random = new Random(seed);
	 	}
	 	
	 	public void reset(){
	 		a = null;
	 		b = null;
	 	}
	 	
	 	public void setA(Point2D p){
	 		a = fp(p);
	 	}
	 	
	 	public void setB(Point2D p){
	 		b = fp(p);
	 	}
	 	
	 	public Point2F getA()
	 	{
	 		return a;
	 	}
	 	
	 	public Point2F getB()
	 	{
	 		return b;
	 	}
	 	
	 	// Recursively draws a tree of Pythagoras, adding the points to A and B
	 	public void draw(Graphics g, Point2F A, Point2F B)
	 	{
	 		// Can't draw if size isn't > 2)
	 		if(!(A.distanceSquared(B) <= pixelSize))
	 		{
	 			// Calculate points C and D for the square
	 			// Find vector AB
	 			Point2F AB = B.sub(A);
	 			
	 			// Rotate 
	 			Point2F ABRot = new Point2F(-AB.y, AB.x);
	 			
	 			Point2F C = B.add(ABRot);
	 			Point2F D = A.add(ABRot);
	 			
	 			// Calculate next point
	 			Point2F E = new Point2F((C.x + D.x) / 2, (C.y + D.y) / 2).add(ABRot.scale(.5f));
	 			
	 			// Fill the square and triangle
	 			
	 			//random color so that it looks cool
	 			g.setColor(new Color(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
	 			g.fillPolygon(new int[] {iX(A.x), iX(B.x), iX(C.x), iX(D.x)}, new int[] {iY(A.y), iY(B.y), iY(C.y), iY(D.y)
	 			}, 4);
	 			
	 			g.setColor(new Color(random.nextInt(256), random.nextInt(256), random.nextInt(256)));
	 			
	 			g.fillPolygon(new int[] {iX(D.x), iX(C.x), iX(E.x)}, new int[] {iY(D.y), iY(C.y), iY(E.y)}, 3);
	 			
	 			g.setColor(Color.black);
	 			
	 			// Draw the square and draw the triangle
	 			g.drawLine(iX(A.x), iY(A.y), iX(B.x), iY(B.y));
	 			g.drawLine(iX(B.x), iY(B.y), iX(C.x), iY(C.y));
	 			g.drawLine(iX(C.x), iY(C.y), iX(D.x), iY(D.y));
	 			g.drawLine(iX(D.x), iY(D.y), iX(A.x), iY(A.y));
	 			g.drawLine(iX(D.x), iY(D.y), iX(C.x), iY(C.y));
	 			g.drawLine(iX(C.x), iY(C.y), iX(E.x), iY(E.y));
	 			g.drawLine(iX(E.x), iY(E.y), iX(D.x), iY(D.y));
	 			
	 			// Make a recursive call
	 			draw(g, D, E);
	 			draw(g, E, C);
	 		}
	 	}
	 	
	 	// For use with 2d points
	 	class Point2F
	 	{
	 		public float x,y;
	 		public Point2F(float x, float y)
	 		{
	 			this.x = x;
	 			this.y = y;
	 		}
	 		
	 		// Returns new Point2F that is current plus p
	 		public Point2F add(Point2F p)
	 		{
	 			return new Point2F(x + p.x, y + p.y);
	 		}
	 		
	 		// Scale the Point by a factor of s
	 		public Point2F scale(float s)
	 		{
	 			return new Point2F(x*s, y*s);
	 		}
	 		
	 		// Give opposite value of Point
	 		public Point2F neg()
	 		{
	 			return scale(-1);
	 		}
	 		
	 		// Subtract p from current and return
	 		public Point2F sub(Point2F p)
	 		{
	 			return add(p.neg());
	 		}
	 		
	 		// Returns distance squared from current to P
	 		public float distanceSquared(Point2F p)
	 		{
	 			return (p.x-x)*(p.x-x) + (p.y-y)*(p.y-y);
	 		}
	 	}
	 	
	 	// Functions taken from the book
	 		int iX(float x)
	 		{
	 			return Math.round(centerX + x / pixelSize);
	 		}

	 		int iY(float y)
	 		{
	 			return Math.round(centerY - y / pixelSize);
	 		}
	 		
	 		Point iP(Point2F p)
	 		{
	 			return new Point(iX(p.x), iY(p.y));
	 		}

	 		float fx(int X)
	 		{
	 			return (X - centerX) * pixelSize;
	 		}

	 		float fy(int Y)
	 		{
	 			return (centerY - Y) * pixelSize;
	 		}

	 		Point2F fp(Point2D p)
	 		{
	 			return new Point2F(fx((int) p.getX()), fy((int) p.getY()));
	 		}
	 }
}

