To run the game you can:

1) Open the folder named release - double click the WumpusHunter3000.exe

2) Double click the WumpusHunter3000.sln - click on the "Start" button at the top of the window if you have Visual Studio


How to Play:

You can interact with the game with the MOVE and AIM buttons.

When Moving, click on move then click on rooms adjacent to your player sprite (the green sprite)

To Shoot, click on AIM then click on rooms that the arrow can follow. It will allow you to click on rooms not connected but it will take a random path.
Once all the rooms, up to 5 are selected, click the fire button.

If you win or lose, you won't be able to do any actions until you choose to either randomize or take the same map which have buttons provided at the
bottom right.


Green Sprite - Player
Brown Sprite - Wumpus
Blue Sprite - Bats
Grey Sprite - Pit
