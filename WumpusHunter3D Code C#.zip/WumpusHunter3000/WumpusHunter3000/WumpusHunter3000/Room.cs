﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework.Graphics;

namespace WumpusHunter3000
{
    public class Room
    {
        int[] connect = new int[3];
        public int hazard; //0=nothing, 1=bats, 2=pit, 3= player start, 4= wumpus start

        public Room(int a, int b, int c)
        {
            connect[0] = a;
            connect[1] = b;
            connect[2] = c;
            hazard = 0;
            
            
        }

        public int[] getConnect()
        {
            return connect;
        }


    }
}
