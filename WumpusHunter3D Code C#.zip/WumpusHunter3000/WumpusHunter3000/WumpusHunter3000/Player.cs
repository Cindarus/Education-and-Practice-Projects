﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WumpusHunter3000
{
    public class Player
    {
        public Boolean pMessage1 = false;
        public Boolean pMessage2 = false;
        public Boolean pMessage3 = false;
        public Boolean pMessage4 = false;
        public Boolean pMessage5 = false;
        public Boolean pMessage6 = false;
        public Boolean pMessage7 = false;
        public Boolean pMessage8 = false;
        private int location;
        string input;

        public Player(int loc)
        {
            location = loc;
        }

        public void detect(Room a, Room[] b)
        {
            System.Console.WriteLine("\n");
            for (int i = 0; i < 3; i++)
            {
                if (b[a.getConnect()[i]].hazard == 1)
                { 
                    pMessage1 = true;
                    System.Console.WriteLine("Bats Nearby!\n");
                }
                //else
                //    pMessage1 = false;
                if (b[a.getConnect()[i]].hazard == 2)
                { 
                    pMessage2 = true;
                    System.Console.WriteLine("I feel a draft!\n");
                }
                //else
                //    pMessage2 = false;
                if (b[a.getConnect()[i]].hazard >= 4)
                {
                    pMessage3 = true;
                    System.Console.WriteLine("I smell a Wumpus!\n");
                }
                //else
                //    pMessage3 = false;
            }

        }





        public void bats()
        {
            pMessage4 = true;// System.Console.WriteLine("\nZap--Super Bat snatch! Elsewhereville for you!");
        }

        public void pit()
        {
            pMessage5 = true;// System.Console.WriteLine("\nYYYIIIIEEEE... fell in a pit");
        }

        public string wumpus(Wumpus a)
        {
            String death = "";
            if (a.getWoke() == false)
            {
                pMessage6 = true; //System.Console.WriteLine("\nOoops! Bumped a Wumpus");
                a.wakeUp();


            }
            else if (a.getWoke() == true)
            {
                pMessage7 = true; //System.Console.WriteLine("\nOH NO THE WUughhgh...\n");
                death = die();
            }
            return death;

        }

        public String die()
        {
            pMessage8 = true;
            //System.Console.WriteLine("OH NO YOU DIED!\n\n\n");
            //System.Console.WriteLine("Would you like to play the same map or randomize to a new one?\nS - Same Map\nR - Randomize to a new Map");
            input = System.Console.ReadLine();
            while (input != "R" && input != "r" && input != "S" && input != "s")
            {
                System.Console.WriteLine("nope bad input");
                input = System.Console.ReadLine();
            }
            return input;

        }

        public int getLocation()
        {
            return location;
        }

        public int setLocation(int a)
        {
            location = a;
            return location;
        }

        public void reset()
        {
            pMessage1 = false;
            pMessage2 = false;
            pMessage3 = false;
            pMessage4 = false;
            pMessage5 = false;
            pMessage6 = false;
            pMessage7 = false;
            pMessage8 = false;

        }
    }
}
