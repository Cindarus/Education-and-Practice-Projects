﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;
using Primitives3D;

namespace WumpusHunter3000

{
   
    public class Game1 : Microsoft.Xna.Framework.Game
    {
        private static readonly TimeSpan intervalBetweenRoom = TimeSpan.FromMilliseconds(1000);
        private TimeSpan lastTimeRoom = TimeSpan.FromMilliseconds(0);
        GeometricPrimitive[] spheres = new GeometricPrimitive[20];
        GeometricPrimitive[] halls = new GeometricPrimitive[20];
        Vector3 cameraPosition = new Vector3(640f, 360f, 720f);
        Vector3 cameraFocus = new Vector3(640f, 360f, 0f);
        Matrix[] spherePOS = new Matrix[20];
        Matrix[] hallPOS = new Matrix[30];

        // Store a list of tint colors, plus which one is currently selected.
        List<Color> colors = new List<Color>
        {
            Color.White,
            Color.Blue,
            Color.Black,
            Color.Green,
            Color.Brown,
        };



        GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        SpriteFont myFont;
        Room[] arena1;
        Map map1;
        

        int cameraIndex;

        List<GeometricPrimitive> primitives = new List<GeometricPrimitive>();
        Texture2D t;
        Texture2D roomE, roomB, roomP, roomW, roomPl, Pmove, Pshoot, Hmove, Hshoot, Hroom, go, random, samemap;

        Player you;
        Wumpus wump;

        static int backward = -1; // prevents arrows from going backward
        static int arrows;
        static int pstart;
        static int wstart;
        int index = 0;
        static int pathcounter = 0;
        static int currentIndex =-1, previousIndex =-1;
        static int j = 0;

        

        static Boolean win = false;
        static Boolean nofix = false; // This prevents the arrows from realigning themselves to the path after veering off.
        static Boolean step1 = true;
        static Boolean step2 = false;
        static Boolean step3 = false;
        MouseState oldMouseState;

        //DRAW FLAGS - so the draw method will decide to give text announcements
        static Boolean message1 = false; // Wumpus is here!
        static Boolean message2 = true;  // Nearby Rooms
        static Boolean message3 = false; // Move Instructions
        static Boolean message4 = false; // Shoot Instructions
        static Boolean message5 = false; // Arrows Crooked 
        static Boolean message6 = false; // Shooting yourself
        static Boolean message7 = false; // Shooting Wumpus
        static Boolean message8 = false; // WIN
        static Boolean message9 = false; // MISSED!!!
        static Boolean message10 = false; //Out of arrows!
        static Boolean message11 = false; // LOSE

        static Boolean release = false;

        static Boolean zoomed = false;

        static int batsprite = -1;
        static int pitsprite = -1;
        static int wumpussprite = -1;


        Rectangle moveArea = new Rectangle(1180, 600, 96, 48);
        Rectangle shootArea = new Rectangle(1180, 650, 96, 48);
        Rectangle goArea = new Rectangle(1080, 650, 96, 48);
        Rectangle sameArea = new Rectangle(105, 650, 96, 48);
        Rectangle randomArea = new Rectangle(5, 650, 96, 48);

        Vector2[] roomPOS = new Vector2[20];
        Rectangle[] roomAreas = new Rectangle[20];
        
        

        int[] path;


       

        public void reset()
        {
            message1 = false;
            message2 = true;
            message3 = false;
            message4 = false;
            message5 = false;
            message6 = false;
            message7 = false;
            message8 = false;
            message9 = false;
            message10 = false;
            message11 = false;
        }

        public class Map
        {
            Vector3 midPOS(Vector3 pos1, Vector3 pos2)
            {
                Vector3 mid;
                mid = new Vector3((pos1.X + pos2.X) / 2, (pos1.Y + pos2.Y) / 2, 0);
                return mid;
            }

            public Room[] createArena()
            {
                

                Room[] Arena = new Room[20];
                Arena[0] = new Room(10, 1, 2);
                Arena[1] = new Room(0, 4, 15);
                Arena[2] = new Room(0, 6, 3);
                Arena[3] = new Room(5, 4, 2);
                Arena[4] = new Room(3, 1, 9);
                Arena[5] = new Room(7, 3, 8);
                Arena[6] = new Room(11, 2, 7);
                Arena[7] = new Room(6, 12, 5);
                Arena[8] = new Room(5, 13, 9);
                Arena[9] = new Room(8, 4, 14);
                Arena[10] = new Room(0, 11, 19);
                Arena[11] = new Room(10, 6, 16);
                Arena[12] = new Room(16, 7, 13);
                Arena[13] = new Room(12, 8, 17);
                Arena[14] = new Room(17, 15, 9);
                Arena[15] = new Room(14, 1, 19);
                Arena[16] = new Room(11, 12, 18);
                Arena[17] = new Room(18, 14, 13);
                Arena[18] = new Room(16, 17, 19);
                Arena[19] = new Room(10, 15, 18);
                
                //Provide the connections between rooms

                Random random = new Random();
                int temp1 = random.Next(20);
                Arena[temp1].hazard = 1;
                // Random room given bats.


                int temp2 = random.Next(20);
                while (temp1 == temp2)
                {
                    temp2 = random.Next(20);
                }
                Arena[temp2].hazard = 1;
                // Random room given bats. Bats can't be in the same place.


                int temp3 = random.Next(20);
                while (temp1 == temp3 || temp2 == temp3)
                {
                    temp3 = random.Next(20);
                }
                Arena[temp3].hazard = 2;
                // Random room assigned to pit1. Cant be same as bats


                int temp4 = random.Next(20);
                while (temp1 == temp4 || temp2 == temp4 || temp3 == temp4)
                {
                    temp4 = random.Next(20);
                }
                Arena[temp4].hazard = 2;
                // Random room assigned to pit2. Cant be same as bats or other pit.

                //---------------------
                int temp5 = random.Next(20);
                while (temp1 == temp5 || temp2 == temp5 || temp3 == temp5 || temp4 == temp5)
                {
                    temp5 = random.Next(20);
                }
                Arena[temp5].hazard = 3;
                pstart = temp5;
               // System.Console.WriteLine("TEST" + temp5);
                // Player start location


                int temp6 = random.Next(20);
                while (temp1 == temp6 || temp2 == temp6 || temp3 == temp6 || temp4 == temp6 || temp5 == temp6)
                {
                    temp6 = random.Next(20);
                }
                Arena[temp6].hazard = 4;
                wstart = temp6;
                // Wumpus start location


                return Arena;
            }

            public void describeMap(Room[] arena1, Player you, Wumpus wump)
            {
                arena1[wump.getLocation()].hazard -= 4;
                arena1[wstart].hazard = 4;
                for (int i = 0; i < 20; i++)
                {
                 
                    if (arena1[i].hazard == 3) 
                    {
                        pstart = i;
                    }

                    if (arena1[i].hazard == 4) 
                    {
                        wstart = i;
                    }
                }

                you.setLocation(pstart);
                wump.setLocation(wstart);

            }
        }
        #region methods
        public int clickRoom(Rectangle [] roomAreas)
        {
            var mouseState = Mouse.GetState();
            var mousePosition = new Point(mouseState.X, mouseState.Y);
            for (int i = 0; i < 20; i++)
            {
                if (roomAreas[i].Contains(mousePosition))
                {
                    
                    return i;
                }
            }
            //System.Console.WriteLine(mouseState.X + " , " + mouseState.Y);
            return -1;
        }

        public void winner()
        {
            win = true;

            message8 = true;
            System.Console.WriteLine("\nHee hee hee - the Wumpus'll getcha next time!!\n\n");
            System.Console.WriteLine("Would you like to play the same map or randomize to a new one?\nS - Same Map\nR - Randomize to a new Map");


        }

        void DrawLine(SpriteBatch sb, Vector2 start, Vector2 end)
        {
            Vector2 edge = end - start;
            // calculate angle to rotate line
            float angle =
                (float)Math.Atan2(edge.Y, edge.X);


            sb.Draw(t,
                new Rectangle(// rectangle defines shape of line and position of start of line
                    (int)start.X,
                    (int)start.Y,
                    (int)edge.Length(), //sb will strech the texture to fill this rectangle
                    1), //width of line, change this to make thicker line
                null,
                Color.Red, //colour of line
                angle,     //angle of line (calulated above)
                new Vector2(0, 0), // point in line about which to rotate
                SpriteEffects.None,
                0);

        }


        void DrawLine(SpriteBatch sb, Vector2 start, Vector2 end, int thickness, Color color)
        {
            Vector2 edge = end - start;
            // calculate angle to rotate line
            float angle =
                (float)Math.Atan2(edge.Y, edge.X);


            sb.Draw(t,
                new Rectangle(// rectangle defines shape of line and position of start of line
                    (int)start.X,
                    (int)start.Y,
                    (int)edge.Length(), //sb will strech the texture to fill this rectangle
                    thickness), //width of line, change this to make thicker line
                null,
                color, //colour of line
                angle,     //angle of line (calulated above)
                new Vector2(0, 0), // point in line about which to rotate
                SpriteEffects.None,
                0);

        }

        public void Zoom(int index, float time)
        {

            //cameraFocus = new Vector3(spherePOS[index].M41, spherePOS[index].M42, spherePOS[index].M43);
            if (cameraPosition.X > spherePOS[index].M41 + 10)
            {
                cameraPosition = new Vector3(cameraPosition.X -= 5, cameraPosition.Y, cameraPosition.Z);
                zoomed = false;
            }
            if (cameraPosition.X < spherePOS[index].M41 + 10)
            {
                cameraPosition = new Vector3(cameraPosition.X += 5, cameraPosition.Y, cameraPosition.Z);
                zoomed = false;
            }
            if (cameraPosition.Y > spherePOS[index].M42 + 25)
            {
                cameraPosition = new Vector3(cameraPosition.X, cameraPosition.Y -= 5, cameraPosition.Z);
                zoomed = false;
            }
            if (cameraPosition.Y < spherePOS[index].M42 + 25)
            { 
                zoomed = false;
                cameraPosition = new Vector3(cameraPosition.X, cameraPosition.Y += 5, cameraPosition.Z);
            }
            if (cameraPosition.Z > spherePOS[index].M43+30)
                cameraPosition = new Vector3(cameraPosition.X, cameraPosition.Y, cameraPosition.Z -=5);
            if (cameraPosition.Z < spherePOS[index].M43 + 30)
                cameraPosition = new Vector3(cameraPosition.X, cameraPosition.Y, cameraPosition.Z +=5);


            if (cameraFocus.X > spherePOS[index].M41)
                cameraFocus = new Vector3(cameraFocus.X -= 4, cameraFocus.Y, cameraFocus.Z);
            if (cameraFocus.X < spherePOS[index].M41)
                cameraFocus = new Vector3(cameraFocus.X += 4, cameraFocus.Y, cameraFocus.Z);
            if (cameraFocus.Y > spherePOS[index].M42)
                cameraFocus = new Vector3(cameraFocus.X, cameraFocus.Y -= 4, cameraFocus.Z);
            if (cameraFocus.Y < spherePOS[index].M42)
                cameraFocus = new Vector3(cameraFocus.X, cameraFocus.Y += 4, cameraFocus.Z);
            if (cameraFocus.Z > spherePOS[index].M43)
                cameraFocus = new Vector3(cameraFocus.X, cameraFocus.Y, cameraFocus.Z -= 4);
            if (cameraFocus.Z < spherePOS[index].M43)
                cameraFocus = new Vector3(cameraFocus.X, cameraFocus.Y, cameraFocus.Z += 4);

            if ((cameraPosition.X > spherePOS[index].M41+6  && cameraPosition.X < spherePOS[index].M41+16) 
            &&  (cameraPosition.Y > spherePOS[index].M42+21 && cameraPosition.Y < spherePOS[index].M42+31) 
            &&  (cameraPosition.Z > spherePOS[index].M43+26 && cameraPosition.Z < spherePOS[index].M43+34))
            {
                //System.Console.WriteLine("path is " + path[0] + " " + path[1] + " " + path[2] + " " + path[3] + " " + path[4] );
                zoomed = true;
                
            }
        }

        public void shoot(int ploc, int wloc, int[] path, Room[] a, int pathcounter, GameTime gameTime)
        {

            Random random = new Random();
            int temp = ploc;
            int x = pathcounter;
            for (int i = 0; i < x; i++)
            {
                if ((path[i] == a[temp].getConnect()[0] || path[i] == a[temp].getConnect()[1] || path[i] == a[temp].getConnect()[2]) && nofix == false)
                {
                    backward = temp;
                    temp = path[i];
                    //cameraIndex = temp;
                   // lastTimeRoom = gameTime.TotalGameTime;  
                    if (temp == wloc)
                    {
                        nofix = false;
                        message7 = true;
                        System.Console.WriteLine("Aha! You got the Wumpus!");
                        winner();

                    }
                    else if (temp == ploc)
                    {
                        nofix = false;
                        message6 = true;
                        System.Console.WriteLine("Ouch! Arrow got you!");
                        winner();
                    }
                }
                else
                {
                    nofix = true;
                    int temp2;
                    int rand;
                    temp2 = random.Next(3);
                    while (backward == a[temp].getConnect()[temp2])
                    {
                        temp2 = random.Next(3);
                    }

                    rand = temp2;

                    switch (rand)
                    {
                        case (0):
                            backward = temp;
                            temp = a[temp].getConnect()[0];
                            //cameraIndex = temp;
                            path[i] = temp;
                             if (temp == wloc)
                            {
                                nofix = false;
                                message7 = true;
                                System.Console.WriteLine("Aha! You got the Wumpus!");
                                winner();

                            }
                            if (temp == ploc)
                            {
                                nofix = false;
                                message6 = true;
                                System.Console.WriteLine("Ouch! Arrow got you!");
                                winner();
                            }
                            break;
                        case (1):
                            backward = temp;
                            temp = a[temp].getConnect()[1];
                            //cameraIndex = temp;
                                path[i] = temp;
                                if (temp == wloc)
                            {
                                nofix = false;
                                message7 = true;
                                System.Console.WriteLine("Aha! You got the Wumpus!");
                                winner();

                            }
                            if (temp == ploc)
                            {
                                nofix = false;
                                message6 = true;
                                System.Console.WriteLine("Ouch! Arrow got you!");
                                winner();
                            }
                            break;
                        case (2):
                            backward = temp;
                            temp = a[temp].getConnect()[2];
                                path[i] = temp;
                                //cameraIndex = temp;
                            if (temp == wloc)
                            {
                                nofix = false;
                                message7 = true;
                                System.Console.WriteLine("Aha! You got the Wumpus!");
                                winner();

                            }
                            if (temp == ploc)
                            {
                                nofix = false;
                                message6 = true;
                                System.Console.WriteLine("Ouch! Arrow got you!");
                                winner();
                            }
                            break;

                    }
                    System.Console.WriteLine("arrow has veered off your path");

                    System.Console.WriteLine("The arrow is at room " + temp);
                }



            }
            
            nofix = false;
            backward = -1;
        }

        public Vector2 adjustpos(Vector2 position, int x, int y)
        {
            Vector2 temp = position;
            temp.X += x;
            temp.Y += y;
            return temp;
        }
#endregion


        /// <summary>
        /// /////////////////////////////////////////////////BARRIER OF METHODS
        /// </summary>
        public Game1()
        {
            
            Content.RootDirectory = "Content";
            graphics = new GraphicsDeviceManager(this);
            graphics.PreferredBackBufferWidth = 1280;
            graphics.PreferredBackBufferHeight = 720;
            
            map1 = new Map();
            arena1 = map1.createArena();
            you = new Player(pstart);
            wump = new Wumpus(wstart);
            map1.describeMap(arena1, you, wump);
            arrows = 5;
            cameraIndex = you.getLocation();


            path = new int[] { -1, -1, -1, -1, -1, };
            path[0] = you.getLocation();

            roomPOS[0] = new Vector2(126, 26);
            roomAreas[0] = new Rectangle(126, 26, 48, 48);
            roomPOS[1] = new Vector2(476, 26);
            roomAreas[1] = new Rectangle(476, 26, 48, 48);
            roomPOS[2] = new Vector2(176, 76);
            roomAreas[2] = new Rectangle(176, 76, 48, 48);
            roomPOS[3] = new Vector2(301, 76);
            roomAreas[3] = new Rectangle(301, 76, 48, 48);
            roomPOS[4] = new Vector2(426, 76);
            roomAreas[4] = new Rectangle(426, 76, 48, 48);
            roomPOS[5] = new Vector2(301, 151);
            roomAreas[5] = new Rectangle(301, 151, 48, 48);
            roomPOS[6] = new Vector2(151, 176);
            roomAreas[6] = new Rectangle(151, 176, 48, 48);
            roomPOS[7] = new Vector2(226, 201);
            roomAreas[7] = new Rectangle(226, 201, 48, 48);
            roomPOS[8] = new Vector2(376, 201);
            roomAreas[8] = new Rectangle(376, 201, 48, 48);
            roomPOS[9] = new Vector2(451, 176);
            roomAreas[9] = new Rectangle(451, 176, 48, 48);
            roomPOS[10] = new Vector2(51, 326);
            roomAreas[10] = new Rectangle(51, 326, 48, 48);
            roomPOS[11] = new Vector2(126, 301);
            roomAreas[11] = new Rectangle(126, 301, 48, 48);
            roomPOS[12] = new Vector2(251, 301);
            roomAreas[12] = new Rectangle(251, 301, 48, 48);
            roomPOS[13] = new Vector2(351, 301);
            roomAreas[13] = new Rectangle(351, 301, 48, 48);
            roomPOS[14] = new Vector2(476, 301);
            roomAreas[14] = new Rectangle(476, 301, 48, 48);
            roomPOS[15] = new Vector2(551, 326);
            roomAreas[15] = new Rectangle(551, 326, 48, 48);
            roomPOS[16] = new Vector2(201, 351);
            roomAreas[16] = new Rectangle(201, 351, 48, 48);
            roomPOS[17] = new Vector2(401, 351);
            roomAreas[17] = new Rectangle(401, 351, 48, 48);
            roomPOS[18] = new Vector2(301, 412);
            roomAreas[18] = new Rectangle(301, 412, 48, 48);
            roomPOS[19] = new Vector2(301, 526);
            roomAreas[19] = new Rectangle(301, 526, 48, 48);

            #region spheres
            //spherePOS[0] = Matrix.CreateTranslation(new Vector3(600f, 300f, 975f));
            spherePOS[0] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(476f, 26f, 000f);
            spherePOS[1] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(126f, 26f, 000f);
            spherePOS[2] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(426f, 76f, 000f);
            spherePOS[3] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(301f, 76f, 000f);
            spherePOS[4] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(176f, 76f, 000f);
            spherePOS[5] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(301f, 151f, 000f);
            spherePOS[6] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(451f, 176f, 000f);
            spherePOS[7] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(376f, 201f, 000f);
            spherePOS[8] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(226f, 201f, 000f);
            spherePOS[9] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(151f, 176f, 000f);
            spherePOS[10] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(551f, 326f, 000f);
            spherePOS[11] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(476f, 301f, 000f);
            spherePOS[12] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(351f, 301f, 000f);
            spherePOS[13] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(251f, 301f, 000f);
            spherePOS[14] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(126f, 301f, 000f);
            spherePOS[15] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(51f, 326f, 000f);
            spherePOS[16] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(401f, 351, 000f);
            spherePOS[17] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(201f, 351f, 000f);
            spherePOS[18] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(301f, 412f, 000f);
            spherePOS[19] = Matrix.CreateScale(40.0f) * Matrix.CreateTranslation(301f, 526f, 000f);
            #endregion
            //
            #region hallPOS
            //0 
            hallPOS[0] = Matrix.CreateScale(20,350,30) * Matrix.CreateRotationZ(1.571f) *
                Matrix.CreateTranslation(301f, 26f, 000f);
            hallPOS[1] = Matrix.CreateScale(20, 75, 30) * Matrix.CreateRotationZ(1f) *
                Matrix.CreateTranslation(451f, 51f, 000f);
            hallPOS[2] = Matrix.CreateScale(20, 320, 30) * Matrix.CreateRotationZ(-0.240f) *
                Matrix.CreateTranslation(521f, 176f, 000f);

            //1
            hallPOS[3] = Matrix.CreateScale(20, 70, 30) * Matrix.CreateRotationZ(-1f) *
                Matrix.CreateTranslation(151f, 51f, 000f);
            hallPOS[4] = Matrix.CreateScale(20, 320, 30) * Matrix.CreateRotationZ(.24f) *
                Matrix.CreateTranslation(89f, 176f, 000f);

            //2
            hallPOS[5] = Matrix.CreateScale(20, 100, 30) * Matrix.CreateRotationZ(1.571f) *
                Matrix.CreateTranslation(364f, 76f, 000f);
            hallPOS[6] = Matrix.CreateScale(20,100, 30) * Matrix.CreateRotationZ(-.24f) *
                Matrix.CreateTranslation(438f, 126f, 000f);

            //3
            hallPOS[7] = Matrix.CreateScale(20, 100, 30) * Matrix.CreateRotationZ(1.571f) *
                Matrix.CreateTranslation(240f, 76f, 000f);
            hallPOS[8] = Matrix.CreateScale(20, 100, 30) * Matrix.CreateRotationZ(0f) *
                Matrix.CreateTranslation(301f, 114f, 000f);

            //4
            hallPOS[9] = Matrix.CreateScale(20, 100, 30) * Matrix.CreateRotationZ(.24f) *
                Matrix.CreateTranslation(164f, 126f, 000f);

            //5
            hallPOS[10] = Matrix.CreateScale(20, 100, 30) * Matrix.CreateRotationZ(-1f) *
                Matrix.CreateTranslation(339f, 176f, 000f);
            hallPOS[11] = Matrix.CreateScale(20, 100, 30) * Matrix.CreateRotationZ(1f) *
                Matrix.CreateTranslation(264f, 176f, 000f);

            //6
            hallPOS[12] = Matrix.CreateScale(20, 100, 30) * Matrix.CreateRotationZ(1.15f) *
                Matrix.CreateTranslation(414f, 190f, 000f);
            hallPOS[13] = Matrix.CreateScale(20, 100, 30) * Matrix.CreateRotationZ(-.24f) *
                Matrix.CreateTranslation(464f, 240f, 000f);

            //7
            hallPOS[14] = Matrix.CreateScale(20, 100, 30) * Matrix.CreateRotationZ(.24f) *
                Matrix.CreateTranslation(364f, 251f, 000f);

            //8
            hallPOS[15] = Matrix.CreateScale(20, 85, 30) * Matrix.CreateRotationZ(-1.1f) *
                Matrix.CreateTranslation(190f, 190f, 000f);
            hallPOS[16] = Matrix.CreateScale(20, 100, 30) * Matrix.CreateRotationZ(-.24f) *
                Matrix.CreateTranslation(240f, 251f, 000f);

            //9
            hallPOS[17] = Matrix.CreateScale(20, 100, 30) * Matrix.CreateRotationZ(.24f) *
                Matrix.CreateTranslation(140f, 240f, 000f);

            //10
            hallPOS[18] = Matrix.CreateScale(20, 85, 30) * Matrix.CreateRotationZ(-1.1f) *
               Matrix.CreateTranslation(514f, 314f, 000f);
            hallPOS[19] = Matrix.CreateScale(20, 320, 30) * Matrix.CreateRotationZ(.9f) *
               Matrix.CreateTranslation(426f, 426f, 000f);

            //11
            hallPOS[20] = Matrix.CreateScale(20, 100, 30) * Matrix.CreateRotationZ(1f) *
               Matrix.CreateTranslation(440f, 326f, 000f);

            //12
            hallPOS[21] = Matrix.CreateScale(20, 100, 30) * Matrix.CreateRotationZ(1.571f) *
               Matrix.CreateTranslation(301f, 301f, 000f);
            hallPOS[22] = Matrix.CreateScale(20, 85, 30) * Matrix.CreateRotationZ(-1f) *
               Matrix.CreateTranslation(375f, 326f, 000f);

            //13
            hallPOS[23] = Matrix.CreateScale(20, 85, 30) * Matrix.CreateRotationZ(1f) *
               Matrix.CreateTranslation(226f, 326f, 000f);

            //14
            hallPOS[24] = Matrix.CreateScale(20, 85, 30) * Matrix.CreateRotationZ(1.15f) *
               Matrix.CreateTranslation(84f, 314f, 000f);
            hallPOS[25] = Matrix.CreateScale(20, 85, 30) * Matrix.CreateRotationZ(-1f) *
               Matrix.CreateTranslation(164f, 326f, 000f);

            //15
            hallPOS[26] = Matrix.CreateScale(20, 320, 30) * Matrix.CreateRotationZ(-.9f) *
               Matrix.CreateTranslation(176f, 426f, 000f);

            //16
            hallPOS[27] = Matrix.CreateScale(20, 100, 30) * Matrix.CreateRotationZ(1f) *
               Matrix.CreateTranslation(351f, 381f, 000f);
            //17
            hallPOS[28] = Matrix.CreateScale(20, 100, 30) * Matrix.CreateRotationZ(-1f) *
               Matrix.CreateTranslation(251f, 381f, 000f);
            //18
            hallPOS[29] = Matrix.CreateScale(20, 100, 30) * Matrix.CreateRotationZ(0f) *
               Matrix.CreateTranslation(301f, 469f, 000f);
            #endregion

        }

        #region bringclose

        protected override void Initialize()
        {
            // TODO: Add your initialization logic here


            this.IsMouseVisible = true;//MAKES MOUSE VISIBLE IN GAME WINDOW
            base.Initialize();

        }

     
        protected override void LoadContent()
        {

            // Create a new SpriteBatch, which can be used to draw textures.
            primitives.Add(new SpherePrimitive(GraphicsDevice));
            primitives.Add(new CylinderPrimitive(GraphicsDevice));


            spriteBatch = new SpriteBatch(GraphicsDevice);
            myFont = Content.Load<SpriteFont>("myFont");
            roomPl = Content.Load<Texture2D>("player");
            roomE = Content.Load<Texture2D>("room");
            roomB = Content.Load<Texture2D>("bats");
            roomP = Content.Load<Texture2D>("pit");
            roomW = Content.Load<Texture2D>("wumpus");
            Pmove = Content.Load<Texture2D>("move");
            Pshoot = Content.Load<Texture2D>("shoot");
            Hmove = Content.Load<Texture2D>("hovermove");
            Hshoot = Content.Load<Texture2D>("hovershoot");
            Hroom = Content.Load<Texture2D>("Roomhover");
            go = Content.Load<Texture2D>("go");
            samemap = Content.Load<Texture2D>("samemap");
            random = Content.Load<Texture2D>("randomize");
            // create 1x1 texture for line drawing
            t = new Texture2D(GraphicsDevice, 1, 1);
            t.SetData<Color>(
                new Color[] { Color.White });// fill the texture with white

        }


        protected override void UnloadContent()
        {


        }

        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)//================================================================================================================================================================
        {
            float time = (float)gameTime.TotalGameTime.TotalSeconds;
            var mouseState = Mouse.GetState();
            System.Console.WriteLine("path is " + path[0] + " " + path[1] + " " + path[2] + " " + path[3] + " " + path[4]);


            if (j < 5 && path[j] != -1)
                {
                System.Console.WriteLine("true");
                cameraIndex = path[j];
                if(path[0] == you.getLocation() || j>0 || release || !zoomed)
                    Zoom(cameraIndex, time);
                if(lastTimeRoom + intervalBetweenRoom < gameTime.TotalGameTime && j <5)
                    {
                    lastTimeRoom = gameTime.TotalGameTime;
                    if(release == true)
                        {
                            j += 1;

                        }
                    if (j == 4 || path[j+1] == -1)
                        release = false;
                    }
                }
            else
                {
                j = 0;
                }


            var mousePosition = new Point(mouseState.X, mouseState.Y); // This is for the MOUSE which is necessary to interface with game
            Random random = new Random();
            //boolean step flags are console and turn
            if (step1) // FIRST THE WUMP MOVES AND THEN PLAYER DETECTS THINGS AROUND THEM
            {
                if (wump.getWoke() == true)
                {
                    arena1[wump.getLocation()].hazard -= 4;
                    int moveA = wump.getLocation();
                    int moveB = arena1[wump.getLocation()].getConnect()[0];
                    int moveC = arena1[wump.getLocation()].getConnect()[1];
                    int moveD = arena1[wump.getLocation()].getConnect()[2];
                    if(!win)
                    wump.move(moveA, moveB, moveC, moveD);

                    
                    arena1[wump.getLocation()].hazard += 4;
                    if (arena1[you.getLocation()].hazard >= 4)
                    {
                        message1 = true;
                        wumpussprite = you.getLocation();
                        // System.Console.WriteLine("\nTHE WUMPUS IS HERE GET AWAY BFORE THE TURN ENDS!\n"); // MESSAGE 1 FLAG
                    }
                    else
                        message1 = false;
                }
                System.Console.WriteLine("WUMP IS AT " + wump.getLocation());
                you.detect(arena1[you.getLocation()], arena1);
                // MESSAGE 2 FLAG
                // System.Console.WriteLine("You are at room " + you.getLocation());
                // System.Console.WriteLine("This room connects to: " + arena1[you.getLocation()].getConnect()[0] + ", " + arena1[you.getLocation()].getConnect()[1] + ", and " + arena1[you.getLocation()].getConnect()[2]);
                step1 = false;
                step2 = true;
            }
            


            if(step2) // HERE IT AWAITS THE INPUT OF THE PLAYER IN CLICKS
            {   // HERE IS HIGHLIGHTING FEATURE I DID FOR FUN

                if (shootArea.Contains(mousePosition))
                    Pshoot = Hshoot;
                else
                    Pshoot = Content.Load<Texture2D>("shoot");
                if (moveArea.Contains(mousePosition))
                    Pmove = Hmove;
                else
                    Pmove = Content.Load<Texture2D>("move");
                if(mouseState.LeftButton == ButtonState.Pressed && moveArea.Contains(mousePosition) && win != true && oldMouseState.LeftButton == ButtonState.Released)
                {
                    System.Console.WriteLine("WUMP IS AT " + wump.getLocation());
                    message4 = false;
                    message3 = true;
                    path[0] = you.getLocation();
                    cameraIndex = path[0];
                    //cameraIndex = you.getLocation();
                }
                if (mouseState.LeftButton == ButtonState.Pressed && message3 ==true && oldMouseState.LeftButton == ButtonState.Released)
                {
                   
                    message9 = false;
                   if(clickRoom(roomAreas) == arena1[you.getLocation()].getConnect()[0] ||
                        clickRoom(roomAreas) == arena1[you.getLocation()].getConnect()[1]||
                        clickRoom(roomAreas) == arena1[you.getLocation()].getConnect()[2])
                    {
                        pitsprite = -1;
                        wumpussprite = -1;
                        batsprite = -1;
                        you.reset();
                        you.setLocation(clickRoom(roomAreas));
                        message3 = false;
                        step2 = false;
                        step3 = true;
                        
                        //TODO ZOOM
                    }
                    backward = -1;
                    path = new int[] { -1, -1, -1, -1, -1 };
                    path[0] = you.getLocation();
                    cameraIndex = path[0];
                }
                


                if (mouseState.LeftButton == ButtonState.Pressed && shootArea.Contains(mousePosition) && oldMouseState.LeftButton == ButtonState.Released && win != true)
                {
                    
                    message9 = false;
                    
                    
                    message3 = false;
                    if(arrows>0)
                    message4 = true;
                    else
                    { 
                        System.Console.WriteLine("OUT OF ARROWS");
                        message10 = true;
                    }
                    
                    index = 0;
                    currentIndex = you.getLocation(); // EVERYTIME YOU PRESS THE AIM BUTTON THIS HAPPENS
                    backward = -1;
                    previousIndex = -1;
                    arrows -= 1;
                    path = new int[] { -1, -1, -1, -1, -1 };
                    pathcounter = 0;
                   
                    
                }

                if (message4 == true && mouseState.LeftButton == ButtonState.Pressed && oldMouseState.LeftButton == ButtonState.Released && clickRoom(roomAreas) != -1)
                {
                    // AFTER YOU PRESS THE AIM BUTON YOU CLICK THE ROOMS
                    System.Console.WriteLine(clickRoom(roomAreas));
                    
                    if (index < 5)
                    {
                        backward =-1;
                        //previousIndex = -1;

                        int temp = clickRoom(roomAreas);
                        if (temp != -1)
                        {
                            if (temp == previousIndex)
                                message5 = true; //System.Console.WriteLine("Arrows are not that crooked");

                            else
                            {
                                message5 = false;
                                path[index] = temp;
                                pathcounter += 1;
                                for (int i = 0; i < 5; i++)
                                    System.Console.WriteLine("index" + i + " is " + path[i]);
                                index += 1;
                                previousIndex = currentIndex;
                                currentIndex = clickRoom(roomAreas);
                            }
                        }

                    }

                }

                if (mouseState.LeftButton == ButtonState.Pressed && goArea.Contains(mousePosition) && oldMouseState.LeftButton == ButtonState.Released && message4 == true)
                { // PRESS FIRE TO RELEASE YOUR ARROW
                    
                    shoot(you.getLocation(), wump.getLocation(), path, arena1, pathcounter, gameTime);
                    if (!win)
                    {
                        wump.wakeUp();
                        message9 = true;
                        System.Console.WriteLine("Missed!");
                    }
                    batsprite = -1;
                    pitsprite = -1;
                    wumpussprite = -1;
                    message4 = false;
                    step2 = false;
                    step3 = true;
                    release = true;

                }
                if (win == true)
                {
                    
                    nofix = false;
                    arrows = 5;
                    if (mouseState.LeftButton == ButtonState.Pressed && randomArea.Contains(mousePosition) && oldMouseState.LeftButton == ButtonState.Released)
                    { // RESET GAME with random map
                        pitsprite = -1;
                        wumpussprite = -1;
                        batsprite = -1;
                        wump.sleep();
                        arena1 = map1.createArena();
                        map1.describeMap(arena1, you, wump);
                        win = false;
                        reset();
                        you.reset();
                        step2 = false;
                        step1 = true;
                    }
                    else if (mouseState.LeftButton == ButtonState.Pressed && sameArea.Contains(mousePosition) && oldMouseState.LeftButton == ButtonState.Released)
                    { // RESET GAME with same map
                        pitsprite = -1;
                        wumpussprite = -1;
                        batsprite = -1;
                        map1.describeMap(arena1, you, wump);
                        you.setLocation(pstart);
                        wump.sleep();
                        wump.setLocation(wstart);
                        System.Console.WriteLine(wstart);
                        win = false;
                        reset();
                        you.reset();
                        step2 = false;
                        step1 = true;

                    }
                }

                
            }

            

            if (step3) // THIS IS WHERE GAME SEES IF YOU DIE
            {
                while (arena1[you.getLocation()].hazard == 1)
                { 
                    batsprite = you.getLocation();
                    you.pMessage4=true;
                    you.setLocation(random.Next(20));
                }
                if (arena1[you.getLocation()].hazard == 2)
                    {
                    win = true;
                    pitsprite = you.getLocation();
                    you.pMessage5 = true;
                    nofix = false;
                    arrows = 5;
                    message11 = true;
                    }
                
                if (arena1[you.getLocation()].hazard >= 4) 
                {
                    wumpussprite = you.getLocation();

                    if (wump.getWoke() == false)
                     {
                         you.wumpus(wump);
                         arena1[wump.getLocation()].hazard -= 4;
                         int moveA = wump.getLocation();
                         int moveB = arena1[wump.getLocation()].getConnect()[0];
                         int moveC = arena1[wump.getLocation()].getConnect()[1];
                         int moveD = arena1[wump.getLocation()].getConnect()[2];
                         wump.move(moveA, moveB, moveC, moveD);
                         arena1[wump.getLocation()].hazard += 4;
                         System.Console.WriteLine("WUMP IS AT " + wump.getLocation());
                        if (arena1[you.getLocation()].hazard >= 4)
                        {
                            win = true;
                            pitsprite = you.getLocation();
                            nofix = false;
                            arrows = 5;
                            you.pMessage7 = true;
                            message11 = true;
                        }

                     }
                     else if (wump.getWoke() == true)
                     {
                        win = true;
                        pitsprite = you.getLocation();
                        nofix = false;
                        arrows = 5;
                        you.pMessage7 = true;
                        message11 = true;
                    }
                }
                
                step3 = false;
                step1 = true;

            }

            oldMouseState = mouseState;
            base.Update(gameTime);
            
        }
        //==================================================================================================================================================================================================================
        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
           
            GraphicsDevice.Clear(Color.White);
            GraphicsDevice.RasterizerState = RasterizerState.CullCounterClockwise;
            float time = (float)gameTime.TotalGameTime.TotalSeconds;

#endregion

            float aspect = GraphicsDevice.Viewport.AspectRatio;
            
            Matrix view = Matrix.CreateLookAt(cameraPosition, cameraFocus, Vector3.Down);
            Matrix projection = Matrix.CreatePerspectiveFieldOfView(1f, aspect, 1, 20000f);
            
            
            GeometricPrimitive spheres = primitives[0];
            GeometricPrimitive halls = primitives[1];

            for(int i =0; i <20; i++)
            {
                
                spheres.Draw(spherePOS[i], view, projection, colors[0]);
                if (i == you.getLocation())
                    spheres.Draw(spherePOS[i], view, projection, colors[3]);
               
                if (arena1[i].hazard == 1)
                    spheres.Draw(spherePOS[i], view, projection, colors[1]);

                if (arena1[i].hazard == 2 && i == you.getLocation())
                    spheres.Draw(spherePOS[i], view, projection, colors[2]);
                
                if (arena1[i].hazard >= 4 && i == you.getLocation())
                    spheres.Draw(spherePOS[i], view, projection, colors[4]);
            }
           
            for (int i = 0; i <30; i++)
            {
                halls.Draw(hallPOS[i], view, projection, colors[0]);
            }
           


            //SPRITES IN DRAW IS SIMPLY BASED ON WTETHER THE BOOLEAN ASSOCIATED WITH THE TEXTURE IS TRUE WHICH IS DETERMINED IN UPDATE

            #region Sprites
            spriteBatch.Begin();

            //DRAWING THE PATHS BETWEEN ROOMS
            DrawLine(spriteBatch, adjustpos(roomPOS[0], 24, 24), adjustpos(roomPOS[1], 24,24));
            DrawLine(spriteBatch, adjustpos(roomPOS[0], 24, 24), adjustpos(roomPOS[2], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[0], 24, 24), adjustpos(roomPOS[10], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[1], 24, 24), adjustpos(roomPOS[4], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[1], 24, 24), adjustpos(roomPOS[15], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[10], 24, 24), adjustpos(roomPOS[11], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[10], 24, 24), adjustpos(roomPOS[19], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[4], 24, 24), adjustpos(roomPOS[3], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[4], 24, 24), adjustpos(roomPOS[9], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[15], 24, 24), adjustpos(roomPOS[14], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[15], 24, 24), adjustpos(roomPOS[19], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[11], 24, 24), adjustpos(roomPOS[6], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[11], 24, 24), adjustpos(roomPOS[16], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[19], 24, 24), adjustpos(roomPOS[18], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[3], 24, 24), adjustpos(roomPOS[2], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[3], 24, 24), adjustpos(roomPOS[5], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[9], 24, 24), adjustpos(roomPOS[8], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[9], 24, 24), adjustpos(roomPOS[14], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[14], 24, 24), adjustpos(roomPOS[17], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[6], 24, 24), adjustpos(roomPOS[2], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[6], 24, 24), adjustpos(roomPOS[7], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[16], 24, 24), adjustpos(roomPOS[12], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[16], 24, 24), adjustpos(roomPOS[18], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[18], 24, 24), adjustpos(roomPOS[17], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[5], 24, 24), adjustpos(roomPOS[7], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[5], 24, 24), adjustpos(roomPOS[8], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[8], 24, 24), adjustpos(roomPOS[13], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[7], 24, 24), adjustpos(roomPOS[12], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[12], 24, 24), adjustpos(roomPOS[13], 24, 24));
            DrawLine(spriteBatch, adjustpos(roomPOS[13], 24, 24), adjustpos(roomPOS[17], 24, 24));

            if(message4)
            {
            if (path[0] != -1)
                DrawLine(spriteBatch, adjustpos(roomPOS[you.getLocation()], 24, 24), adjustpos(roomPOS[path[0]], 24, 24), 4, Color.Blue);
            if (path[1] != -1) 
            DrawLine(spriteBatch, adjustpos(roomPOS[path[0]], 24, 24), adjustpos(roomPOS[path[1]], 24, 24), 4, Color.Blue);
            if (path[2] != -1)
                DrawLine(spriteBatch, adjustpos(roomPOS[path[1]], 24, 24), adjustpos(roomPOS[path[2]], 24, 24), 4, Color.Blue);
            if (path[3] != -1)
                DrawLine(spriteBatch, adjustpos(roomPOS[path[2]], 24, 24), adjustpos(roomPOS[path[3]], 24, 24), 4, Color.Blue);
            if (path[4] != -1)
                DrawLine(spriteBatch, adjustpos(roomPOS[path[3]], 24, 24), adjustpos(roomPOS[path[4]], 24, 24), 4, Color.Blue);
            }


            if(batsprite > -1)
            {
                spriteBatch.Draw(roomB, roomPOS[batsprite], Color.White);
            }
            if(pitsprite >-1)
                spriteBatch.Draw(roomP, roomPOS[pitsprite], Color.White);
            if (wumpussprite > -1)
                spriteBatch.Draw(roomW, roomPOS[wumpussprite], Color.White);


            for (int i = 0; i < 20; i++)
            {
                if (batsprite != i && pitsprite != i && wumpussprite != i)
                    spriteBatch.Draw(roomE, roomPOS[i], Color.White);
                if (you.getLocation() == i)
                    if (batsprite != i && pitsprite != i && wumpussprite != i)
                        spriteBatch.Draw(roomPl, roomPOS[i], Color.White);
                spriteBatch.DrawString(myFont, i.ToString(), adjustpos(roomPOS[i], 0, -17), Color.Black);
            }

            spriteBatch.Draw(Pmove, new Vector2(1180,600), Color.White);
            spriteBatch.Draw(Pshoot, new Vector2(1180, 650), Color.White);
            spriteBatch.Draw(go, new Vector2(1080, 650), Color.White);
            spriteBatch.Draw(random, new Vector2(5, 650), Color.White);
            spriteBatch.Draw(samemap, new Vector2(105, 650), Color.White);


            if (message1)
                spriteBatch.DrawString(myFont, "Run the WUMPUS is here!", new Vector2(640,50), Color.Red);
            if (message2)
            { 
                spriteBatch.DrawString(myFont, "You are at room " + you.getLocation(), new Vector2(640, 65), Color.Black);
                spriteBatch.DrawString(myFont, "This room connects to: " + arena1[you.getLocation()].getConnect()[0] + ", " + arena1[you.getLocation()].getConnect()[1] + ", and " + arena1[you.getLocation()].getConnect()[2], new Vector2(640, 80), Color.Black);
            }
            if (message3)
            {
                spriteBatch.DrawString(myFont, "Click on an adjacent room to move there.", new Vector2(640, 305), Color.Black);
            }
            if (message4)
            {
                spriteBatch.DrawString(myFont, "Click up to 5 rooms for the path of the arrow then press GO.", new Vector2(640, 305), Color.Black);
            }
            if(message5)
            {
                spriteBatch.DrawString(myFont, "Arrows aren't that crooked.", new Vector2(640, 320), Color.Black);
            }
            if(message6)
            {
                spriteBatch.DrawString(myFont, "Ouch! Arrow got you!", new Vector2(640, 185), Color.Black);
            }
            if (message7)
            {
                spriteBatch.DrawString(myFont, "Aha! You got the Wumpus!", new Vector2(640, 170), Color.Black);
            }
            if (message8)
            {
                spriteBatch.DrawString(myFont, "Hee hee hee - the Wumpus'll getcha next time!!\nWould you like to play the same map or randomize \nto a new one?", new Vector2(640, 215), Color.Black);
                
            }
            if (message9)
            {
                spriteBatch.DrawString(myFont, "MISSED!!!", new Vector2(640, 245), Color.Black);

            }
            if (message10)
            {
                spriteBatch.DrawString(myFont, "Out of Arrows!!!", new Vector2(640, 215), Color.Black);

            }
            if(message11)
            {
                spriteBatch.DrawString(myFont, "Would you like to play the same map or randomize \nto a new one?", new Vector2(640, 215), Color.Black);
            }








            //spriteBatch.DrawString(myFont, "" + you.pMessage1, new Vector2(640, 35), Color.Black);
            if (you.pMessage1 == true)
            {
                spriteBatch.DrawString(myFont, "Bats nearby!", new Vector2(640, 35), Color.Black);
            }
            //spriteBatch.DrawString(myFont, ""+you.pMessage2, new Vector2(640, 20), Color.Black);
            if (you.pMessage2 == true)
            {
                spriteBatch.DrawString(myFont, "I feel a draft.", new Vector2(640, 20), Color.Black);
            }
            //spriteBatch.DrawString(myFont, "" + you.pMessage3, new Vector2(640, 5), Color.Black);
            if (you.pMessage3 == true)
            {
                spriteBatch.DrawString(myFont, "I smell a Wumpus!", new Vector2(640, 5), Color.Black);
            }
            if (you.pMessage4 == true)
            {
                spriteBatch.DrawString(myFont, "Zap--Super Bat snatch! Elsewhereville for you!", new Vector2(640, 110), Color.Black);
            }
            if (you.pMessage5 == true)
            {
                spriteBatch.DrawString(myFont, "YYYIIIIEEEE... fell in a pit", new Vector2(640, 110), Color.Black);
            }
            if (you.pMessage6 == true)
            {
                spriteBatch.DrawString(myFont, "Ooops! Bumped a Wumpus", new Vector2(640, 110), Color.Black);
            }
            if (you.pMessage7 == true)
            {
                spriteBatch.DrawString(myFont, "OH NO THE WUughhgh...", new Vector2(640, 125), Color.Black);
            }
            if (you.pMessage8 == true)
            {
                spriteBatch.DrawString(myFont, "OH NO YOU DIED!\n Would you like to play the same map or randomize to a new one?\nS - Same Map\nR - Randomize to a new Map", new Vector2(640, 95), Color.Black);
            }




            spriteBatch.End();
#endregion

            base.Draw(gameTime);
          
        }
    }
}