﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace WumpusHunter3000
{
    public class Wumpus
    {
        Random random = new Random();
        private int location;
        private Boolean wake;

        public Wumpus(int loc)
        {
            location = loc;
            wake = false;
        }

        public Boolean getWoke()
        {
            return wake;
        }

        public void wakeUp()
        {
            wake = true;
        }

        public void sleep()
        {
            wake = false;
        }

        public int move(int a, int b, int c, int d)
        {

            int r = random.Next(4);
            if (r == 0)
                location = a;
            if (r == 1)
                location = b;
            if (r == 2)
                location = c;
            if (r == 3)
                location = d;
            return location;
        }

        public int getLocation()
        {
            return location;
        }

        public int setLocation(int a)
        {
            location = a;
            return location;
        }
    }
}
